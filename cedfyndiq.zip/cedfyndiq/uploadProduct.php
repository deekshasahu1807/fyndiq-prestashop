<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedShopee
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqProduct.php');

if (!Tools::isSubmit('secure_key')
    || Tools::getValue('secure_key') != Configuration::get('CEDFYNDIQ_CRON_SECURE_KEY')) {
    die('Secure key not matched');
}

try {

    $CedfyndiqHelper = new CedfyndiqHelper;
    $CedfyndiqProduct = new CedfyndiqProduct;

    $db = Db::getInstance();

    $product_ids = array();
    $allproducts= Configuration::get('CEDFYNDIQ_CATEGORY_MAP_ALL');

    if ($allproducts) {
        $query = Db::getInstance()->ExecuteS("SELECT `id_product` 
                     FROM " . _DB_PREFIX_ . "product");
        if (is_array($query) && count($query)) {
            foreach ($query as $value) {
                if (isset($value['id_product']) && $value['id_product']) {
                    $product_ids[] = $value['id_product'];
                }
            }
        }
    } else {
        $query = Db::getInstance()->ExecuteS("SELECT `mapped_categories` 
                       FROM `" . _DB_PREFIX_ . "fyndiq_category_list` WHERE `mapped_categories` != '' 
                       ORDER BY `mapped_categories` DESC");
       
        if (is_array($query) && count($query)) {
            foreach ($query as $value) {
                if (isset($value['mapped_categories']) && $value['mapped_categories']) {
                    $value['mapped_categories'] = unserialize($value['mapped_categories']);
                    $categories = implode(',', $value['mapped_categories']);

                    if($categories)
                    {
                        $query = Db::getInstance()->ExecuteS("SELECT cp.`id_product` 
                        FROM `" . _DB_PREFIX_ . "category_product` cp
                        JOIN `"._DB_PREFIX_."product` p ON (p.id_product = cp.`id_product`)
                        LEFT JOIN `"._DB_PREFIX_."fyndiq_products` fp ON (p.`id_product` = fp.`product_id`) 
                        WHERE p.`id_category_default` IN (" . $categories . ")");

                        if (is_array($query) && count($query)) 
                        {
                            foreach ($query as $val) {
                                if (isset($val['id_product']) && $val['id_product']) {
                                    $product_ids[] = $val['id_product'];
                                }
                            }
                        }
                    }
                }
            }
        }

        $sql =  Db::getInstance()->ExecuteS("SELECT `product_id` FROM `". _DB_PREFIX_ ."fyndiq_products` 
                WHERE `fyndiq_status` != 'Excluded' AND `category` != ''");

        if (is_array($sql) && count($sql)) {
            foreach ($sql as $val) {
                if (isset($val['product_id']) && $val['product_id']) {
                    $product_ids[] = $val['product_id'];
                }
            }
        }
    }
    $product_ids = array_unique($product_ids);
    asort($product_ids);
    $product_ids = array_values($product_ids);

    if (is_array($product_ids) && count($product_ids)) 
    {
        //$db = Db::getInstance();

        // $sql = "DELETE FROM  `"._DB_PREFIX_."fyndiq_final_products`";
        // $res = $db->execute($sql);
        // if ($res) {
            $csv_dir = _PS_MODULE_DIR_.'cedfyndiq/product_upload/';
            if (!is_dir($csv_dir)) {
                mkdir($csv_dir, '0777', true);
            }
            $file = fopen($csv_dir.'product_feed.csv', 'w');
            fputcsv($file, array());
            fclose($file);
        // }

        $errors = array();
        $successes = array();
        $response = $CedfyndiqProduct->uploadProducts($product_ids);
//echo '<pre>'; print_r($response); die;
        if (isset($response['error']) && is_array($response['error']) && !empty($response['error']))
        {
            die(Tools::jsonEncode(
                array(
                    'status' => false,
                    'response' => $response['error']
                )
            ));
        } else {
            die(Tools::jsonEncode(
                array(
                    'status' => true,
                    'response' => $response['success']
                )
            ));
        }
    }  else {
        die(Tools::jsonEncode(array(
            'status' => false,
            'message' => 'Product(s) does not exist in mapped category'
        )));
    }
} catch(\Exception $e) {
    $CedfyndiqHelper->log(
        'Cron uploadProduct',
        'Exception',
        $e->getMessage(),
        $e->getMessage(),
        true
    );
    die(Tools::jsonEncode(array(
        'status' => false,
        'message' => $e->getMessage()
    )));
}