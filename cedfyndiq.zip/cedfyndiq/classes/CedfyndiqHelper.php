<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

class CedfyndiqHelper
{

    public function isEnabled()
    {
        $flag = false;

        if (Configuration::get('CEDFYNDIQ_LIVE_MODE')) {
            $flag = true;
            $this->init();
        }
        return $flag;
    }

    public function init()
    {
        $this->_api_url = Configuration::get('CEDFYNDIQ_API_URL');
        $this->user = Configuration::get('CEDFYNDIQ_CONSUMER_ID');
        $this->pass = Configuration::get('CEDFYNDIQ_TOKEN');
    }

    public function log($method = '', $type = '', $message = '', $response = '', $force_log = false)
    {
        if (Configuration::get('CEDFYNDIQ_DEBUG_ENABLE') || $force_log == true) {
            $db = Db::getInstance();
            $db->insert(
                'fyndiq_logs',
                array(
                    'method' => pSQL($method),
                    'type' => pSQL($type),
                    'message' => pSQL($message),
                    'data' => pSQL($response, true),
                )
            );
        }
    }

    public function fyndiqPostRequest($url, $params = array(), $method)
    {
        $enable = $this->isEnabled();
        if ($enable) {
            try {
                $url = $this->_api_url . $url;

                $body = array();
                
                if(isset($params) && is_array($params) && !empty($params))
                {
                    if(isset($params['product_feed_url']) && !empty($params['product_feed_url'])){
                        $params['product_feed_url'] = str_replace('http://', 'https://', $params['product_feed_url']);
                    }
                    if(isset($params['product_feed_notification_url']) && !empty($params['product_feed_notification_url'])){
                        $params['product_feed_notification_url'] = str_replace('http://', 'https://', $params['product_feed_notification_url']);
                    }
                    if(isset($params['order_notification_url']) && !empty($params['order_notification_url'])){
                        $params['order_notification_url'] = str_replace('http://', 'https://', $params['order_notification_url']);
                    }
                    $body = Tools::jsonEncode($params);
                }

                $headers = array();

                $headers[] = "Accept: application/json";
                $headers[] = "Content-Type: application/json";

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                //curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                curl_setopt($ch, CURLOPT_USERPWD, $this->user . ":" . $this->pass);
                //curl_setopt($ch, CURLOPT_HEADER, TRUE);

                // Set additional method specific options
                switch($method) {
                    case 'GET':
                        break;
                    case 'POST':
                        curl_setopt($ch, CURLOPT_POST, TRUE);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
                        curl_setopt($ch, CURLOPT_HEADER, TRUE);
                        break;
                    case 'PATCH':
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
                        break;
                    case 'PUT':
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
                        break;
                    case 'DELETE':
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
                        break;
                }

                $server_output = curl_exec($ch);
                //echo '<pre>'; print_r($server_output); die;
                $curlError = curl_error($ch);
                $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $body = Tools::substr($server_output, $header_size);

                $res = array(
                    'Post Request Url' => $url,
                    'Post Request Header' => $headers,
                    'Post Request Params' => $params,
                    'Post Request Response' => $server_output,
                );
                $this->log(__METHOD__, 'Info', 'Post Request to fyndiq', Tools::jsonEncode($res));
                if ($curlError) {
                    return array('success' => false, 'message' => $curlError);
                }
                if (!curl_errno($ch)) {
                    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if (($http_code == 204) || ($http_code == 200)) {
                        return array('success' => true, 'message' => $body);
                    } else {
                        return array('success' => false, 'message' => $body);
                    }
                }
                curl_close($ch);
            } catch (Exception $e) {
                $this->log(
                    'CedfyndiqHelper::fyndiqPostRequest',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
                return array('success' => false, 'message' => $e->getMessage());
            }
        } else {
            return array('success' => false, 'message' => 'Module is not enable.');
        }
    }

    public function fyndiqGetRequest($url, $params = array())
    {
        $enable = $this->isEnabled();
        if ($enable) {
            try {
                $url = $this->_api_url . $url;
                 foreach($params as $key => $value){
                    $url = $url . $value . '/';
                 }
                 // echo $url; die;
                $headers = array();
                //$headers[] = "Authorization: $this->user";
                $headers[] = "Accept: application/json";
                $headers[] = "Content-Type: application/json"; // x-www-form-urlencoded

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_HEADER, FALSE);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                curl_setopt($ch, CURLOPT_USERPWD, $this->user . ':' . $this->pass);
                $server_output = curl_exec($ch);
 
                $res = array(
                    'Get Request Url' => $url,
                    'Get Request Header' => $headers,
                    'Get Request Parameters' => $params,
                    'Get Request Response' => $server_output,
                );
                $this->log(__METHOD__, 'Info', 'Fyndiq Get Request', Tools::jsonEncode($res));

                $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                $header = Tools::substr($server_output, 0, $header_size);
                $body = Tools::substr($server_output, $header_size);
                if (!curl_errno($ch)) {
                    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if ($http_code == 200) {
                        return array('success' => true, 'response' => $server_output);
                    } else {
                        if ($body) {
                            return array('success' => false, 'message' => $body);
                        } else {
                            return array('success' => false, 'message' => $server_output);
                        }
                    }
                }
                curl_close($ch);
            } catch (Exception $e) {
                $this->log(
                    'CedfyndiqHelper::fyndiqGetRequest',
                    'Exception',
                    $e->getMessage() . 'for' . $url,
                    $e->getMessage(),
                    true
                );
                return array('success' => false, 'message' => $e->getMessage());
            }
        } else {
            return array('success' => false, 'message' => 'Module is not enable.');
        }
    }

    public function getFyndiqCategories()
    {
        $db = Db::getInstance();
        $countries = $db->ExecuteS("SELECT `category_id`, `name_sv` FROM `" . _DB_PREFIX_ . "fyndiq_category_list`");
        if(isset($countries) && is_array($countries)) {
            return $countries;
        } else {
            return array();
        }
    }

    public function getValidationArray()
    {
        return array(
            'product-id' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 32,
                'description' =>
                    'The merchant\'s product ID that ties together a group of articles. This must be unique for each product within the feed. Fyndiq will use it during the reading of the feed, but never save it.'
            ),
            'product-paused' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 1,
                'description' =>
                    'If 1, it is a signal that this product should be paused from selling. Un-pause it again by submitting it in the feed with this flag set to 0.'
            ),
            'product-category-id' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 32,
                'description' =>
                    'The merchant\'s unique internal category id for this product. This is used to identify and map the merchant\'s categories to Fyndiq\'s. '
            ),
            'product-category-name' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 512,
                'description' =>
                    'The merchant\'s unique internal category name associated with this product. This is used for displaying the category in Fyndiq\'s '
            ),
            'product-category-fyndiq-id' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 32,
                'description' =>
                    'Fyndiq\'s category id for this product. A category using product-category-fyndiq-id will take precedence over the choices made for product-category-id and product-category-name fields.'
            ),
            'product-brand-name' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 32,
                'description' => 'The brand name of the product.'
            ),
            'product-title' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 64,
                'description' =>
                    'The title of the product.'
            ),
            'product-description' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 4096,
                'description' =>
                    'The description of the product. The product-description must not contain any HTML or other formatting.'
            ),
            'product-market' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 32,
                'description' =>
                    'What market the product is to be sold in. We do not support selling in different markets from the same merchant account. Possible Value "SE". '
            ),
            'product-currency' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 32,
                'description' => '
                    The currency of the values in "price" and "oldprice". Possible Value "SEK".'
            ),
            'product-price' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 32,
                'description' =>
                    "The price of the product. Must have dot (.) as decimal separator and two digits after the decimal point. Include VAT."
            ),
            'product-oldprice' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 32,
                'description' =>
                    "The old price of the product, i.e the price before selling on Fyndiq. If the merchant did not lower the price when starting to sell on Fyndiq, this should be set to equal to the 'price' field. Must have dot (.) as decimal separator and two digits after the decimal point. Include VAT."
            ),
            'product-vat-percent' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 32,
                'description' =>
                    'The vat percentage of the price and oldprice (the price and oldprice must include VAT).'
            ),
            'product-portion' => array(
                'type' => 'digits',
                'is_required' => false,
                'length' => 32,
                'description' =>
                    'The total weight or volume of the product (to be used in combination with product-comparison-unit). If decimal value, must have dot (.) as decimal separator and two digits after the decimal point.'
            ),
            'product-comparison-unit' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 5,
                'description' =>
                    'The unit of measurement for the weight or volume of the product (to be used in combination with product-portion). Should be one of g, kg, ml, l, m, m2, m3, wash.'
            ),
            'product-image-1-url' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 2150,
                'description' =>
                    'URL to the first product image (image-1). Supported formats are PNG, JPEG and GIF. The image must have a width of at least 200 pixels, and a height of at least 200 pixels.'
            ),
            'product-image-1-identifier' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 42,
                'description' =>
                    'The image identifier (for image-1) is a string denoting a unique instance of an image. When the contents of this field changes from the previous feed read, Fyndiq will fetch the corresponding image again. The field is needed for performance reasons – without it, every image would be downloaded once per hour, causing unnecessary network traffic and server load. Suggestions of values to use here are: A hash of the image contents, a timestamp of when the image was last updated, or a unique id representing a unique image.'
            ),
            'product-image-2-url' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "URL to the second product image."
            ),
            'product-image-2-identifier' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 42,
                'description' =>
                    "The image identifier (for image-2)."
            ),
            'product-image-3-url' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "URL to the second product image."
            ),
            'product-image-3-identifier' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 42,
                'description' =>
                    "The image identifier (for image-3)."
            ),
            'product-image-4-url' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "URL to the second product image."
            ),
            'product-image-4-identifier' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 42,
                'description' =>
                    "The image identifier (for image-4)."
            ),
            'product-image-5-url' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 2150,
                'description' =>
                    "URL to the second product image."
            ),
            'product-image-5-identifier' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 42,
                'description' =>
                    "The image identifier (for image-5)."
            ),
            'article-sku' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 64,
                'description' =>
                    'The merchant\'s globally unique SKU id of this article. Together with market this identifies a unique article that is to be added or updated.'
            ),
            'article-quantity' => array(
                'type' => 'digits',
                'is_required' => true,
                'length' => 5,
                'description' =>
                    'The quantity in stock of this article that is to be offered to Fyndiq at the reading of the feed.'
            ),
            'article-name' => array(
                'type' => 'string',
                'is_required' => true,
                'length' => 30,
                'description' =>
                    'The name of the article in the market\'s local language.'
            ),
            'article-location' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 64,
                'description' =>
                    'The merchant\'s location for the item in the warehouse. Will be shown on the delivery note to ease picking of items.'
            ),
            'article-ean' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 13,
                'description' =>
                    'Article\'s GTIN (EAN, UPC etc.) reference. As of September 1st 2017, required field for all branded products (field product-brand-name is given).'
            ),
            'article-isbn' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 14,
                'description' =>
                    'If the article has an ISBN code it should be supplied here.'
            ),
            'article-mpn' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 14,
                'description' =>
                    'If the article has an Manufacturer Part Number it should be supplied here.'
            ),
            'article-eu-energy-class' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 32,
                'description' =>
                    'The energy efficency class of the product according to EU Directive 2010/30/EU.'
            ),
            'article-eu-energy-label-url' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 1250,
                'description' =>
                    'URL to picture of EU energy label.'
            ),
            'article-eu-energy-datasheet-url' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 1250,
                'description' =>
                    'URL to EU energy data sheet of product.'
            ),
            'article-property-n-name' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 64,
                'description' =>
                    'The name of the first property associated with this article. If there are several properties they must be listed in as many "property-name-n/property-value-n" column pairs as needed.'
            ),
            'article-property-n-value' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 64,
                'description' =>
                    'The value of the first property associated with this article.'
            ),
            // 'article-property-2-name' => array(
            //     'type' => 'string',
            //     'is_required' => false,
            //     'length' => 50,
            //     'description' =>
            //         'The name of the second property associated with this article.'
            // ),
            // 'article-property-2-value' => array(
            //     'type' => 'string',
            //     'is_required' => false,
            //     'length' => 50,
            //     'description' =>
            //         'The value of the second property associated with this article.'
            // )
        );
    }

    public function variantAttributes()
    {
        return array(
            'article-property-n-name' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 64,
                'description' =>
                    'The name of the first property associated with this article. If there are several properties they must be listed in as many "property-name-n/property-value-n" column pairs as needed.'
            ),
            'article-property-n-value' => array(
                'type' => 'string',
                'is_required' => false,
                'length' => 64,
                'description' =>
                    'The value of the first property associated with this article.'
            ),
            // 'article-property-2-name' => array(
            //     'type' => 'string',
            //     'is_required' => false,
            //     'length' => 50,
            //     'description' =>
            //         'The name of the second property associated with this article.'
            // ),
            // 'article-property-2-value' => array(
            //     'type' => 'string',
            //     'is_required' => false,
            //     'length' => 50,
            //     'description' =>
            //         'The value of the second property associated with this article.'
            // ),
        );
    }
}