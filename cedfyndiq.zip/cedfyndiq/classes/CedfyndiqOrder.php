<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

require_once _PS_MODULE_DIR_ . 'cedfyndiq/classes/CedfyndiqHelper.php';

class CedfyndiqOrder
{
    public function fetchOrder($params, $url)
    {
        $cedFyndiqHelper = new CedfyndiqHelper();
        $response = '';
        $minDate = date('Y-m-d H:i:s',strtotime("-7 days"));
        $minDate = str_replace(' ', '%20', $minDate);
        $order = array('min_date'=> $minDate);
        $queryString = empty($order) ? '' : '?' .'min_date='. $minDate;
//       echo '<pre>'; print_r($url . $queryString); die;
        $response = $cedFyndiqHelper->fyndiqGetRequest($url . $queryString, $params);
        //echo '<pre>'; print_r($response); die;
        
        $cedFyndiqHelper->log(
            __METHOD__,
            'Info',
            'Fetch Order Response',
            Tools::jsonEncode($response)
        );
        try {
            $errorMessage = '';
            if ($response) {
                if (isset($response['success']) && $response['success']) 
                {
                    if (isset($response['response']) && $response['response']) {
                        $response = Tools::jsonDecode($response['response'], true);
                        //echo '<pre>'; print_r($response); die;

                        $cedFyndiqHelper->log(
                            __METHOD__,
                            'Info',
                            'Fetched Order Data',
                            Tools::jsonEncode($response)
                        );

                        if (!is_array($response)) {
                            return array('success' => false, 'message' => $response);
                        }
                        $errorMessage = '';
                        if (isset($response['errors'])) {
                            foreach ($response['errors'] as $error) {
                                foreach ($error as $err) {
                                    if (isset($err['description']) && $err['	description']) {
                                        $errorMessage .= $err['description'];
                                    }
                                }
                            }
                        } else {
                            $order_ids = array();
                            if (is_array($response) && isset($response['results'])) {
                                $fetchedOrders = $response['results'];

                                if (isset($fetchedOrders) && is_array($fetchedOrders)
                                    && count($fetchedOrders)) {
                                    if (!isset($response['results']['0'])) {
                                        $temp_orderLine = $response['results'];
                                        $fetchedOrders = array();
                                        $fetchedOrders['0'] = $temp_orderLine;
                                    }
                                    $totalOrderFetched = count($fetchedOrders);

                                    foreach ($fetchedOrders as $value) {
                                        
                                        if (isset($value['id']) && $value['id']) {
                                            $fyndiq_order_id = $value['id'];

                                            $already_exist = $this->isFyndiqOrderIdExist($value['id'], $value);

                                            if ($already_exist) {
                                                continue;
                                            } else {
                                                $order_ids[] = $this->prepareOrderData($value);
                                                
                                                $cedFyndiqHelper->log(
                                                    __METHOD__,
                                                    'Info',
                                                    'Created Order',
                                                    Tools::jsonEncode($value)
                                                );

                                                $order_ids = array_filter($order_ids);
                                                // for auto accept and reject
                                                // if (Configuration::get('CEDFYNDIQ_AUTO_ORDER_PROCESS')) {
                                                //     $this->acceptOrder($fyndiq_order_id, 'order/accept');
                                                // }
                                            }
                                        }
                                    }
                                    if (count($order_ids) == $totalOrderFetched) {
                                        return array('success' => true, 'message' => $order_ids);
                                    } elseif (count($order_ids) && ($totalOrderFetched > count($order_ids))) {
                                        return array(
                                            'success' => true,
                                            'message' => $order_ids, 'sub_message' => 'Please see Rejected List too.'
                                        );
                                    } elseif (count($order_ids) == 0) {
                                        return array('success' => true, 'message' => 'No new Order Found.');
                                    } else {
                                        return array('success' => false, 'message' => 'Order Send to Rejected List.');
                                    }
                                } else {
                                    return array('success' => true, 'message' => 'No new order found.');
                                }
                            }
                        }
                    }
                    if ($errorMessage) {
                        return array('success' => false, 'message' => $errorMessage);
                    }
                } else {
                    return array('success' => false, 'message' => $response['message']);
                }
            } else {
                return array('success' => false, 'message' => 'Failed to fetch Orders(s)');
            }
        } catch (Exception $e) {
            $cedFyndiqHelper->log(
                'CedfyndiqOrder::fetchOrder',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function prepareOrderData($data = array())
    {
        if ($data) {
            $db = Db::getInstance();
            $fyndiq_order_id = $data['id'];
            $shipment = array(
                'delivery_firstname' => $data['delivery_firstname'],
                'delivery_lastname' => $data['delivery_lastname'],
                'delivery_phone' => $data['delivery_phone'],
                'delivery_company' => (isset($data['delivery_company']) && !empty($data['delivery_company'])) ? $data['delivery_company'] : '',
                'delivery_address' => $data['delivery_address'],
                'delivery_city' => $data['delivery_city'],
                'delivery_country' => $data['delivery_country'],
                'delivery_country_code' =>$data['delivery_country_code'],
                'delivery_postalcode' => $data['delivery_postalcode'],
                'delivery_co' => $data['delivery_co']
                );
            $orderDate = $data['created'];
            $orderDate = str_replace('T', ' ', $orderDate);
            $status = 'NORMAL';

            if (!$this->isFyndiqOrderIdExist($fyndiq_order_id, $data)) {
                $id = $this->createPrestashopOrder($data);
                if ($id) {
                    $prestashop_order_id = $id;
                    $db->insert(
                        'fyndiq_order',
                        array(
                            'prestashop_order_id' => (int)$prestashop_order_id,
                            'order_place_date' => pSQL($orderDate),
                            'order_data' => pSQL(Tools::jsonEncode($data)),
                            'status' => pSQL($status),
                            'fyndiq_order_id' => pSQL($fyndiq_order_id),
                            'shipment_data' => pSQL(Tools::jsonEncode($shipment)),
                            'invoice' => pSQL($data['delivery_note'])
                        )
                    );
                    return $id;
                }
            }
        }
        return null;
    }

    public function createPrestashopOrder($data)
    {
//         echo '<pre>'; print_r($data); die;
        $contexts = Context::getContext();
        $db = Db::getInstance();
        $prestashop_order_id = '';
        $fyndiq_order_id = $data['id'];
        $firstname = $data['delivery_firstname'];
        $lastname = isset($data['delivery_lastname']) ?
            $data['delivery_lastname'] : 'fyndiq';
        $email = $data['id'] . '@fyndiqcustomer.com';
        $phone = isset($data['delivery_phone']) ?
            ($data['delivery_phone']): '';
        $id_lang = $contexts->language->id;
        $id_customer = 0;
        if ((int)Configuration::get('CEDFYNDIQ_CUSTOMER_ID')) {
            $config_id_customer = (int)Configuration::get('CEDFYNDIQ_CUSTOMER_ID');
            $customer = new Customer($config_id_customer);
            if (isset($customer->id) && $customer->id) {
                $id_customer = (int)$customer->id;
            }
        } elseif (Customer::customerExists($email)) {
            $customer = Customer::getCustomersByEmail($email);
            if (isset($customer[0]) && isset($customer[0]['id_customer']) && $customer[0]['id_customer']) {
                $id_customer = (int)$customer[0]['id_customer'];
            }
        }

        if (!$id_customer) {
            $new_customer = new Customer();
            $new_customer->email = $email;
            $new_customer->lastname = $lastname;
            $new_customer->firstname = $firstname;
            $new_customer->passwd = 'fyndiq';
            $new_customer->add();
            $id_customer = (int)$new_customer->id;
        }

        $contexts->customer = new Customer($id_customer);
        $state = '';
        $country = isset($data['delivery_country']) ?
            $data['delivery_country'] : '';
        $country_code = isset($data['delivery_country_code']) ? $data['delivery_country_code'] : '';
        $getLocalizationDetails = $this->getLocalizationDetails($country_code);
        $id_country = $getLocalizationDetails['country_id'];
        $id_state = '';
//        echo '<pre>'; print_r($id_country); die;
        $address_shipping = new Address();
        $address_shipping->id_customer = $id_customer;
        $address_shipping->id_country = $id_country;
        $address_shipping->alias = 'FYN';
        $address_shipping->firstname = $firstname;
        $address_shipping->lastname = $lastname;
        $address_shipping->id_state = $id_state;
        $address_shipping->address1 = isset($data['delivery_address']) ?
            $data['delivery_address'] : '';
        $address_shipping->address2 = '';
        $address_shipping->postcode = isset($data['delivery_postalcode']) ?
            $data['delivery_postalcode'] : '';
        $address_shipping->city = isset($data['delivery_city']) ?
            $data['delivery_city'] : '';
        if ($phone && Validate::isPhoneNumber($phone)) {
            $address_shipping->phone = $phone;
        }
        $address_shipping->add();
        $address_id_shipping = $address_shipping->id;

        $address_invoice = new Address();
        $address_invoice->id_customer = $id_customer;
        $address_invoice->id_country = $id_country;
        $address_invoice->alias = 'FYN';
        $address_invoice->firstname = $firstname;
        $address_invoice->lastname = $lastname;
        $address_invoice->id_state = $id_state;
        $address_invoice->address1 = isset($data['delivery_address']) ? $data['delivery_address'] : '';
        $address_invoice->address2 = '';
        $address_invoice->postcode = isset($data['delivery_postalcode']) ? $data['delivery_postalcode'] : '';
        $address_invoice->city = isset($data['delivery_city']) ? $data['delivery_city'] : '';
        if ($phone && Validate::isPhoneNumber($phone)) {
            $address_invoice->phone = $phone;
        }
        $address_invoice->add();
        $address_id_invoice = $address_invoice->id;

        $payment_module = Configuration::get('CEDFYNDIQ_ORDER_PAYMENT');
        $module_id = 0;
        $sql = 'SELECT DISTINCT m.`id_module`, h.`id_hook`, m.`name`, hm.`position` 
                FROM `' . _DB_PREFIX_ . 'module` m LEFT JOIN `' . _DB_PREFIX_ . 'hook_module` hm 
                ON hm.`id_module` = m.`id_module` LEFT JOIN `' . _DB_PREFIX_ . 'hook` h 
                ON hm.`id_hook` = h.`id_hook` GROUP BY hm.id_hook, hm.id_module 
                ORDER BY hm.`position`, m.`name` DESC';
        $modules_list = $db->executeS($sql);
        foreach ($modules_list as $module) {
            $module_obj = ModuleCore::getInstanceById($module['id_module']);
            if (isset($module_obj->name) && $module_obj->name == $payment_module) {
                $module_id = $module['id_module'];
                break;
            }
        }
        $context = (array)$contexts;
        $currency = isset($context['currency']) ? (array)$context['currency'] : array();

        if (Configuration::get('PS_CURRENCY_DEFAULT')) {
            $id_currency = Configuration::get('PS_CURRENCY_DEFAULT');
        } else {
            $id_currency = isset($currency['id']) ? $currency['id'] : '0';
        }

        if (!$id_currency) {
            $currency_id = $db->executeS('SELECT `id_currency` FROM `' . _DB_PREFIX_ . 'module_currency` WHERE `id_module` = ' . (int)$module_id);
            $id_currency = isset($currency_id['0']['id_currency']) ? $currency_id['0']['id_currency'] : 0;
        }

        $cart = new Cart();
        $cart->id_customer = $id_customer;
        $cart->id_address_delivery = $address_id_shipping;
        $cart->id_address_invoice = $address_id_invoice;
        $cart->id_currency = (int)$id_currency;
        $cart->id_carrier = (int)Configuration::get('CEDFYNDIQ_CARRIER_ID');
        $cart->recyclable = 0;
        $cart->gift = 0;
        $cart->add();
        $cart_id = (int)($cart->id);
        $order_total = 0;

        $final_shipping_cost = 0;
        $shipping_cost_vat = 0;

        $order_total += $final_shipping_cost;
        if (isset($data['order_rows'])
            && isset($data['order_rows'])
            && count($data['order_rows'])
        ) {
            if (!isset($data['order_rows']['0'])) {
                $temp_orderLine = $data['order_rows'];
                $data['order_rows'] = array();
                $data['order_rows']['0'] = $temp_orderLine;
            }
            $order_items = $data['order_rows'];
            $final_item_cost = 0;
            $total_vat = 0;
            $productArray = array();
            foreach ($order_items as $orderLine => $item) {
                $cancelQty = 0;
                $sku = isset($item['sku']) ? $item['sku'] : '';
                $fyndiqProductId = '';

                $id_product = $this->getProductIdByReference($sku); //$sku

                if (!$id_product) {
                    $id_product = $this->getVariantProductIdByReference($sku);
                }

                $id_product_attribute = $this->getProductAttributeIdByReference($sku); // $sku

                $qty = isset($item['quantity']) ? $item['quantity'] : '0';

                $context = Context::getContext();
                $context->cart = new Cart();
                $producToAdd = new Product(
                    $id_product,
                    true,
                    $id_lang,
                    (int)$context->shop->id,
                    $context
                );

                //$producToAdd = (array)new Product((int)($id_product), true, (int)($id_lang));
//echo '<pre>'; print_r($producToAdd); die;
                if (!$producToAdd->id) {
                    $this->orderErrorInformation(
                        $sku,
                        $fyndiq_order_id,
                        $data,
                        "PRODUCT ID" . $id_product . " DOES NOT EXIST",
                        $orderLine,
                        $sku,
                        $fyndiqProductId,
                        $cancelQty
                    );
                    //continue;
                    return false;
                }

                if (!$producToAdd->active) {
                    $this->orderErrorInformation(
                        $sku,
                        $fyndiq_order_id,
                        $data,
                        "PRODUCT STATUS IS DISABLED WITH ID " . $id_product . "",
                        $orderLine,
                        $sku,
                        $fyndiqProductId,
                        $cancelQty
                    );
                    //continue;
                    return false;
                }

                if (!$producToAdd->checkQty((int)$qty)) 
                {
                    $availableQuantity = StockAvailable::getQuantityAvailableByProduct($id_product, $id_product_attribute);
                    if ($qty > $availableQuantity) 
                    {
                        $this->orderErrorInformation(
                            $sku,
                            $fyndiq_order_id,
                            $data,
                            "REQUESTED QUANTITY FOR PRODUCT ID " . $id_product . " IS NOT AVAILABLE",
                            $orderLine,
                            $sku,
                            $fyndiqProductId,
                            $cancelQty
                        );
                        return false;
                    }
                    
                }

                if(!$cart->updateQty((int)($qty), (int)($id_product), (int)$id_product_attribute))
                {
                    $this->orderErrorInformation(
                        $sku,
                        $fyndiq_order_id,
                        $data,
                        "REQUESTED QUANTITY FOR PRODUCT ID " . $id_product . " CAN NOT UPDATE IN CART",
                        $orderLine,
                        $sku,
                        $fyndiqProductId,
                        $qty
                    );
                    return false;
                } else {
                    //$cart->updateQty((int)($qty), (int)($id_product), (int)$id_product_attribute);
                    $cart->update();
                }

                // $item_cost = isset($item['unit_price_amount']) ? (float)$item['unit_price_amount'] : 0;
                // $item_vat = isset($item['vat_percent']) ? (float)$item['vat_percent'] : 0;
                
                $item_cost = 0;
                $item_vat = 0;
                if(isset($item['unit_price_amount']) && ($item['unit_price_amount']) > 0)
                {
                    $item_cost = (float)$item['unit_price_amount'];
                    if(isset($item['vat_percent']) && ($item['vat_percent'] > 0))
                    {
                        $item_vat = (float)($item_cost * $item['vat_percent']) / 100;
                    }
                }

                $productArray[$id_product] = array(
                    'reference' => $sku,
                    'id_product' => $id_product,
                    'price_tax_included' => $item_cost,
                    'price_tax_excluded' => $item_cost - $item_vat,
                    'quantity' => $qty
                );
                $total_cost = $item_cost * (int)$qty;
                $total_vat += $item_vat * (int)$qty;
                $final_item_cost += (float)$total_cost;
            }
            $order_total += $final_item_cost;

            if (count($productArray)) {
                $extra_vars = array();
                $extra_vars['item_shipping_cost'] = $final_shipping_cost;
                $extra_vars['total_paid'] = $order_total;
                $extra_vars['total_item_cost'] = $final_item_cost;
                $extra_vars['total_item_tax'] = $total_vat;
                $extra_vars['item_shipping_tax'] = $shipping_cost_vat;
                $extra_vars['merchant_order_id'] = $fyndiq_order_id;
                $extra_vars['customer_reference_order_id'] = $data['id'];
                $secure_key = false;
                $id_shop = (int)Context::getContext()->shop->id;
                $shop = new Shop($id_shop);
            }
            
            if (!empty($productArray)) {
                $prestashop_order_id = $this->addOrderInPrestashop(
                    $cart_id,
                    $id_customer,
                    $address_id_shipping,
                    $address_id_invoice,
                    Configuration::get('CEDFYNDIQ_CARRIER_ID'),
                    $id_currency,
                    $extra_vars,
                    $productArray,
                    $secure_key,
                    $contexts,
                    $shop,
                    $payment_module
                );
                if (!empty($prestashop_order_id)) {
                    return $prestashop_order_id;
                }
            } else {
                return false;
            }
            return false;
        }
    }

    public function addOrderInPrestashop(
        $id_cart,
        $id_customer,
        $id_address_delivery,
        $id_address_invoice,
        $id_carrier,
        $id_currency,
        $extra_vars,
        $products,
        $secure_key,
        $context,
        $shop,
        $payment_module
    ) {
        $context->cart = new Cart($id_cart);
        $newOrder = new Order();
        $carrier = new Carrier($id_carrier, $context->cart->id_lang);
        $newOrder->id_address_delivery = $id_address_delivery;
        $newOrder->id_address_invoice = $id_address_invoice;
        $newOrder->id_shop_group = $shop->id_shop_group;
        $newOrder->id_shop = isset($shop->id) ? $shop->id: '';
        $newOrder->id_cart = $id_cart;
        $newOrder->id_currency = $id_currency;
        $newOrder->id_lang = $context->language->id;
        $newOrder->id_customer = $id_customer;
        $newOrder->id_carrier = $id_carrier;
        $newOrder->current_state = Configuration::get('CEDFYNDIQ_ORDER_STATE');
        $newOrder->secure_key = (
        $secure_key ? pSQL($secure_key) : pSQL($context->customer->secure_key)
        );
        //$newOrder->payment = $payment_module ? $payment_module : 'Cedfyndiq Payment';

        $newOrder->payment = 'Fyndiq';
        $newOrder->module = 'cedfyndiq';
        if(empty($context->currency->conversion_rate))
        {
            $newOrder->conversion_rate = '1';
        } else {
            $newOrder->conversion_rate = $context->currency->conversion_rate;
        }
        $newOrder->recyclable = $context->cart->recyclable;
        $newOrder->gift = (int)$context->cart->gift;
        $newOrder->gift_message = $context->cart->gift_message;
        $newOrder->mobile_theme = $context->cart->mobile_theme;
        $newOrder->total_discounts = 0;
        $newOrder->total_discounts_tax_incl = 0;
        $newOrder->total_discounts_tax_excl = 0;
        $newOrder->total_paid = $extra_vars['total_paid'];
        $newOrder->total_paid_tax_incl = $extra_vars['total_paid'];
        $newOrder->total_paid_tax_excl = $extra_vars['total_paid'];
        $newOrder->total_paid_real = $extra_vars['total_paid'];
        $newOrder->total_products = $extra_vars['total_item_cost'];
        $newOrder->total_products_wt = $extra_vars['total_item_cost'];
        $newOrder->total_shipping = $extra_vars['item_shipping_cost'];
        $newOrder->total_shipping_tax_incl = $extra_vars['item_shipping_cost'];
        $newOrder->total_shipping_tax_excl = $extra_vars['item_shipping_cost'] - $extra_vars['item_shipping_tax'];

        if (!is_null($carrier) && Validate::isLoadedObject($carrier)) {
            $newOrder->carrier_tax_rate = $carrier->getTaxesRate(
                new Address($context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')})
            );
        }
        $newOrder->total_wrapping = 0;
        $newOrder->total_wrapping_tax_incl = 0;
        $newOrder->total_wrapping_tax_excl = 0;
        $newOrder->invoice_date = '0000-00-00 00:00:00';
        $newOrder->delivery_date = '0000-00-00 00:00:00';
        $newOrder->valid = true;
        do {
            $reference = Order::generateReference();
        } while (Order::getByReference($reference)->count());
        $newOrder->reference = $reference;
        $newOrder->round_mode = Configuration::get('PS_PRICE_ROUND_MODE');
        $packageList = $context->cart->getProducts(true);
        foreach ($packageList as &$product) {
            if (array_key_exists($product['id_product'], $products)) {
                $product['price'] = $products[$product['id_product']]['price_tax_excluded'];
                $product['price_wt'] = $products[$product['id_product']]['price_tax_included'];
                $product['total'] = $products[$product['id_product']]['price_tax_excluded'] *
                    $products[$product['id_product']]['quantity'];
                $product['total_wt'] = $products[$product['id_product']]['price_tax_included'] *
                    $products[$product['id_product']]['quantity'];
            }
        }
        $orderItems = $packageList;
        $newOrder->product_list = $orderItems;

        $res = $newOrder->add(true, false);

        if (!$res) {
            PrestaShopLogger::addLog(
                'Order cannot be created',
                3,
                null,
                'Cart',
                (int)$id_cart,
                true
            );
            throw new PrestaShopException('Can\'t add Order');
        }
        if ($newOrder->id_carrier) {
            $newOrderCarrier = new OrderCarrier();
            $newOrderCarrier->id_order = (int)$newOrder->id;
            $newOrderCarrier->id_carrier = (int)$newOrder->id_carrier;
            $newOrderCarrier->weight = (float)$newOrder->getTotalWeight();
            $newOrderCarrier->shipping_cost_tax_excl = $newOrder->total_shipping_tax_excl;
            $newOrderCarrier->shipping_cost_tax_incl = $newOrder->total_shipping_tax_incl;
            $newOrderCarrier->add();
        }

        if (isset($newOrder->product_list) && count($newOrder->product_list)) {
            foreach ($newOrder->product_list as $productLine) {
                $order_detail = new OrderDetail();
                $order_detail->id_order = (int)$newOrder->id;
                $order_detail->id_order_invoice = $productLine['id_address_delivery'];
                $order_detail->product_id = $productLine['id_product'];
                $order_detail->id_shop = $productLine['id_shop'];
                $order_detail->id_warehouse = 0;
                $order_detail->product_attribute_id = $productLine['id_product_attribute'];
                $order_detail->product_name = $productLine['name'];
                $order_detail->product_quantity = $productLine['cart_quantity'];
                $order_detail->product_quantity_in_stock = $productLine['quantity_available'];
                $order_detail->product_price = $productLine['price'];
                $order_detail->unit_price_tax_incl = $productLine['price_wt'];
                $order_detail->unit_price_tax_excl = $productLine['price'];
                $order_detail->total_price_tax_incl = $productLine['total_wt'];
                $order_detail->total_price_tax_excl = $productLine['total'];
                $order_detail->product_ean13 = $productLine['ean13'];
                $order_detail->product_upc = $productLine['upc'];
                $order_detail->product_reference = $productLine['reference'];
                $order_detail->product_supplier_reference = $productLine['supplier_reference'];
                $order_detail->product_weight = $productLine['weight'];
                $order_detail->ecotax = $productLine['ecotax'];
                $order_detail->discount_quantity_applied = $productLine['quantity_discount_applies'];
                $o_res = $order_detail->add();
                if (!$o_res) {
                    $newOrder->delete();
                    PrestaShopLogger::addLog(
                        'Order details cannot be created',
                        3,
                        null,
                        'Cart',
                        (int)$id_cart,
                        true
                    );
                    throw new PrestaShopException('Can\'t add Order details');
                }
            }
            Hook::exec(
                'actionValidateOrder',
                array(
                    'cart' => $context->cart,
                    'order' => $newOrder,
                    'customer' => $context->customer,
                    'currency' => $context->currency,
                    'orderStatus' => Configuration::get('CEDFYNDIQ_ORDER_STATE')
                )
            );

            $order_status = new OrderState(
                (int)Configuration::get('CEDFYNDIQ_ORDER_STATE'),
                (int)$context->language->id
            );
            foreach ($context->cart->getProducts() as $cproduct) {
                if ($order_status->logable) {
                    ProductSale::addProductSale(
                        (int)$cproduct['id_product'],
                        (int)$cproduct['cart_quantity']
                    );
                }
            }

            // Set the order status
            $new_history = new OrderHistory();
            $new_history->id_order = (int)$newOrder->id;
            $new_history->changeIdOrderState((int)Configuration::get('CEDFYNDIQ_ORDER_STATE'), $newOrder, true);
            $new_history->add(true, $extra_vars);

            // Switch to back order if needed
            if (Configuration::get('PS_STOCK_MANAGEMENT') && $order_detail->getStockState()) {
                $history = new OrderHistory();
                $history->id_order = (int)$newOrder->id;
                $history->changeIdOrderState(
                    Configuration::get(
                        $newOrder->valid ? 'PS_OS_OUTOFSTOCK_PAID' : 'PS_OS_OUTOFSTOCK_UNPAID'
                    ),
                    $newOrder,
                    true
                );
                $history->add();
            }

            // Order is reloaded because the status just changed

            // Send an e-mail to customer (one order = one email)

            //  updates stock in shops
            $product_list = $newOrder->getProducts();
            foreach ($product_list as $eproduct) {
                $idProd = $eproduct['product_id'];
                $idProdAttr = $eproduct['product_attribute_id'];
                $qtyToReduce = (int)$eproduct['product_quantity']*-1;
                StockAvailable::updateQuantity($idProd, $idProdAttr, $qtyToReduce, $newOrder->id_shop);
            }
            if (isset($newOrder->id) && $newOrder->id) {
                return $newOrder->id;
            }
        }
        return false;
    }

    public function orderErrorInformation(
        $sku,
        $fyndiq_order_id,
        $worder_data,
        $errormessage,
        $orderLine,
        $fyndiqSkuId,
        $fyndiqProductId,
        $cancelQty
    ) {
        if ($orderLine) {
            $db = Db::getInstance();
        } else {
            $db = Db::getInstance();
        }
        $sql_check_already_exists = "SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_order_error` 
        WHERE `merchant_sku`='" . pSQL($sku) . "' 
        AND `fyndiq_order_id`='" . pSQL($fyndiq_order_id) . "'";
        $Execute_check_already_exists = $db->ExecuteS($sql_check_already_exists);
        if (count($Execute_check_already_exists) == 0) {
            $result = $db->insert(
                'fyndiq_order_error',
                array(
                    'merchant_sku' => pSQL($sku),
                    'fyndiq_order_id' => pSQL($fyndiq_order_id),
                    'order_data' => pSQL(Tools::jsonEncode($worder_data)),
                    'reason' => pSQL($errormessage),
                    'cancel_qty' => (int)($cancelQty),
                )
            );
            if ($result) {
                if (Configuration::get('CEDFYNDIQ_AUTO_ORDER_PROCESS')) {
                    $this->cancelOrderByFyndiqId(
                        $fyndiq_order_id,
                        $cancelQty,
                        $fyndiqSkuId,
                        $fyndiqProductId,
                        '',
                        '',
                        'out_of_stock'
                    );
                }
            }
        }
    }

    public function isFyndiqOrderIdExist($fyndiq_order_id = 0, $data = array())
    {
        $db = Db::getInstance();
        $isExist = false;
        if ($fyndiq_order_id) {
            $sql = "SELECT `id`, `prestashop_order_id` FROM `" . _DB_PREFIX_ . "fyndiq_order` 
            WHERE `fyndiq_order_id` = '" . pSQL($fyndiq_order_id) . "'";
            $result = $db->ExecuteS($sql);
            if (is_array($result) && count($result)) {
                $isExist = true;
                
                if(isset($data['marked']) && ($data['marked'] == true))
                {
                    if(Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED'))
                    {
                        $id_order_state = Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED');
                        $id_lang = ((int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'))?
                            (int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'):
                            (int) Configuration::get('PS_LANG_DEFAULT');
                        $order_status = $db->getValue("SELECT `name` FROM `"._DB_PREFIX_."order_state_lang` WHERE `id_order_state` = '". (int) $id_order_state ."' AND `id_lang` = '".(int)$id_lang."'");
                        $db->update(
                            'fyndiq_order',
                            array(
                                'status' => pSQL($order_status)
                            ),
                            'id="'. (int) $result['0']['id'] .'"'
                        );
                        $this->updateOrderStatus($result['0']['prestashop_order_id'], $id_order_state);
                    }
                }

            }
        }
        return $isExist;
    }

    public function getLocalizationDetails($country_code)
    {
        $db = Db::getInstance();
        $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');

        $sql = "SELECT cl.`id_country`, cl.`name` FROM `" . _DB_PREFIX_ . "country` AS c LEFT JOIN `" . _DB_PREFIX_ . "country_lang` AS cl ON (c.`id_country` = cl.`id_country`) WHERE c.`iso_code` = '" . pSQL($country_code) . "' AND cl.`id_lang` ='" . (int)$default_lang . "'";
        $Execute = $db->ExecuteS($sql);
        if (is_array($Execute) && count($Execute) && isset($Execute['0'])) {
            $country_id = 0;
            $country_name = '';
            if (isset($Execute['0']['id_country']) && $Execute['0']['id_country']) {
                $country_id = $Execute['0']['id_country'];
                $country_name = $Execute['0']['name'];
            }
            if($country_id){
                return array(
                  'country_id' => $country_id,
                  'country_name' => $country_name
                );
            } else {
                return array(
                    'country_id' => '',
                    'country_name' => $country_name
                );
            }
        } else {
            return array(
                'country_id' => '',
                'country_name' => ''
            );
        }
    }

    public static function getProductIdByReference($merchant_sku)
    {
        $db = Db::getInstance();
        return $db->getValue(
            'Select `id_product` FROM `' . _DB_PREFIX_ . 'product` 
            WHERE `reference`="' . pSQL($merchant_sku) . '"'
        );
    }

    public static function getVariantProductIdByReference($merchant_sku)
    {
        $db = Db::getInstance();
        return $db->getValue(
            'Select `id_product` FROM `' . _DB_PREFIX_ . 'product_attribute` 
            WHERE `reference`="' . pSQL($merchant_sku) . '"'
        );
    }

    public static function getProductAttributeIdByReference($merchant_sku)
    {
        $db = Db::getInstance();
        return $db->getValue(
            'SELECT `id_product_attribute` FROM `' . _DB_PREFIX_ . 'product_attribute` 
            WHERE `reference`="' . pSQL($merchant_sku) . '"'
        );
    }

    public function updateOrderStatus($order_id, $id_order_state)
    {
        $cedFyndiqHelper = new CedfyndiqHelper;
        try {
            $order_state = new OrderState($id_order_state);
            $order = new Order((int)$order_id);
            $history = new OrderHistory();
            $history->id_order = $order->id;
            $use_existings_payment = !$order->hasInvoice();
            $history->changeIdOrderState((int)$order_state->id, (int)$order_id, $use_existings_payment);
            if (Configuration::get('PS_ADVANCED_STOCK_MANAGEMENT')) {
                foreach ($order->getProducts() as $product) {
                    if (StockAvailable::dependsOnStock($product['product_id'])) {
                        StockAvailable::synchronize($product['product_id'], (int)$product['id_shop']);
                    }
                }
            }
        } catch (\Exception $e) {
            $cedFyndiqHelper->log(
                'CedfyndiqOrder::updateOrderStatus',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
}
