<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

class CedfyndiqCategory extends ObjectModel
{
    public static $definition = array(
        'table'     => 'fyndiq_category_list',
        'primary'   => 'id',
        'multilang' => false,
        'fields'    => array(
            'id'  => array('type' => self::TYPE_INT, 'validate' => 'isInt'),
            'category_id'  => array('type' => self::TYPE_INT, 'validate' => 'isInt'),
            'name_sv' => array('type' => self::TYPE_STRING,  'db_type' => 'text'),
            'name_de' => array('type' => self::TYPE_STRING,  'db_type' => 'text'),
            'path' => array('type' => self::TYPE_STRING,  'db_type' => 'text'),
            'url' => array('type' => self::TYPE_STRING,  'db_type' => 'text'),
            'parent_id'  => array('type' => self::TYPE_INT, 'validate' => 'isInt'),
            'mapped_categories' => array('type' => self::TYPE_STRING,  'db_type' => 'text'),
        ),
    );
 
    public $id;
    public $category_id;
    public $name;
    public $path;
    public $url;
    public $parent_id;

    public function insertCategory($categories)
    {
        $response = array();
        $db = Db::getInstance();
        if(isset($categories) && is_array($categories) && $categories)
        {
            $category_chunks = array_chunk($categories, 500);
            if(count($category_chunks) > 0)
            {
                foreach($category_chunks as $category_chunk)
                {
                    foreach($category_chunk as $key => $category)
                    {
                        $category_id = $db->getValue("SELECT `id` FROM `". _DB_PREFIX_ ."fyndiq_category_list` WHERE `category_id` = '". (int) $category['id'] ."' ");

                        if($category_id)
                        {
                            $db->update('fyndiq_category_list',
                                array(
                                    'category_id' => (int) $category['id'],
                                    'name_sv' => html_entity_decode(pSQL($category['path']['sv']), ENT_QUOTES, 'UTF-8'),
                                    'name_de' => html_entity_decode(pSQL($category['path']['de']),ENT_QUOTES, 'UTF-8'),
                                    'cat_name_sv' => html_entity_decode(pSQL($category['name']['sv']), ENT_QUOTES, 'UTF-8'),
                                    'cat_name_de' => html_entity_decode(pSQL($category['name']['de']),ENT_QUOTES, 'UTF-8'),
                                    'parent_id' => (int) $category['parent_id'],
                                ),
                                '`category_id` = "'. (int) $category['id'] .'"'
                            );
                        } else {
                            $db->insert('fyndiq_category_list',
                                array(
                                    'category_id' => (int) $category['id'],
                                    'name_sv' => html_entity_decode(pSQL($category['path']['sv']), ENT_QUOTES, 'UTF-8'),
                                    'name_de' => html_entity_decode(pSQL($category['path']['de']),ENT_QUOTES, 'UTF-8'),
                                    'cat_name_sv' => html_entity_decode(pSQL($category['name']['sv']), ENT_QUOTES, 'UTF-8'),
                                    'cat_name_de' => html_entity_decode(pSQL($category['name']['de']),ENT_QUOTES, 'UTF-8'),
                                    'parent_id' => (int) $category['parent_id'],
                                )
                            );
                        }
                    }
                }
            }
            $response = array('success' => true, 'message' => 'Categories fetched successfully!');
        } else {
            $response = array('success' => false, 'message' => 'Categories not found!');
        }
        return $response;
    }
}
