<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

require_once _PS_MODULE_DIR_ . 'cedfyndiq/classes/CedfyndiqHelper.php';

class CedfyndiqProduct
{
    public function uploadProducts($product_ids = array())
    {
        $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');

        $db = Db::getInstance();
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }

        $all_product_ids = array_chunk($product_ids, 1000);
        foreach ($all_product_ids as $product_ids)
        {
            $product_to_upload = array();
            $product_error = array();
            foreach ($product_ids as $product_id)
            {
                $fyndiq_data = array();
                //$productObject = new Product($product_id, false, $default_lang);
                $context = Context::getContext();
                $context->cart = new Cart();
                $productObject = new Product(
                    $product_id,
                    true,
                    $default_lang,
                    (int)$context->shop->id,
                    $context
                );
//echo '<pre>'; print_r($productObject); die;
                $pricewithVat = $productObject::getPriceStatic(
                    $product_id,
                    true,
                    null,
                    2,
                    null,
                    false,
                    false,
                    1,
                    true,
                    null,
                    null,
                    null
                );

                $pricewithoutVat = $productObject::getPriceStatic(
                    $product_id,
                    true,
                    null,
                    2,
                    null,
                    false,
                    true,
                    1,
                    true,
                    null,
                    null,
                    null
                );

                $disabled_product_upload = Configuration::get('CEDFYNDIQ_UPLOAD_DISABLE_PRODUCT');

                $product_status = $productObject->active;
                if (!$product_status && !$disabled_product_upload) {
                    $product_error[$product_id] = 'Product :' . $product_id . ' is disabled.';
                    continue;
                }

                $fyndiqProductstatus = $db->getValue(
                    "SELECT `fyndiq_status` FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$product_id . "'"
                );

                if($fyndiqProductstatus == 'Excluded')
                {
                    $product_error[$product_id] = 'Product :' . $product_id . ' is excluded.';
                    continue;
                }

                $product = (array)new Product($product_id, true, $default_lang);
                $fyndiq_product = $this->getFyndiqProduct($product_id);

                $fyndiq_product = array_filter($fyndiq_product);
                if(isset($fyndiq_product['id_product']) && !empty($fyndiq_product['id_product'])) {
                    $fyndiq_product['product-id'] = $fyndiq_product['id_product'];
                    unset($fyndiq_product['id_product']);
                }

                // Default Values
                $default_values = $this->getSavedDefaultValues();

                // Brand
                if(isset($default_values['product-brand-name']) && !empty($default_values['product-brand-name']))
                {
                    $default_values['product-brand-name'] = trim($default_values['product-brand-name']);
                    if(strlen($default_values['product-brand-name']) > '32')
                    {
                        $default_values['product-brand-name'] = substr($default_values['product-brand-name'], 0, 31);
                    }
                }

                if ($productObject->getAttributeCombinations($default_lang)) {
                    $mapped_values = $this->getMappingValues($product_id, $product, $pricewithVat, $pricewithoutVat, false);
                } else {
                    $mapped_values = $this->getMappingValues($product_id, $product, $pricewithVat, $pricewithoutVat);
                }

                // Brand;
                if(isset($mapped_values['product-brand-name']) && !empty($mapped_values['product-brand-name']))
                {
                    $mapped_values['product-brand-name'] = trim($mapped_values['product-brand-name']);
                    if(strlen($mapped_values['product-brand-name']) > '32'){
                        $mapped_values['product-brand-name'] = substr($mapped_values['product-brand-name'], 0, 31);
                    }
                }

                // Title
                if(isset($mapped_values['product-title']) && !empty($mapped_values['product-title']))
                {
                    $mapped_values['product-title'] = trim($mapped_values['product-title']);
                    if(strlen($mapped_values['product-title']) > '64'){
                        $mapped_values['product-title'] = substr($mapped_values['product-title'], 0, 63);
                    }
                }


                $category = $this->getFyndiqCategory($product_id);

                foreach ($default_values as $valKey => $value) {
                    if (isset($mapped_values[$valKey]) && empty(($mapped_values[$valKey]))) {
                        $mapped_values[$valKey] = $value;
                    }
                }

                if(isset($default_values['product-paused']) && ($default_values['product-paused'] == '1'))
                    $mapped_values['product-paused'] = $default_values['product-paused'];
                else
                    $mapped_values['product-paused'] = '0';

                if (!isset($mapped_values['product-vat-percent'])
                    || empty($mapped_values['product-vat-percent'])
                    || $mapped_values['product-vat-percent'] == '0')
                {
                    $mapped_values['product-vat-percent'] = '0';
                }

                if(isset($default_values['product-market']) && !empty($default_values['product-market']))
                {
                    $mapped_values['product-market'] = $default_values['product-market'];
                }

                if(empty($default_values['product-currency']))
                    $mapped_values['product-currency'] = $default_values['product-currency'];


                if($default_values['product-oldprice'] > '0')
                    $mapped_values['product-oldprice'] = $default_values['product-oldprice'];

                if(empty($default_values['product-portion']))
                    $mapped_values['product-portion'] = $default_values['product-portion'];

                $mapped_values['product-comparison-unit'] = $default_values['product-comparison-unit'];

                if(empty($mapped_values['article-location']))
                    $mapped_values['article-location'] = $default_values['article-location'];

                $mapped_values['article-eu-energy-class'] = $default_values['article-eu-energy-class'];
                $mapped_values['article-eu-energy-label-url'] = $default_values['article-eu-energy-label-url'];
                $mapped_values['article-eu-energy-datasheet-url'] = $default_values['article-eu-energy-datasheet-url'];

                // article property
                if($productObject->getAttributeCombinations($default_lang)) {
                    $attribute_properties = $this->getAttributeProperty($mapped_values, $product_id);
                }

                $fyndiq_data = array_merge($mapped_values, array_filter($fyndiq_product));

                if (isset($product['reference']) && $product['reference']) {
                    $fyndiq_data['article-sku'] = $product['reference'];
                }

                if ($category) {
                    $fyndiq_data['product-category-id'] = $category['store-category-id'];
                    $fyndiq_data['product-category-name'] = $category['store-category-name'];
                    $fyndiq_data['product-category-fyndiq-id'] = $category['fyndiq-category-id'];
                } else {
                    $fyndiq_data['product-category-id'] = '';
                    $fyndiq_data['product-category-name'] = '';
                    $fyndiq_data['product-category-fyndiq-id'] = '';
                }

                if ($product_id) {
                    $fyndiq_data['product-id'] = $product_id;
                }

                if (isset($product['reference']) && $product['reference']) {
                    $fyndiq_data['article-sku'] = $product['reference'];
                }else {
                    $fyndiq_data['article-sku'] = '';
                }

                $images = $this->productImageUrls($product_id);

                if (isset($images['mainImageUrl']) && !empty($images['mainImageUrl'])) {
                    $fyndiq_data['product-image-1-url'] = $images['mainImageUrl'];
                    $fyndiq_data['product-image-1-identifier'] = basename($images['mainImageUrl']);
                    if(strlen($fyndiq_data['product-image-1-identifier']) > '42')
                    {
                        $fyndiq_data['product-image-1-identifier'] = substr($fyndiq_data['product-image-1-identifier'], 0, 41);
                    }
                }
                if (isset($images['productSecondaryImageURL']) && !empty($images['productSecondaryImageURL'])) {
                    $secondaryImageURLs = $images['productSecondaryImageURL'];
                    if (count($secondaryImageURLs)) {
                        $i = 2;
                        foreach ($secondaryImageURLs as $secondaryImageURL) {
                            if ($i <= 30) {
                                $fyndiq_data['product-image-' . $i . '-url'] = $secondaryImageURL;
                                $fyndiq_data['product-image-' . $i . '-identifier'] = basename($secondaryImageURL);
                                if(strlen($fyndiq_data['product-image-' . $i . '-identifier']) > '42')
                                {
                                    $fyndiq_data['product-image-' . $i . '-identifier'] = substr($fyndiq_data['product-image-' . $i . '-identifier'], 0, 41);
                                }
                                $i++;
                            } else {
                                break;
                            }
                        }
                    }
                }

                for ($i = 2; $i <= 30; $i++) {
                    if (!isset($fyndiq_data['product-image-' . $i . '-url'])) {
                        $fyndiq_data['product-image-' . $i . '-url'] = '';
                        $fyndiq_data['product-image-' . $i . '-identifier'] = '';
                    }
                }

                foreach ($default_values as $ky => $value) {
                    if ((!isset($fyndiq_data[trim($ky)])) || (isset($fyndiq_data[trim($ky)])
                            && ($fyndiq_data[trim($ky)] == ''))) {
                        if ($value) {
                            $fyndiq_data[trim($ky)] = $value;
                        }
                    }
                }

                if (isset($fyndiq_data['product-description']) && $fyndiq_data['product-description']) {
                    $fyndiq_data['product-description'] = $fyndiq_data['product-description'];
                } else {
                    $fyndiq_data['product-description'] = strip_tags($fyndiq_data['article-name']);
                }

                if(strlen($fyndiq_data['product-description']) > '4096')
                {
                    $fyndiq_data['product-description'] = substr($fyndiq_data['product-description'], 0, 4095);
                }

                if(strlen($fyndiq_data['article-name']) > '30')
                {
                    $fyndiq_data['article-name'] = substr($fyndiq_data['article-name'], 0, 29);
                    //$fyndiq_data['article-name'] =  utf8_decode($fyndiq_data['article-name']);
                }

                $k = '1';
                foreach($fyndiq_data as $key => $value)
                {
                    unset($fyndiq_data['article-property-'. $k .'-name']);
                    unset($fyndiq_data['article-property-'. $k .'-value']);
                    unset($fyndiq_data['article-property-n-name']);
                    unset($fyndiq_data['article-property-n-value']);
                    $k++;
                }

                // article-property
                if($productObject->getAttributeCombinations($default_lang))
                {
                    if(isset($attribute_properties) && is_array($attribute_properties) && $attribute_properties)
                    {
                        $product_combinations=array();
                        $temp_array = array();
                        $i=1;
                        foreach($attribute_properties as $index => $val)
                        {
                            $count = '1';
                            $article_name = '';
                            foreach($val as $optKey => $value)
                            {

                                if(isset($value['article-property-' .$count.'-name']) &&
                                    !empty($value['article-property-' .$count.'-name']) &&
                                    isset($value['article-property-' .$count.'-value']) &&
                                    !empty($value['article-property-' .$count.'-value']))
                                {
                                    $article_name .= $value['article-property-' .$count.'-name'] . ': ' . $value['article-property-' .$count.'-value'] . ', ';
                                    $product_combinations['article-sku'] = $value['reference'];
                                    $product_combinations['article-quantity'] = (int) $value['quantity'];
                                    $product_combinations['article-property-' .$count.'-name'] = $value['article-property-' .$count.'-name'];
                                    $product_combinations['article-property-' .$count.'-value'] = $value['article-property-' .$count.'-value'];

                                }
                                $count++;
                            }

                            if(!empty($article_name))
                            {
                                $article_name = rtrim($article_name, ', ');
                                if(strlen($article_name > '30'))
                                {
                                    $product_combinations['article-name'] = substr($article_name, 0, 29);
                                }
                            }

                            $temp_array[] = array_merge($fyndiq_data, $product_combinations);

                            $i++;
                        }
                        $fyndiq_data = $temp_array;
                    }
                }

                // article-property
                // if($productObject->getAttributeCombinations($default_lang))
                // {
                //     if(isset($attribute_properties) && is_array($attribute_properties) && $attribute_properties)
                //     {
                //         $product_combinations=array();
                //         $temp_array = array();
                //         $i=1;
                //         foreach($attribute_properties as $index => $val)
                //         {
                //             $count = '1';
                //             $article_name = '';
                //             foreach($val as $optKey => $value)
                //             {

                //                 $colord = $this->getMappedVariationValue($value['id_attribute'],$value['id_attribute_group']);
                //                 if(isset($value['article-property-' .$count.'-name']) &&
                //                     !empty($value['article-property-' .$count.'-name']) &&
                //                     isset($value['article-property-' .$count.'-value']) &&
                //                     !empty($value['article-property-' .$count.'-value']) )
                //                 {

                //                     $product_combinations['article-sku'] = $value['reference'];
                //                     $product_combinations['article-quantity'] = $value['quantity'];

                //                     if(isset($colord)  && !empty($colord)  && is_array($colord))
                //                     {
                //                         $article_name .= $value['article-property-' .$count.'-name'] . ': ' . $colord['color'] . ', ';
                //                         $product_combinations['article-property-' .$count.'-name'] = $value['article-property-' .$count.'-name'];
                //                         $product_combinations['article-property-' .$count.'-value'] = $colord['color'];
                //                     } else {
                //                         $article_name .= $value['article-property-' .$count.'-name'] . ': ' . $value['article-property-' .$count.'-value'] . ', ';
                //                         $product_combinations['article-property-' .$count.'-name'] = $value['article-property-' .$count.'-name'];
                //                         $product_combinations['article-property-' .$count.'-value'] = $value['article-property-' .$count.'-value'];
                //                     }

                //                 }
                //                 $count++;
                //             }

                //             if(!empty($article_name))
                //             {
                //                 $article_name = rtrim($article_name, ', ');
                //                 if(strlen($article_name > '30'))
                //                 {
                //                     $product_combinations['article-name'] = substr($article_name, 0, 29);
                //                 }
                //             }

                //             $temp_array[] = array_merge($fyndiq_data, $product_combinations);
                //             $i++;
                //         }
                //         $fyndiq_data = $temp_array;
                //     }
                // }
//                echo '<pre>'; print_r($fyndiq_data); die;
                if(isset($fyndiq_data['0']))
                {
                    $error = '';
                    $variant_error = array();
                    foreach ($fyndiq_data as $value)
                    {
                        $ProductId = '';
                        if (isset($value['product-id'])) {
                            $ProductId = $value['product-id'];
                        }
                        $result = $this->validateProduct($value);

                        if (isset($result['error']) && !empty($result['error']))
                        {
                            $error .= $value['article-sku'] . ' : ' . $result['error'];
                            $variant_error[$value['article-sku']] = $result['error'];
                        } else {
                            $product_to_upload[] = $value;
                            $db->Execute("UPDATE `" . _DB_PREFIX_ . "fyndiq_product_variations` SET `error_message` ='' WHERE `product_id`='" . (int)$ProductId . "' AND `sku`='" . pSQL($value['article-sku']) . "'");
                            $db->Execute("UPDATE `" . _DB_PREFIX_ . "fyndiq_products` SET `error_message` ='' WHERE `product_id`='" . (int)$value['product-id'] . "'");
                        }
                    }
                    if ($error) {
                        $product_error[$product_id] = $error;
                    } else {
                        $product_error[$product_id] = '';
                    }

                    $this->saveProductVariants($fyndiq_data, $product_id, $variant_error);
                } else {
                    $result = $this->validateProduct($fyndiq_data);

                    if (isset($result['error']) && !empty($result['error']))
                    {
                        $product_error[$product_id] = $fyndiq_data['article-sku'] . ' : ' . $result['error'];
                    } else {
                        $product_to_upload[] = $fyndiq_data;
                        $db->getInstance()->Execute("UPDATE `" . _DB_PREFIX_ . "fyndiq_products` SET `error_message` ='' WHERE `product_id`='" . (int)$fyndiq_data['product-id'] . "'");
                    }
                }

            }

            $response = array();
            if (isset($product_error) && !empty($product_error)) {
                $product_error = array_filter($product_error);
                $response['error'] = $product_error;
                $this->processUploadError($product_error);
            }
            if (!empty($product_to_upload)) {
                $result = $this->processUploadData($product_to_upload);
                if(isset($result['success']) && $result['success'] == true)
                {
                    $response['success'] = $result['message'];
                } else {
                    $response['error'] = $result['message'];
                }
            }
            return $response;
        }
    }

    public function getAttributeProperty($mapped_values, $product_id)
    {
        $response = array();

        $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');

        $productObject = new Product($product_id, false, $default_lang);
        $combinations = $productObject->getAttributeCombinations($default_lang);
        $k = 1;
        foreach($mapped_values as $key => $mapped_val)
        {
            if(isset($mapped_values['article-property-'.$k.'-name']) &&
                $mapped_values['article-property-'.$k.'-name'] &&
                isset($mapped_values['article-property-'.$k.'-value']) &&
                $mapped_values['article-property-'.$k.'-value'])
            {
                $article_name = 'article-property-' . $k . '-name';
                $article_value = 'article-property-' . $k . '-value';

                $i = 1;

                $mapped_key_array = array_keys($mapped_values);
                foreach($mapped_key_array as $key => $mapped_keys)
                {
                    if($mapped_keys == $article_name)
                    {
                        $count = 1;
                        foreach($combinations as $key => $combination)
                        {
                            if(isset($mapped_values[$article_name]) && !empty($mapped_values[$article_name]) &&
                                in_array($combination['id_attribute_group'], $mapped_values[$article_name]))
                            {
                                if(isset($mapped_values[$article_value]) && !empty($mapped_values[$article_value]) && in_array($combination['id_attribute'], $mapped_values[$article_value]))
                                {
                                    if($count==1 && isset($response[$combination['id_product_attribute']]))
                                    {
                                        $count++;
                                    }
                                    $response[$combination['id_product_attribute']][] = array(
                                        'reference' => $combination['reference'],
                                        'quantity' => $combination['quantity'],
                                        'id_product_attribute' => $combination['id_product_attribute'],
                                        'id_attribute_group'=>$combination['id_attribute_group'],
                                        'id_attribute'=>$combination['id_attribute'],
                                        'article-property-' . $count . '-name' => $combination['group_name'],
                                        'article-property-' . $count . '-value' => $combination['attribute_name'],
                                    );
                                    // $count++;
                                }
                                else
                                {
                                    if($count==1 && isset($response[$combination['id_product_attribute']]))
                                    {
                                        $count++;
                                    }
                                    $response[$combination['id_product_attribute']][] = array(
                                        'reference' => $combination['reference'],
                                        'quantity' => $combination['quantity'],
                                        'id_product_attribute' => $combination['id_product_attribute'],
                                        'id_attribute_group'=>$combination['id_attribute_group'],
                                        'id_attribute'=>$combination['id_attribute'],
                                        'article-property-' . $count . '-name' => $combination['group_name'],
                                        'article-property-' . $count . '-value' => $combination['attribute_name'],
                                    );
                                }
                            }
                            $i++;
                        }

                    }
                }
            }
            $k++;

        }
        return $response;
    }

//    public function getAttributeProperty($mapped_values, $product_id)
//    {
//        $response = array();
//
//        $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ?
//            (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') :
//            (int)Configuration::get('PS_LANG_DEFAULT');
//
//        $productObject = new Product($product_id, false, $default_lang);
//        $combinations = $productObject->getAttributeCombinations($default_lang);
//        $k = 1;
//        foreach($mapped_values as $key => $mapped_val)
//        {
//            if(isset($mapped_values['article-property-'.$k.'-name']) &&
//                $mapped_values['article-property-'.$k.'-name'] &&
//                isset($mapped_values['article-property-'.$k.'-value']) &&
//                $mapped_values['article-property-'.$k.'-value'])
//            {
//                $article_name = 'article-property-' . $k . '-name';
//                $article_value = 'article-property-' . $k . '-value';
//
//                $i = 1;
//
//                $mapped_key_array = array_keys($mapped_values);
//                foreach($mapped_key_array as $key => $mapped_keys)
//                {
//                    if($mapped_keys == $article_name)
//                    {
//                        $count = 1;
//                        foreach($combinations as $key => $combination)
//                        {
//                            if(isset($mapped_values[$article_name]) && !empty($mapped_values[$article_name]) && in_array($combination['id_attribute_group'], $mapped_values[$article_name]))
//                            {
//                                if(isset($mapped_values[$article_value]) && !empty($mapped_values[$article_value]) && in_array($combination['id_attribute'], $mapped_values[$article_value]))
//                                {
//                                    if($count==1 && isset($response[$combination['id_product_attribute']]))
//                                    {
//                                        $count++;
//                                    }
//                                    $response[$combination['id_product_attribute']][] = array(
//                                        'reference'=>$combination['reference'],
//                                        'quantity'=>$combination['quantity'],
//                                        'article-property-'.$count.'-name' => $combination['group_name'],
//                                        'article-property-'.$count.'-value' => $combination['attribute_name']
//                                    );
//                                    // $count++;
//                                }
//                            }
//                            $i++;
//                        }
//
//                    }
//                }
//            }
//            $k++;
//
//        }
//
//        return $response;
//    }

    public function getFyndiqProduct($product_id)
    {
        $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $product = $db->executeS('SELECT `attributes` FROM `' . _DB_PREFIX_ . 'fyndiq_products` 
        WHERE `product_id`="' . (int)$product_id . '"');
        if (isset($product['0']['attributes']) && $product['0']['attributes']) {
            return unserialize($product['0']['attributes']);
        }
        return array();
    }

    public function getMappingValues($product_id, $product, $pricewithVat, $pricewithoutVat, $mapped_attribute_id = true)
    {
        $mapped_values = array();
        $result = $this->getMappedAttributes();
//        echo '<pre>'; print_r($result); die;
        if ($product_id && count($result)) {
            foreach ($result as $key => $value) {

                $attr_val = '';
                $vals = array();

                if (is_array($value)) {
                    foreach ($value as $val) {
                        $mapped_expresion = explode('-', $val);

                        $attr_val = '';
                        if (isset($mapped_expresion['0'])
                            && in_array($mapped_expresion['0'], array('system', 'attribute', 'feature'))) {
                            $attr_type = $mapped_expresion['0'];
                            $attribute_id = str_replace($attr_type . '-', "", $val);

                            switch ($attr_type) {
                                case 'attribute':
                                    if ($mapped_attribute_id) {
                                        $attr_val = $this->getAttributeValue($attribute_id, $product_id);

                                    } else {
                                        $attr_val = $attribute_id;
                                    }

                                    break;
                                case 'feature':
                                    $attr_val = $this->getFeatureValue($attribute_id, $product_id);
                                    break;
                                case 'system':
                                    $attr_val = $this->getSystemValue($attribute_id, $product);
                                    break;
                                default:
                                    break;
                            }
                        }
                        if (isset($attr_val) && !empty($attr_val)) {
                            $vals[] = $attr_val;
                        }
                    }
                } else {
                    $mapped_expresion = explode('-', $value);
                    //echo '<pre>'; print_r($mapped_expresion); die;
                    $attr_val = '';
                    if (isset($mapped_expresion['0'])
                        && in_array($mapped_expresion['0'], array('system', 'attribute', 'feature'))) {
                        $attr_type = $mapped_expresion['0'];
                        $attribute_id = str_replace($attr_type . '-', "", $value);

                        switch ($attr_type) {
                            case 'attribute':
                                if ($mapped_attribute_id) {
                                    $attr_val = $this->getAttributeValue($attribute_id, $product_id);
                                } else {
                                    $attr_val = $attribute_id;
                                }

                                break;
                            case 'feature':
                                $attr_val = $this->getFeatureValue($attribute_id, $product_id);
                                break;
                            case 'system':
                                $attr_val = $this->getSystemValue($attribute_id, $product);
                                break;
                            default:
                                break;
                        }
                    }
                }
                if (is_array($value)) {
                    $mapped_values[$key] = $vals;
                } else {
                    $mapped_values[$key] = $attr_val;
                }

                if(isset($mapped_values['product-price']) && ($mapped_values['product-price'] > 0))
                {
                    $mapped_values['product-price'] = (float) $pricewithoutVat;
                }
                if(isset($mapped_values['product-oldprice']) && ($mapped_values['product-oldprice'] > 0))
                {
                    $mapped_values['product-oldprice'] = (float) $pricewithVat;
                }
            }

            return $mapped_values;
        } else {
            return array();
        }
    }

    public function getMappedAttributes($fyndiq_attribute = '')
    {
        $db = Db::getInstance();
        $status = $db->ExecuteS("SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_attribute_mapping`");

        if (is_array($status) && count($status)) {
            $attributes = array();
            foreach ($status as $value) {
                if (isset($value['fyndiqSkuId']) && (int)$value['fyndiqSkuId']) {
                    $attributes[trim($value['fyndiq_attribute'])] = json_decode($value['prestashop_attribute']);
                } else {
                    $attributes[trim($value['fyndiq_attribute'])] = $value['prestashop_attribute'];
                }
            }
            if ($fyndiq_attribute && isset($attributes[trim($fyndiq_attribute)])) {
                return $attributes[trim($fyndiq_attribute)];
            }

            return $attributes;
        } else {
            return array();
        }
    }

    public function getAttributeValue($attribute_group_id, $product_id)
    {
        $sql_db_intance = Db::getInstance();
        $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');
        $features = $sql_db_intance->executeS('
            SELECT *
            FROM ' . _DB_PREFIX_ . 'product_attribute pa
            LEFT JOIN ' . _DB_PREFIX_ . 'product_attribute_combination pac 
            ON pac.id_product_attribute = pa.id_product_attribute
            LEFT JOIN ' . _DB_PREFIX_ . 'attribute a ON a.id_attribute = pac.id_attribute
            LEFT JOIN ' . _DB_PREFIX_ . 'attribute_group ag 
            ON ag.id_attribute_group = a.id_attribute_group
            LEFT JOIN ' . _DB_PREFIX_ . 'attribute_lang al ON (a.id_attribute = al.id_attribute 
            AND al.id_lang = ' . (int)$default_lang . ')
            LEFT JOIN ' . _DB_PREFIX_ . 'attribute_group_lang agl 
            ON (ag.id_attribute_group = agl.id_attribute_group 
            AND agl.id_lang = ' . (int)$default_lang . ')
            WHERE pa.id_product = "' . (int)$product_id . '" 
            AND a.id_attribute_group = "' . (int)$attribute_group_id . '" 
            ORDER BY pa.id_product_attribute');

        if (isset($features['0']['name'])) {
            return $features['0']['name'];
        } else {
            return false;
        }
    }

    public function getFeatureValue($attribute_id, $product_id)
    {
        $sql_db_intance = Db::getInstance(_PS_USE_SQL_SLAVE_);
        $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ?
            (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') :
            (int)Configuration::get('PS_LANG_DEFAULT');
        $features = $sql_db_intance->executeS('
            SELECT value FROM ' . _DB_PREFIX_ . 'feature_product pf
            LEFT JOIN ' . _DB_PREFIX_ . 'feature_lang fl 
            ON (fl.id_feature = pf.id_feature 
            AND fl.id_lang = ' . (int)$default_lang . ')
            LEFT JOIN ' . _DB_PREFIX_ . 'feature_value_lang fvl 
            ON (fvl.id_feature_value = pf.id_feature_value 
            AND fvl.id_lang = ' . (int)$default_lang . ')
            LEFT JOIN ' . _DB_PREFIX_ . 'feature f ON (f.id_feature = pf.id_feature 
            AND fl.id_lang = ' . (int)$default_lang . ')
            ' . Shop::addSqlAssociation('feature', 'f') . '
            WHERE pf.id_product = ' . (int)$product_id . ' 
            AND fl.id_feature = "' . (int)$attribute_id . '" 
            ORDER BY f.position ASC');
        if (isset($features['0']['value'])) {
            return $features['0']['value'];
        } else {
            return false;
        }
    }

    public function getSystemValue($attribute_id, $product)
    {
        if (isset($product[$attribute_id])) {
            $db = Db::getInstance();
            if ($attribute_id == 'id_manufacturer') {
                if (isset($product['id_manufacturer']) && $product['id_manufacturer']) {
                    $Execute = 'SELECT `name` FROM `' . _DB_PREFIX_ . 'manufacturer` 
                    WHERE `id_manufacturer`=' . (int)$product['id_manufacturer'];
                    $qresult = $db->ExecuteS($Execute);
                    if (isset($qresult['0']["name"])) {
                        return $qresult['0']["name"];
                    }
                }
            }
            if ($attribute_id == 'id_tax_rules_group') {
                if (isset($product['id_tax_rules_group']) && $product['id_tax_rules_group']) {
                    $Execute = 'SELECT `rate` FROM `' . _DB_PREFIX_ . 'tax_rule` tr 
                    LEFT JOIN `' . _DB_PREFIX_ . 'tax` t on (t.id_tax = tr.id_tax) 
                    WHERE tr.`id_tax_rules_group`=' . (int)$product['id_tax_rules_group'];
                    $qresult = $db->ExecuteS($Execute);
                    if (isset($qresult['0']["rate"])) {
                        return number_format($qresult['0']["rate"], 2);
                    }
                }
            }

            return $product[$attribute_id];
        } else {
            return false;
        }
    }

    public function getFyndiqCategory($product_id)
    {
        $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ? (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') : (int)Configuration::get('PS_LANG_DEFAULT');
        $db = Db::getInstance();
        $query = $db->ExecuteS("SELECT cp.`id_category`, cl.`name` FROM `" . _DB_PREFIX_ . "category_product` AS cp LEFT JOIN `" . _DB_PREFIX_ . "category_lang` AS cl ON (cp.`id_category` = cl.`id_category`) WHERE cp.`id_product` = '" . (int)$product_id . "' AND cl.`id_lang` = '". (int)$default_lang ."' ");
        $catgories = array();
        if (is_array($query) && count($query)) {
            foreach ($query as $result) {
                $catgories[] = array(
                    'store_cat_id' => $result['id_category'],
                    'store_cat_name' => $result['name']
                );
            }
        }
        $mapped_category = array();
        if (count($catgories)) {
            $rows = $db->ExecuteS("SELECT `category_id`, `name_sv` AS `name`, `mapped_categories` 
              FROM `" . _DB_PREFIX_ . "fyndiq_category_list` WHERE `mapped_categories` != ''");
            if (isset($rows['0']) && $rows['0']) {
                foreach ($rows as $row) {
                    $mapped_categories = unserialize($row['mapped_categories']);

                    foreach($catgories as $key => $value){
                        if(in_array($value['store_cat_id'], $mapped_categories)){
                            $mapped_category['fyndiq-category-id'] = $row['category_id'];
                            $mapped_category['store-category-id'] = $value['store_cat_id'];
                            $mapped_category['store-category-name'] = trim($value['store_cat_name']);
                        }
                    }
                }
            }
        } elseif (Configuration::get('CEDFYNDIQ_CATEGORY_MAP_ALL')) {

            $rows = $db->ExecuteS("SELECT `category_id` 
              FROM `" . _DB_PREFIX_ . "fyndiq_category_list` WHERE `mapped_categories` != '' AND `name_sv` = '". trim(Configuration::get('CEDFYNDIQ_CATEGORY_MAP_ALL')) ."' ");
            if (isset($rows['0']) && $rows['0']) {

                $mapped_categories = unserialize($rows['0']['mapped_categories']);

                $storeCategory = $db->ExecuteS("SELECT `name` FROM `" . _DB_PREFIX_ . "category_lang` WHERE `id_lang` = '". (int)$default_lang ."' AND `id_category` = '". (int)$mapped_categories['0'] ."' ");

                $mapped_category['fyndiq-category-id'] = $rows['0']['category_id'];
                $mapped_category['store-category-id'] = $mapped_categories['0'];
                $mapped_category['store-category-name'] = trim($storeCategory['0']['name']);
            }
        }
        return $mapped_category;
    }

    public function productImageUrls($product_id = 0, $attribute_id = 0)
    {
        if ($product_id)
        {
            $additionalAssets = array();
            $default_lang = ((int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE')) ?
                (int)Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') :
                (int)Configuration::get('PS_LANG_DEFAULT');
            $db = Db::getInstance();
            $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'image` i 
            LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il 
            ON (i.`id_image` = il.`id_image`)';

            if ($attribute_id)
            {
                $sql .= ' LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_image` ai 
                ON (i.`id_image` = ai.`id_image`)';
                $attribute_filter = ' AND ai.`id_product_attribute` = ' . (int)$attribute_id;
                $sql .= ' WHERE i.`id_product` = ' . (int)$product_id . ' 
                AND il.`id_lang` = ' . (int)$default_lang . $attribute_filter . ' 
                ORDER BY i.`position` ASC';
            } else {
                $sql .= ' WHERE i.`id_product` = ' . (int)$product_id . ' 
                AND il.`id_lang` = ' . (int)$default_lang . ' ORDER BY i.`position` ASC';
            }

            $Execute = $db->ExecuteS($sql);

            if (version_compare(_PS_VERSION_, '1.7', '>=') === true) {
                $type = ImageType::getFormattedName('large');
            } else {
                $type = ImageType::getFormatedName('thickbox');
            }

            $product = new Product($product_id);
            $link = new Link;
            if (count($Execute) > 0) {
                foreach ($Execute as $image) {
                    $image_url = $link->getImageLink(
                        $product->link_rewrite[$default_lang],
                        $image['id_image'],
                        $type
                    );
                    if (isset($image['cover']) && $image['cover']) {
                        $additionalAssets['mainImageUrl'] = (Configuration::get('PS_SSL_ENABLED') ?
                                'https://' : 'http://') . $image_url;
                    } else {
                        if (!isset($additionalAssets['mainImageUrl'])) {
                            $additionalAssets['mainImageUrl'] = (Configuration::get('PS_SSL_ENABLED') ?
                                    'https://' : 'http://') . $image_url;
                        } else {
                            $additionalAssets['productSecondaryImageURL'][] =
                                (Configuration::get('PS_SSL_ENABLED') ?
                                    'https://' : 'http://') . $image_url;
                        }
                    }
                }
            }

            return $additionalAssets;
        }
    }

    public function getAllFyndiqCategory()
    {
        $db = Db::getInstance();

        $mapped_category = array();
        $rows = $db->ExecuteS("SELECT `name_sv` FROM `" . _DB_PREFIX_ . "fyndiq_category_list`");
        $mapped_category[] = array('id' => '', 'name' => '');
        if (isset($rows['0']) && $rows['0']) {
            foreach ($rows as $row) {
                $mapped_category[] = array('id' => trim($row['name_sv']), 'name' => trim($row['name_sv']));
            }
        }
        return $mapped_category;
    }

    public function getSavedDefaultValues()
    {
        $db = Db::getInstance();
        $sql = "SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_default_values`";
        $status = $db->ExecuteS($sql);
        if (is_array($status) && count($status)) {
            $attributes = array();
            foreach ($status as $value) {
                $attributes[$value['fyndiq_attribute']] = $value['default_value'];
            }
            return $attributes;
        } else {
            return array();
        }
    }

    public function getAllMappedCategories()
    {
        $db = Db::getInstance();
        $row = $db->ExecuteS("SELECT `mapped_categories` 
        FROM `" . _DB_PREFIX_ . "fyndiq_category_list` 
        WHERE `mapped_categories` != ''");

        if (isset($row['0']) && $row['0']) {
            $mapped_categories = array();
            foreach ($row as $value) {
                $mapped_categories = array_merge($mapped_categories, unserialize($value['mapped_categories']));
            }
            return $mapped_categories;
        } else {
            return array();
        }
    }

    public function saveProductVariants($variations, $product_id, $errors)
    {
        $db = Db::getInstance();
        $sql = "SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_product_variations` 
        WHERE product_id=" . (int)$product_id . " ";

        $priviousChilds = $db->ExecuteS($sql);
        $previousChildSkus = array();
        if (is_array($priviousChilds) && count($priviousChilds)) {
            foreach ($priviousChilds as $priviousChild) {
                $previousChildSkus[trim($priviousChild['sku'])] = array(
                    'fyndiqSkuId' => $priviousChild['fyndiqSkuId']
                );
            }
            $previousChildSkus = array_filter($previousChildSkus);
        }
        $sql = "DELETE FROM `" . _DB_PREFIX_ . "fyndiq_product_variations` 
        WHERE `product_id`=" . (int)($product_id);
        $db->Execute($sql);
        foreach ($variations as $product) {
            if (isset($product['product-id']) && isset($product['article-sku'])
                && $product['product-id'] && $product['article-sku']) {
                $error = '';
                if (isset($errors[$product['article-sku']])) {
                    $error = $errors[$product['article-sku']];
                }

                if (isset($product['article-quantity']) && $product['article-quantity'] != '0') {
                    $product['article-quantity'] = 'INSTOCK';
                }

                $combination = array();
                for($i=1; $i<50; $i++){
                    if(isset($product['article-property-' . $i . '-name']) && !empty($product['article-property-' . $i . '-name'])){
                        $combination['article-property-' . $i . '-name'] = $product['article-property-' . $i . '-name'];
                    }
                    if(isset($product['article-property-' . $i . '-value']) && !empty($product['article-property-' . $i . '-value'])){
                        $combination['article-property-' . $i . '-value'] = $product['article-property-' . $i . '-value'];
                    }
                }

                $result = $db->insert(
                    'fyndiq_product_variations',
                    array(
                        'product_id' => (int)$product['product-id'],
                        'fyndiq_status' => (int)$product['article-quantity'],
                        'error_message' => pSQL($error),
                        'sku' => pSQL($product['article-sku']),
                        'combination' => pSQL(Tools::jsonEncode($combination))
                    )
                );

                if ($result) {
                    if (isset($previousChildSkus[trim($product['article-sku'])])
                        && $previousChildSkus[trim($product['article-sku'])]) {
                        unset($previousChildSkus[trim($product['article-sku'])]);
                    }
                }
            }
        }
        // if (count($previousChildSkus)) {
        //     $this->removeFyndiqVariation($previousChildSkus);
        // }
    }

    public function processUploadError($data)
    {
        if (isset($data) && $data) {
            $db = Db::getInstance(_PS_USE_SQL_SLAVE_);
            foreach ($data as $key => $value) {
                if (!is_array($value)) {
                    $value = array($value);
                }
                $result = $db->ExecuteS("SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$key . "'");

                if (count($result)) {
                    $db->update(
                        'fyndiq_products',
                        array(
                            'error_message' => pSQL(implode('<br>', (array)$value)),
                        ),
                        'product_id='.(int)$key.''
                    );
                } else {
                    $db->insert(
                        'fyndiq_products',
                        array(
                            'error_message' => pSQL(implode('<br>', (array)$value)),
                            'product_id' => (int)$key
                        )
                    );
                }
            }
        }
    }

    public function processUploadData($data)
    {
        //echo '<pre>';
        //var_dump($data);die;
        if(!isset($data['0']))
        {
            $temp_array = $data;
            $data = array();
            $data['0'] = $temp_array;
        }

        $response = array();
        $price_type = Configuration::get('CEDFYNDIQ_PRICE_TYPE');
        if (count($data)) {
            $db = Db::getInstance();
            foreach ($data as $pro) {

                switch ($price_type) {
                    case 'product-price':
                        if($pro['product-price'] > '0') {
                            $pro['product-price'] = $pro['product-price'];
                        } else {
                            $pro['product-price'] = '0.00';
                        }
                        break;

                    case 'product-oldprice':
                        if($pro['product-oldprice'] > '0') {
                            $pro['product-oldprice'] = $pro['product-oldprice'];
                        } else {
                            $pro['product-oldprice'] = '0.00';
                        }
                        break;

                    default:
                        if($pro['product-price'] > '0') {
                            $pro['product-price'] = $pro['product-price'];
                        } elseif($pro['product-oldprice'] > '0') {
                            $pro['product-oldprice'] = $pro['product-oldprice'];
                        } else {
                            $pro['product-price'] = '0.00';
                        }
                        break;
                }

                if (isset($pro['product-price']) && $pro['product-price'] > '0') {
                    $pro['product-price'] = (float) $this->getPriceFyndiq($pro['product-price']);
                }

                if (isset($pro['product-oldprice']) && !empty($pro['product-oldprice'])) {
                    $pro['product-oldprice'] = (float) $this->getPriceFyndiq($pro['product-oldprice']);
                }

                $product_images = array();
                for ($i = 1; $i <= 30; $i++) {
                    if (isset($pro['product-image-' . $i . '-url']) && !empty($pro['product-image-' . $i . '-url']))
                    {
                        $product_images['product-image-' . $i . '-url'] = $pro['product-image-' . $i . '-url'];
                        $product_images['product-image-' . $i . '-identifier'] = basename($pro['product-image-' . $i . '-url']);
                        if(strlen($pro['product-image-' . $i . '-identifier']) > 42)
                        {
                            $product_images['product-image-' . $i . '-identifier'] = substr($pro['product-image-' . $i . '-identifier'], 0, 41);
                        }



                    } else {
                        $product_images['product-image-' . $i . '-url'] = '';
                        $product_images['product-image-' . $i . '-identifier'] = '';
                    }
                    unset($pro['product-image-' . $i . '-url']);
                    unset($pro['product-image-' . $i . '-identifier']);
                }

                $combination = array();
                for($i=1; $i<=50; $i++) {
                    if (isset($pro['article-property-' . $i . '-name']) && !empty($pro['article-property-' . $i . '-name']))
                        $combination['article-property-' . $i . '-name'] = $pro['article-property-' . $i . '-name'];
                    else
                        $combination['article-property-' . $i . '-name'] = '';

                    if (isset($pro['article-property-' . $i . '-value']) && !empty($pro['article-property-' . $i . '-value']))
                        $combination['article-property-' . $i . '-value'] = $pro['article-property-' . $i . '-value'];
                    else
                        $combination['article-property-' . $i . '-value'] = '';

                    unset($pro['article-property-' . $i . '-name']);
                    unset($pro['article-property-' . $i . '-value']);
                }

                $res = $db->executeS("SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_final_products` WHERE `article-sku`='". pSQL($pro['article-sku']) ."'");

                if (isset($res) && count($res) && is_array($res) && isset($combination) && is_array($combination)) {
                    $db->update(
                        'fyndiq_final_products',
                        array(
                            'product-id' => (int)$pro['product-id'],
                            'product-paused' => (int)$pro['product-paused'],
                            'product-category-id' => pSQL($pro['product-category-id']),
                            'product-category-name' => pSQL($pro['product-category-name']),
                            'product-category-fyndiq-id' => pSQL($pro['product-category-fyndiq-id']),
                            'product-brand-name' => pSQL($pro['product-brand-name']),
                            'product-title' => pSQL($pro['product-title']),
                            'product-description' => pSQL($pro['product-description'], true),
                            'product-market' => pSQL($pro['product-market']),
                            'product-currency' => pSQL($pro['product-currency']),
                            'product-price' => (float)$pro['product-price'],
                            'product-oldprice' => (float)$pro['product-oldprice'],
                            'product-vat-percent' => (int)$pro['product-vat-percent'],
                            'product-portion' => (float)$pro['product-portion'],
                            'product-comparison-unit' => pSQL($pro['product-comparison-unit']),
                            'article-sku' => pSQL($pro['article-sku']),
                            'article-quantity' => (int)$pro['article-quantity'],
                            'article-name' => pSQL($pro['article-name']),
                            'article-location' => pSQL($pro['article-location']),
                            'article-ean' => pSQL($pro['article-ean']),
                            'article-isbn' => pSQL($pro['article-isbn']),
                            'article-mpn' => pSQL($pro['article-mpn']),
                            'article-eu-energy-class' => pSQL($pro['article-eu-energy-class']),
                            'article-eu-energy-label-url' => (int)$pro['article-eu-energy-label-url'],
                            'article-eu-energy-datasheet-url' => pSQL($pro['article-eu-energy-datasheet-url']),
                            'article-property' => pSQL(Tools::jsonEncode($combination)),
                            'product-images' => pSQL(Tools::jsonEncode($product_images))
                        ),
                        ' `article-sku` ="' . pSQL($pro['article-sku']) . '"'
                    );
                } else {
                    if (isset($pro) && count($pro) && is_array($pro) && isset($combination) && is_array($combination)) {
                        $db->insert(
                            'fyndiq_final_products',
                            array(
                                'product-id' => (int)$pro['product-id'],
                                'product-paused' => (int)$pro['product-paused'],
                                'product-category-id' => pSQL($pro['product-category-id']),
                                'product-category-name' => pSQL($pro['product-category-name']),
                                'product-category-fyndiq-id' => pSQL($pro['product-category-fyndiq-id']),
                                'product-brand-name' => pSQL($pro['product-brand-name']),
                                'product-title' => pSQL($pro['product-title']),
                                'product-description' => pSQL($pro['product-description'], true),
                                'product-market' => pSQL($pro['product-market']),
                                'product-currency' => pSQL($pro['product-currency']),
                                'product-price' => (float)$pro['product-price'],
                                'product-oldprice' => (float)$pro['product-oldprice'],
                                'product-vat-percent' => (int)$pro['product-vat-percent'],
                                'product-portion' => (float)$pro['product-portion'],
                                'product-comparison-unit' => pSQL($pro['product-comparison-unit']),
                                'article-sku' => pSQL($pro['article-sku']),
                                'article-quantity' => (int)$pro['article-quantity'],
                                'article-name' => pSQL($pro['article-name']),
                                'article-location' => pSQL($pro['article-location']),
                                'article-ean' => pSQL($pro['article-ean']),
                                'article-isbn' => pSQL($pro['article-isbn']),
                                'article-mpn' => pSQL($pro['article-mpn']),
                                'article-eu-energy-class' => pSQL($pro['article-eu-energy-class']),
                                'article-eu-energy-label-url' => (int)$pro['article-eu-energy-label-url'],
                                'article-eu-energy-datasheet-url' => pSQL($pro['article-eu-energy-datasheet-url']),
                                'article-property' => pSQL(Tools::jsonEncode($combination)),
                                'product-images' => pSQL(Tools::jsonEncode($product_images))
                            )
                        );
                    }
                }
            }
            $feedGenerated = $this->generateFeed();

            if($feedGenerated == '1') {
                $cedFyndiqHelper = new CedfyndiqHelper();
                $module_url = _PS_BASE_URL_.__PS_BASE_URI__ . 'modules/cedfyndiq/';
                $params = array(
                    'product_feed_url' => $module_url . 'product_upload/product_feed.csv',
                    'product_feed_notification_url' => Configuration::get('CEDFYNDIQ_NOTIFICATION_URL'),
                    'order_notification_url' => $module_url . 'orders/'
                );

                $headers = array();

                $headers[] = "Accept: application/csv";
                $headers[] = "Content-Type: text/csv; charset=utf-8";

                $res = $cedFyndiqHelper->fyndiqPostRequest('settings/', $params, "PATCH", $headers);
                //echo '<pre>'; print_r($res); die;
                if(isset($res['success']) && $res['success'] == 1)
                {
                    $response['success'] = true;
                    if (!empty($res['message'])) {
                        $response['message'] = $res['message'];
                    } else {
                        $response['message'] = 'Feed Updated at Fyndiq';
                    }
                } else {
                    $response['success'] = false;
                    if (!empty($res['message'])) {
                        $response['message'] = $res['message'];
                    } else {
                        $response['message'] = 'No response from Fyndiq';
                    }
                }
            }
        }
        return $response;
    }

    public function generateFeed()
    {
        $cedFyndiqHelper = new CedfyndiqHelper();
        $db = Db::getInstance();
        $result = $db->executeS("SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_final_products` ");
//        echo '<pre>'; print_r($result); die;
        $headers = array();
        $csv_dir = _PS_MODULE_DIR_ . 'cedfyndiq/product_upload/';
        if (!is_dir($csv_dir)) {
            mkdir($csv_dir, '0777', true);
        }
        try {
            $file = fopen($csv_dir . 'product_feed.csv', 'w');
            //fputs($file, $bom = ( chr(0xEF) . chr(0xBB) . chr(0xBF) ));
            // Feed start with a byte order mark (BOM) character, please remove it to ensure correct parsing of your feed.
            foreach ($result as $row_data) {
                ksort($row_data);

                $row = $this->removeNullValuesFromFinalProducts($row_data);
                ksort($row);

                if (count($headers) == 0) {
                    $headers = array_keys($row);
                    fputcsv($file, $headers);
                    fputcsv($file, $row);
                } else {
                    fputcsv($file, $row);
                }
            }

            fclose($file);
            return true;
        } catch (Exception $e) {
            $cedFyndiqHelper->log(
                'CedfyndiqProduct::generateFeed',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return $e->getMessage();
        }
    }

    public function removeNullValuesFromFinalProducts($data = array())
    {
        if (count($data)) {
            foreach ($data as $key => $value) {

                if ($key == 'article-quantity') {
                    continue;
                }
                if ($key == 'product-vat-percent') {
                    continue;
                }

                if ($key == 'product-price') {
                    if(strpos($value, '.') === false)
                        $data[$key] = $value . '.00';
                    else
                        $data[$key] = number_format((float)$value, 2, '.', '');
                    //$data[$key] =  number_format((float) $value, 2, '.', '');
                }

                if ($key == 'product-oldprice') {
                    if(strpos($value, '.') === false)
                        $data[$key] = $value . '.00';
                    else
                        $data[$key] = number_format((float)$value, 2, '.', '');
                    //$data[$key] =  number_format((float)$value, 2, '.', '');
                }

                if (!$value) {
                    $data[$key] = '';
                }

                // Category
                if ($key == 'product-category-name') {
                    $data[$key] = str_replace(array("\r", "\r\n", "\n"), '', $value);
                }
                // Brand
                if($key == 'product-brand-name') {
                    $brand = trim($value);
                    if(strlen($brand) > '32')
                    {
                        $data[$key] = substr($brand, 0, 31);
                    }
                }
                // Title
                if($key == 'product-title') {
                    $title = trim($value);
                    if(strlen($title) > '64')
                    {
                        $data[$key] = substr($title, 0, 63);
                    }
                }

                // Description
                if($key == 'product-description') {
                    $value = $this->prepareDescriptionWoHtml($value);
                    if(strlen($value) > '4096')
                    {
                        $value = substr($value, 0, 4095);
                    }

                    $data[$key] = $value;
                }
                // article name
                if($key == 'article-name') {
                    $article_name = trim($value);
                    if(strlen($article_name) > '30')
                    {
                        $article_name = substr($article_name, 0, 29);
                    }
                    $data[$key] = htmlspecialchars_decode($article_name);
                }

                // Article property
                if(($key == 'article-property') && !empty($value))
                {
                    $articleProperty = Tools::jsonDecode($value, true);
                    unset($data[$key]);
                    if(!empty($articleProperty)){
                        foreach($articleProperty as $index => $val){
                            $data[$index] = $val;
                        }
                        for($i='2'; $i<= '50'; $i++){
                            if(!isset($data['article-property-'. $i .'-name']))
                            {
                                $data['article-property-'. $i .'-name'] = '';
                                $data['article-property-'. $i .'-value'] = '';
                            }
                        }

                    } else {
                        for($i='1'; $i<= '50'; $i++){
                            if(!isset($data['article-property-'. $i .'-name']))
                            {
                                $data['article-property-'. $i .'-name'] = '';
                                $data['article-property-'. $i .'-value'] = '';
                            }
                        }
                    }
                }

                // Product Image
                if(($key == 'product-images') && !empty($value))
                {
                    $productImages = Tools::jsonDecode($value, true);
                    unset($data[$key]);
                    if(!empty($productImages) && is_array($productImages))
                    {
                        foreach($productImages as $index => $val)
                        {
                            if(strpos($index, 'identifier') !== false)
                            {
                                $data[$index] = $val;
                                $identifier = $val;
                                if(strlen($identifier) > '42')
                                {
                                    $data[$index] = substr($identifier, 0, 41);
                                }
                            } else {
                                $data[$index] = $val;
                            }
                        }
                        for($i='1'; $i<= '30'; $i++)
                        {
                            if(!isset($data['product-image-'. $i .'-url']))
                            {
                                $data['product-image-'. $i .'-url'] = '';
                                $data['product-image-'. $i .'-identifier'] = '';
                            }
                        }

                    } else {
                        for($i='1'; $i<= '30'; $i++){
                            if(!isset($data['product-image-'. $i .'-url']))
                            {
                                $data['product-image-'. $i .'-url'] = '';
                                $data['product-image-'. $i .'-identifier'] = '';
                            }
                        }
                    }
                }
            }
        }
        return $data;
    }

    public static function prepareDescriptionWoHtml($html)
    {
        $text = $html;

        $text = str_replace(array('</li>', '</LI>'), "\n</li>", $text);
        $text = str_replace(array('<BR', '<br'), "\n<br", $text);

        $text = strip_tags($text);

        $text = str_replace('&#39;', "'", $text);

        $text = mb_convert_encoding($text, 'HTML-ENTITIES');

        $text = str_replace('&nbsp;', ' ', $text);

        $text = html_entity_decode($text, ENT_NOQUOTES, 'UTF-8');

        //$text = str_replace('&', '&amp;', $text);
        //$text = str_replace('"', "&#34;", $text);

        //$text = preg_replace('#\s+[\n|\r]+$#i', '', $text); // empty
        //$text = preg_replace('#[\n|\r]+#i', "\n", $text); // multiple-return
        // $text = preg_replace('#(\s)\n+#i', "\n", $text); // multiple-return
        // $text = preg_replace('#^[\n\r\s]#i', '', $text);

        //$text = preg_replace('/[\x{0001}-\x{0009}]/u', '', $text);
        // $text = preg_replace('/[\x{000b}-\x{001f}]/u', '', $text);
        // $text = preg_replace('/[\x{0080}-\x{009F}]/u', '', $text);
        // $text = preg_replace('/[\x{0600}-\x{FFFF}]/u', '', $text);

        // $text = preg_replace('/\x{000a}/', "\n", $text);

        //$text = str_replace("\n", ', ', $text);
        //$text = trim(rtrim($text, ', '));

        return ($text);
    }

    public function getPriceFyndiq($price)
    {
        $type = Configuration::get('CEDFYNDIQ_PRICE_VARIANT_TYPE');
        $amount = Configuration::get('CEDFYNDIQ_PRICE_VARIANT_AMOUNT');
        switch ($type) {
            case 1:
                $price = $price;
                break;
            case 2:
                $price = $price + $amount;
                break;

            case 3:
                $price = $price - $amount;
                break;

            case 4:
                $price = $price + (($price * $amount) / 100);
                break;

            case 5:
                $price = $price - (($price * $amount) / 100);
                break;

            default:
                $price = $price;
                break;
        }
        return (float)$price;
    }

    public function syncProducts($url = 'product_info/', $params = array())
    {
        try{
            $cedFyndiqHelper = new CedfyndiqHelper();
            $response = $cedFyndiqHelper->fyndiqGetRequest($url, $params);
            if(isset($response['success']) && $response['success'] == true)
            {
                if (isset($response['response']) && $response['response'])
                {
                    $response = json_decode($response['response'], true);
                    if(isset($response['next']) && $response['next'])
                    {
                        $endpointurl = 'https://api.fyndiq.com/v2/';
                        $data = explode($endpointurl, $response['next']);

                        @$next_url = $data[1];
                    }

                    if (!is_array($response)) {
                        return array('success' => false, 'message' => $response);
                    }
                    $errorMessage = '';
                    if (isset($response['errors'])) {
                        foreach ($response['errors'] as $error) {
                            foreach ($error as $err) {
                                if (isset($err['description']) && $err['    description']) {
                                    $errorMessage .= $err['description'];
                                }
                            }
                        }
                    } else {
                        if(isset($response['results']) && is_array($response['results']) && $response['results'])
                        {
                            foreach($response['results'] as $key => $value)
                            {
                                $res = Db::getInstance()->Execute("UPDATE `". _DB_PREFIX_."fyndiq_products` SET `fyndiq_status` = '". pSQL($value['for_sale']) ."' WHERE `product_id` = '". (int) $value['product_id'] ."' ");
                            }
                        }
                        if(isset($next_url) && $next_url)
                        {
                            $this->syncProducts($next_url, array());
                        }
                    }
                    if(empty($errorMessage))
                        return array('success' => true, 'message' => 'Product(s) Status Synced Successfully!');
                    else
                        return array('success' => false, 'message' => $errorMessage);
                }
            } else {
                return $response;
            }

        } catch(Exception $e)
        {
            $cedFyndiqHelper->log(
                'CedfyndiqProduct::syncProducts',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }

    }

    public function feedReport($url = 'feed_report/')
    {
        try {
            $cedFyndiqHelper = new CedfyndiqHelper();
            $response = $cedFyndiqHelper->fyndiqGetRequest($url, array());
            $cedFyndiqHelper->log(
                'CedfyndiqProduct::feedReport',
                'Response',
                $response,
                $response,
                true
            );

            if(isset($response['success']) && $response['success'] == true)
            {
                return $response;
            } else {
                return array('success' => false, 'message' => $response['message']);
            }

        } catch(Exception $e)
        {
            $cedFyndiqHelper->log(
                'CedfyndiqProduct::feedReport',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function validateProduct($data)
    {
        $cedFyndiqHelper = new CedfyndiqHelper();
        $result = array();
        $validation = $cedFyndiqHelper->getValidationArray();
        $result['error'] = '';
        foreach ($validation as $key => $value) {
            $key = trim($key);
            if (isset($value['is_required']) && $value['is_required'] && isset($data[$key])) {
                switch ($key) {
                    case 'product-id':
                        if (isset($data['product-id']) && $data['product-id']) {
                            if (Tools::strlen(trim($data['product-id'])) > $value['length']) {
                                $result['error'] .= 'The length of' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'article-sku':
                        if (isset($data['article-sku']) && $data['article-sku']) {
                            if (Tools::strlen(trim($data['article-sku'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'article-ean':
                        if (isset($data['article-ean']) && $data['article-ean']) {
                            if (Tools::strlen(trim($data['article-ean'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-image-1-url':
                        if (isset($data['product-image-1-url']) && $data['product-image-1-url']) {
                            if (Tools::strlen(trim($data['product-image-1-url'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-image-1-identifier':
                        if (isset($data['product-image-1-identifier']) && $data['product-image-1-identifier']) {
                            if (Tools::strlen(trim($data['product-image-1-identifier'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'article-quantity':
                        if (isset($data['article-quantity'])) {
                            if(is_numeric($data['article-quantity']))
                            {
                                if (Tools::strlen(trim($data['article-quantity'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key . ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be a valid number. </br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-title':
                        if (isset($data['product-title']) && $data['product-title']) {
                            if (Tools::strlen(trim($data['product-title'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-description':
                        if (isset($data['product-description']) && $data['product-description']) {
                            if (Tools::strlen(trim($data['product-description'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-price':
                        if (isset($data['product-price']) && $data['product-price']) {
                            if ((float)(trim($data['product-price']))) {
                                if(strpos($data['product-price'], '.') === false)
                                    $data['product-price'] = $data['product-price'] . '.00';
                                else
                                    $data['product-price'] = $data['product-price'];
                                // $data['product-price'] =
                                //     number_format(trim($data['product-price']), 2, '.', '');
                                if (Tools::strlen($data['product-price']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-oldprice':
                        if (isset($data['product-oldprice']) && $data['product-oldprice']) {
                            if ((float)(trim($data['product-oldprice']))) {
                                if(strpos($data['product-oldprice'], '.') === false)
                                    $data['product-oldprice'] = $data['product-oldprice'] . '.00';
                                else
                                    $data['product-oldprice'] = $data['product-oldprice'];
                                // $data['product-oldprice'] =
                                //     number_format(trim($data['product-oldprice']), 2, '.', '');
                                if (Tools::strlen($data['product-oldprice']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-vat-percent':
                        if (isset($data['product-vat-percent'])) {
                            if (is_numeric((trim($data['product-vat-percent'])))) {
                                $data['product-vat-percent'] = (float)trim($data['product-vat-percent']);
                                if (Tools::strlen($data['product-vat-percent']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-market':
                        if (isset($data['product-market'])) {
                            if (Tools::strlen(trim($data['product-market'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'product-currency':
                        if (isset($data['product-currency'])) {
                            if (Tools::strlen(trim($data['product-currency'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                    case 'article-name':
                        if (isset($data['article-name'])) {
                            if (Tools::strlen(trim($data['article-name'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        } else {
                            $result['error'] .= $key . ' is a required field. </br>';
                        }
                        break;
                }
            } elseif (isset($value['is_required']) && !$value['is_required']) {
                if (isset($data[$key]) && !$data[$key]) {
                    continue;
                }
                switch ($key) {
                    case 'product-brand-name':
                        if (isset($data['product-brand-name']) && $data['product-brand-name']) {
                            if (Tools::strlen(trim($data['product-brand-name'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'product-category-id':
                        if (isset($data['product-category-id']) && $data['product-category-id']) {
                            if (Tools::strlen(trim($data['product-category-id'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'product-category-name':
                        if (isset($data['product-category-name']) && $data['product-category-name']) {
                            if (Tools::strlen(trim($data['product-category-name'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'product-category-fyndiq-id':
                        if (isset($data['product-category-fyndiq-id']) && $data['product-category-fyndiq-id']) {
                            if (Tools::strlen(trim($data['product-category-fyndiq-id'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
//                    case 'product-image-2-url':
//                        if (isset($data['product-image-2-url']) && $data['product-image-2-url']) {
//                            if (Tools::strlen(trim($data['product-image-2-url'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
//                    case 'product-image-2-identifier':
//                        if (isset($data['product-image-2-identifier']) && $data['product-image-2-identifier']) {
//                            if (Tools::strlen(trim($data['product-image-2-identifier'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
//                    case 'product-image-3-url':
//                        if (isset($data['product-image-3-url']) && $data['product-image-3-url']) {
//                            if (Tools::strlen(trim($data['product-image-3-url'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
//                    case 'product-image-3-identifier':
//                        if (isset($data['product-image-3-identifier']) && $data['product-image-3-identifier']) {
//                            if (Tools::strlen(trim($data['product-image-3-identifier'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
//                    case 'product-image-4-url':
//                        if (isset($data['product-image-4-url']) && $data['product-image-4-url']) {
//                            if (Tools::strlen(trim($data['product-image-4-url'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
//                    case 'product-image-4-identifier':
//                        if (isset($data['product-image-4-identifier']) && $data['product-image-4-identifier']) {
//                            if (Tools::strlen(trim($data['product-image-4-identifier'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
//                    case 'product-image-5-url':
//                        if (isset($data['product-image-5-url']) && $data['product-image-5-url']) {
//                            if (Tools::strlen(trim($data['product-image-5-url'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
//                    case 'product-image-5-identifier':
//                        if (isset($data['product-image-5-identifier']) && $data['product-image-5-identifier']) {
//                            if (Tools::strlen(trim($data['product-image-5-identifier'])) > $value['length']) {
//                                $result['error'] .= 'The length of ' . $key .
//                                    ' must not exceed ' . $value['length'] . '</br>';
//                            }
//                        }
//                        break;
                    case 'product-portion':
                        if (isset($data['product-portion'])) {
                            if (Tools::strlen(trim($data['product-portion'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'article-isbn':
                        if (isset($data['article-isbn'])) {
                            if ((int)(trim($data['article-isbn']))) {
                                $data['article-isbn'] = (int)trim($data['article-isbn']);
                                if (Tools::strlen($data['article-isbn']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'article-mpn':
                        if (isset($data['article-mpn'])) {
                            if ((int)(trim($data['article-mpn']))) {
                                $data['article-mpn'] = (int)trim($data['article-mpn']);
                                if (Tools::strlen($data['article-mpn']) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else {
                                $result['error'] .= $key . ' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'product-comparison-unit':
                        if (isset($data['product-comparison-unit'])) {
                            if (Tools::strlen(trim($data['product-comparison-unit'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'article-eu-energy-class':
                        if (isset($data['article-eu-energy-class'])) {
                            if (Tools::strlen(trim($data['article-eu-energy-class'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'article-eu-energy-label-url':
                        if (isset($data['article-eu-energy-label-url'])) {
                            if (Tools::strlen($data['article-eu-energy-label-url']) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'article-eu-energy-datasheet-url':
                        if (isset($data['article-eu-energy-datasheet-url'])) {
                            if (Tools::strlen($data['article-eu-energy-datasheet-url']) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'article-location':
                        if (isset($data['article-location'])) {
                            if (Tools::strlen(trim($data['article-location'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case 'product-paused':
                        if (isset($data['product-paused'])) {
                            if (Tools::strlen(trim($data['product-paused'])) > $value['length']) {
                                $result['error'] .= 'The length of ' . $key .
                                    ' must not exceed ' . $value['length'] . '</br>';
                            }
                        }
                        break;
                    case $key :
                        for($i = '1'; $i< 50; $i++) {
                            if (isset($data['article-property-' . $i . '-name']) && ($data['article-property-' . $i . '-name'] == $key))
                            {
                                if (Tools::strlen(trim($data['article-property-' . $i . '-name'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else  if (isset($data['article-property-' . $i . '-value']) && ($data['article-property-' . $i . '-value'] == $key)) {
                                if (Tools::strlen(trim($data['article-property-' . $i . '-value'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else if(!isset($data['product-image-1-url']) && isset($data['product-image-'. $i .'-url']) && $data['product-image-'. $i .'-url'] && ($data['product-image-'. $i .'-url'] == $key)) {
                                if (Tools::strlen(trim($data['product-image-'. $i .'-url'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            } else if (!isset($data['product-image-1-identifier']) && isset($data['product-image-'. $i .'-identifier']) && $data['product-image-'. $i .'-identifier'] && ($data['product-image-'. $i .'-identifier'] == $key)) {
                                if (Tools::strlen(trim($data['product-image-'. $i .'-identifier'])) > $value['length']) {
                                    $result['error'] .= 'The length of ' . $key .
                                        ' must not exceed ' . $value['length'] . '</br>';
                                }
                            }
                        }
                        break;
                }
            } else {
                $result['error'] .= $key . ' is Required Field.' . '</br>';
            }
        }
        return $result;
    }

    public function getMappedVariationValue($id_attribute, $id_attribute_group)
    {
        if ($id_attribute_group) {
            $sql = "SELECT `mapped_options`, `fyndiq_option_id` 
                     FROM `"._DB_PREFIX_."fyndiq_option_mapping`
                      WHERE `store_option_id`='".$id_attribute_group."'";
            $result = Db:: getInstance()->ExecuteS($sql);
            if (isset($result['0']['mapped_options']) && isset($result['0']['fyndiq_option_id'])) {
                $cedwish_option_id = $result['0']['fyndiq_option_id'];
                $mapped_attributes = json_decode($result['0']['mapped_options'], true);
                if (is_array($mapped_attributes)) {
                    foreach ($mapped_attributes as $value) {
                        if (isset($value['store_option_value'])
                            && (trim($value['store_option_value'])==trim($id_attribute))) {
                            return array($cedwish_option_id => $value['cedfyndiq_option_value']);
                        }
                    }
                }
            }
            return array();
        }
        return array();
    }
}