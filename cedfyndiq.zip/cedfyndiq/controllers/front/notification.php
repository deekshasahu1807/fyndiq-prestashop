<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license http://cedcommerce.com/license-agreement.txt
 * @category Ced
 * @package CedFyndiq
 */
include_once(_PS_ROOT_DIR_.'/config/config.inc.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php');

class CedfyndiqNotificationModuleFrontController extends ModuleFrontController
{
    public function __construct()
    {
        $CedfyndiqHelper = new CedfyndiqHelper;

        header("HTTP/1.1 200 OK");
        $notificationData = Tools::file_get_contents("php://input");
        $notificationData = json_decode($notificationData, true);

        $CedfyndiqHelper->log(
            'CedfyndiqNotification',
            'Info',
            'Notification From Fyndiq',
            json_encode($notificationData)
        );
    }
}