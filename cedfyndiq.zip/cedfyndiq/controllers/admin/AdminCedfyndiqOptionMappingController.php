<?php
/**
 * Created by PhpStorm.
 * User: cedcoss
 * Date: 15/4/19
 * Time: 6:25 PM
 */
class AdminCedfyndiqOptionMappingController extends ModuleAdminController
{
    public function __construct()
    {
        $sql_queries= "CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."fyndiq_option_mapping` (
                          `id` int(11) NOT NULL AUTO_INCREMENT,
                          `fyndiq_option_id` text NOT NULL,
                          `store_option_id` int(11) NOT NULL,
                          `mapped_options` longtext NOT NULL,
                          PRIMARY KEY (`id`)
                        );";
        $db = Db::getInstance();
        $result=$db->execute($sql_queries);
        if($result)
        {
            $this->confirmations[]='table created';
        }else
        {
            $this->errors[]='table not created';
        }
        if (Tools::getIsset('removefyndiq_option_mapping')
            && Tools::getValue('removefyndiq_option_mapping')
            && Tools::getValue('id')) {
            $status = $this->deleteAttributemap(Tools::getValue('id'));
            if ($status) {
                $this->confirmations[] = 'Attribute Deleted Successfully.';
            } else {
                $this->errors[] = 'Failed To Delete Attribute(s).';
            }
        }
        if (Tools::getIsset('mapped') && Tools::getValue('mapped')) {
            $this->confirmations[] = 'Mapping Saved Successfully.';
        }
        $this->bootstrap  = true;
        $this->table      = 'fyndiq_option_mapping';
        $this->identifier = 'id';
        $this->addRowAction('edit');
        $this->addRowAction('remove');
        $this->fields_list = array(
            'id'     => array(
                'title' => 'ID',
                'type'  => 'text',
            ),
            'fyndiq_option_id'     => array(
                'title' => 'Fyndiq Attribute Code',
                'type'  => 'text',
            ),

            'store_option_id' => array(
                'title' => 'Store Attribute Id',
                'type'  => 'text',
            ),
        );
        parent::__construct();
    }
    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['new_mapping'] = array(
                'href' => self::$currentIndex.'&addfyndiq_option_mapping&token='.$this->token,
                'desc' => 'Add Mapping',
                'icon' => 'process-icon-new'
            );
        }
        elseif ($this->display == 'edit' || $this->display == 'add')
        {
            $this->page_header_toolbar_btn['backtolist'] = array(
                'href' => self::$currentIndex . '&token=' . $this->token,
                'desc' => $this->l('Back To List', null, null, false),
                'icon' => 'process-icon-back'
            );
        }
        parent::initPageHeaderToolbar();
    }
    public function displayRemoveLink($token = null, $id = null)
    {
        $tpl = $this->createTemplate('helpers/list/list_action_view.tpl');
        if (!array_key_exists('Remove', self::$cache_lang)) {
            self::$cache_lang['Remove'] = 'Remove';
        }

        $tpl->assign(array(
            'href' => self::$currentIndex.'&'.$this->identifier.'='.
                $id.'&removefyndiq_option_mapping='.
                $id.'&token='.($token != null ? $token : $this->token),
            'action' => self::$cache_lang['Remove'],
            'id' => $id
        ));

        return $tpl->fetch();
    }
    public function deleteAttributemap($id)
    {
        $db = Db::getInstance();
        $result = $db->delete(
            'fyndiq_option_mapping',
            'id='.(int)$id
        );
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
    public  function  renderForm()
    {
        $fyndiq_attributes = array(
            'color',
//            'size',
        );
        $mapped_attributes = $this->getFyndiqColors();
        $rowCount = 0;
        $already_mapped_attributes = array();
        $fyndiq_attributes_values = array();
        $this->context->smarty->assign(array('attributes' => array()));
        $fyndiq_attributes_values['color'] = $this->getFyndiqColors();
        if (Tools::getIsset('id') && Tools::getValue('id')) {
            $already_mapped_attributes = $this->getAttributeMappings(Tools::getValue('id'));
            if (count($already_mapped_attributes)) {
                $rowCount = count($already_mapped_attributes);
            }
        }
        $attributes = $this->getStoreAttributes();

        if(isset($attributes) && $attributes)
        {
            $features =  array();
            foreach($attributes as $key => $value)
            {
                if($value['name'] == 'Color')
                    $features[] = $value;
                else
                    continue;

            }
        }

        $option_values =  $this->getStoreAttributeValues();
        $controllerUrl =  $this->context->link->getAdminLink('AdminCedFyndiqOptionMapping');
        $this->context->smarty->assign(
            array(
                'token'=>$this->token,
                'controllerUrl' =>$controllerUrl,
                'option_values' =>$option_values,
                'features' =>$features,
                'attribute_row' => $rowCount,
                'already_mapped_attributes' => $already_mapped_attributes,
                'mapped_attributes' => $mapped_attributes,
                'fyndiq_attributes' => $fyndiq_attributes,
                'fyndiq_attributes_values'  => $fyndiq_attributes_values,
            )
        );
        $return = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/option/option_mapping.tpl'
        );
        parent::renderForm();
        return $return;
    }
    public function postProcess()
    {
        try {
            if (Tools::getIsset('savemapping') && Tools::getValue('savemapping')) {
                if (version_compare(_PS_VERSION_, '1.6.1', '>=') == true) {
                    $values = Tools::getAllValues();
                } else {
                    $values = $_POST;
                }
                $status = $this->saveOptionMapping($values);
                if ($status) {
                    $this->confirmations[] = 'Attribute Mapped Successfully.';
                } else {
                    $this->errors[] = 'Failed To Map Attribute(s).';
                }
            }
        } catch (\Exception $e) {
            $this->errors[] = $e->getMessage();
        }
        parent::postProcess();
    }
    public function saveOptionMapping($data)
    {
//        echo '<pre>';print_r($data);die;
        if (isset($data['cedfyndiq_option_mapping'])
            && count($data['cedfyndiq_option_mapping'])
            && isset($data['cedfyndiq_option_id'])
            &&  isset($data['store_option_id'])) {
            $db = Db::getInstance();
            $sql="SELECT `id` FROM `"._DB_PREFIX_."fyndiq_option_mapping` 
            WHERE `fyndiq_option_id` = '".$data['cedfyndiq_option_id']."' ";
            $result=$db->ExecuteS($sql);
            if (isset($result['0']['id'])) {
                $res = $db->update(
                    'fyndiq_option_mapping',
                    array(
                        'store_option_id' => (int)$data['store_option_id'],
                        'mapped_options' => pSQL(json_encode($data['cedfyndiq_option_mapping']))
                    ),
                    'id='.(int)$result['0']['id']
                );
            } else {
                $res = $db->insert(
                    'fyndiq_option_mapping',
                    array(
                        'fyndiq_option_id' => pSQL($data['cedfyndiq_option_id']),
                        'store_option_id' => (int)$data['store_option_id'],
                        'mapped_options' => pSQL(json_encode($data['cedfyndiq_option_mapping'])),
                    )
                );
            }
            if ($res) {
                return true;
            } else {
                return false;
            }
        }
    }
    public function getStoreAttributes()
    {
        $db = Db::getInstance();
        $default_lang = Configuration::get('PS_LANG_DEFAULT') ;
        $sql="SELECT `id_attribute_group` as `id_attribute`,`name` 
        FROM `"._DB_PREFIX_."attribute_group_lang` where `id_lang`='".$default_lang."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }
    }
    public function getAttributeMappings($id)
    {
        $db = Db::getInstance();
        $sql="SELECT * FROM `"._DB_PREFIX_."fyndiq_option_mapping` where `id`='".$id."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result['0'];
        } else {
            return array();
        }
    }
    public function getStoreAttributeValues()
    {
        $db = Db::getInstance();
        $default_lang = Configuration::get('PS_LANG_DEFAULT') ;
        $sql="SELECT * FROM `"._DB_PREFIX_."attribute` a 
        LEFT join `"._DB_PREFIX_."attribute_lang` al ON (a.id_attribute = al.id_attribute) 
        where al.id_lang='".$default_lang."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            $option_values = array();
            foreach ($result as $value) {
                $option_values[$value['id_attribute_group']][$value['id_attribute']] = $value['name'];
            }
            return $option_values;
        } else {
            return array();
        }
    }
    public function getFyndiqColors()
    {

        return array(
            "Beige",
            "Blå",
            "Brun",
            "Flerfärgad",
            "Genomskinlig",
            "Grön",
            "Gul",
            "Guld",
            "Lila",
            "Orange",
            "Rosa",
            "Röd",
            "Silver/Grå",
            "Svart",
            "Vit");
    }
}