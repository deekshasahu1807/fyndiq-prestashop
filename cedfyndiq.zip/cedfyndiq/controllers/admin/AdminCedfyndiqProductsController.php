<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php';
include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqProduct.php';

class AdminCedfyndiqProductsController extends ModuleAdminController
{
    /**
     * @var string name of the tab to display
     */
    protected $tab_display;

    protected $object;

    protected $product_attributes;

    protected $position_identifier = 'id_product';

    protected $submitted_tabs;

    protected $id_current_category;

    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->table = 'product';
        $this->className = 'Product';
        $this->lang = false;
        $this->list_no_link = true;
        $this->explicitSelect = true;
        $this->bulk_actions = array(
            'upload' => array(
                'text' => ('Upload selected'),
                'icon' => 'icon-upload',
            ),
            // 'assign_cat' => array(
            //     'text' => ('Assign Fyndiq Category'),
            //     'icon' => 'icon-upload',
            // ),
            // 'remove_cat' => array(
            //     'text' => ('Remove Fyndiq Category'),
            //     'icon' => 'icon-eraser',
            // ),
            'include' => array(
                'text' => ('Include Product'),
                'icon' => 'icon-refresh',
            ),
            'exclude' => array(
                'text' => ('Exclude Product'),
                'icon' => 'icon-refresh',
            )
        );
        if (!Tools::getValue('id_product')) {
            $this->multishop_context_group = false;
        }

        parent::__construct();


        /* Join categories table */
        if ($id_category = (int)Tools::getValue('productFilter_cl!name')) {
            $this->_category = new Category((int)$id_category);
            $_POST['productFilter_cl!name'] = $this->_category->name[$this->context->language->id];
        } else {
            if ($id_category = (int)Tools::getValue('id_category')) {
                $this->id_current_category = $id_category;
                $this->context->cookie->id_category_products_filter = $id_category;
            } elseif ($id_category = $this->context->cookie->id_category_products_filter) {
                $this->id_current_category = $id_category;
            }
            if ($this->id_current_category) {
                $this->_category = new Category((int)$this->id_current_category);
            } else {
                $this->_category = new Category();
            }
        }
        $this->_join .= '
        LEFT JOIN `'._DB_PREFIX_.'stock_available` sav ON (sav.`id_product` = a.`id_product` 
        AND sav.`id_product_attribute` = 0
        '.StockAvailable::addSqlShopRestriction(null, null, 'sav').') ';

        $alias = 'sa';
        $alias_image = 'image_shop';

        $id_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int)$this->context->shop->id : 'a.id_shop_default';

        if (Configuration::get('CEDFYNDIQ_CATEGORY_MAP_ALL')) {
            $fyndiq_cat_filter = false;
        } else {
            $fyndiq_cat_filter = true;
        }
        $catgories =array();
        if ($fyndiq_cat_filter)
        {
            $cedfyndiqProduct = new CedfyndiqProduct();
            $mapped_categories = $cedfyndiqProduct->getAllMappedCategories();
            $mapped_categories = array_unique($mapped_categories);

            if (is_array($mapped_categories) && count($mapped_categories))
            {
                $catgories = $mapped_categories;
                if (count($catgories)) {
                    $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` 
                        AND sa.id_shop = '.$id_shop.')
                        LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                        AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")
                        LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                        AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                        LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                         LEFT JOIN `'._DB_PREFIX_.'fyndiq_products` wp ON (wp.product_id = a.`id_product`)
                        LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                        AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                        LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                        LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                        AND pd.`active` = 1)';
                }
            } else {
                $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` 
                AND sa.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")
                LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                 JOIN `'._DB_PREFIX_.'fyndiq_products` wp ON (wp.product_id = a.`id_product`)
                LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                AND pd.`active` = 1)';
            }
        } else {
            $this->_join .= ' JOIN `'._DB_PREFIX_.'product_shop` sa ON (a.`id_product` = sa.`id_product` 
            AND sa.id_shop = '.$id_shop.')

                LEFT JOIN `'._DB_PREFIX_.'product_lang` b ON (a.`id_product` = b.id_product 
                AND b.id_shop = '.$id_shop.' AND b.`id_lang`="'.(int)$this->context->language->id.'")
                LEFT JOIN `'._DB_PREFIX_.'category_lang` cl ON ('.$alias.'.`id_category_default` = cl.`id_category` 
                AND b.`id_lang` = cl.`id_lang` AND cl.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'shop` shop ON (shop.id_shop = '.$id_shop.')
                 JOIN `'._DB_PREFIX_.'fyndiq_products` wp ON (wp.product_id = a.`id_product`)
                LEFT JOIN `'._DB_PREFIX_.'image_shop` image_shop ON (image_shop.`id_product` = a.`id_product` 
                AND image_shop.`cover` = 1 AND image_shop.id_shop = '.$id_shop.')
                LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_image` = image_shop.`id_image`)
                LEFT JOIN `'._DB_PREFIX_.'product_download` pd ON (pd.`id_product` = a.`id_product` 
                AND pd.`active` = 1)';
        }


        $this->_select .= 'shop.`name` AS `shopname`, a.`id_shop_default`, ';
        $this->_select .= 'wp.`category` AS `fyndiq_category`, ';

        $this->_select .= $alias_image.'.`id_image` AS `id_image`, a.`id_product` as `id_temp`, cl.`name` 
        AS `name_category`, '.$alias.'.`price`, 0 
        AS `price_final`, a.`is_virtual`, pd.`nb_downloadable`, sav.`quantity` 
        AS `sav_quantity`, '.$alias.'.`active`, IF(sav.`quantity`<=0, 1, 0) AS `badge_danger`';

//        if (count($catgories)) {
//            $this->_where = 'AND cl.`id_category` IN ('.implode(',', (array)$catgories).')';
//        }
        if (count($catgories)) {
            $this->_where = 'AND '.$alias.'.`id_category_default` IN ('.implode(',', (array)$catgories).')';
        }
        $this->_where .= 'AND wp.product_id > 0';
        $this->_use_found_rows = true;

        $this->fields_list = array();
        $this->fields_list['id_product'] = array(
            'title' => ('ID'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int'
        );
        $this->fields_list['image'] = array(
            'title' => ('Image'),
            'align' => 'center',
            'image' => 'p',
            'orderby' => false,
            'filter' => false,
            'search' => false
        );
        $this->fields_list['name'] = array(
            'title' => ('Name'),
            'filter_key' => 'b!name',
            'class' => 'fixed-width-sm',
        );
        $this->fields_list['reference'] = array(
            'title' => ('Reference'),
            'align' => 'left',
        );


        /* if (Shop::isFeatureActive() && Shop::getContext() != Shop::CONTEXT_SHOP) {
             $this->fields_list['shopname'] = array(
                 'title' => ('Default shop'),
                 'filter_key' => 'shop!name',
             );
         } else {
             $this->fields_list['name_category'] = array(
                 'title' => ('Category'),
                 'filter_key' => 'cl!name',
             );
         }*/
        $this->fields_list['price'] = array(
            'title' => ('Base price'),
            'type' => 'price',
            'align' => 'text-right',
            'filter_key' => 'a!price'
        );
        $this->fields_list['price_final'] = array(
            'title' => ('Final price'),
            'type' => 'price',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => false,
            'search' => false
        );

        if (Configuration::get('PS_STOCK_MANAGEMENT')) {
            $this->fields_list['sav_quantity'] = array(
                'title' => ('Quantity'),
                'type' => 'int',
                'align' => 'text-right',
                'filter_key' => 'sav!quantity',
                'orderby' => true,
                'badge_danger' => true,
                'hint' => ('This is the quantity available in the current shop/group.'),
            );
        }

        $this->fields_list['active'] = array(
            'title' => ('Status'),
            'active' => 'status',
            'filter_key' => $alias.'!active',
            'align' => 'text-center',
            'type' => 'bool',
            'class' => 'fixed-width-sm',
            'orderby' => false
        );

        $this->fields_list['fyndiq_status'] = array(
            'title' => ('Fyndiq Status'),
            'type' => 'text',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => true,
            'class' => 'fixed-width-xs',
            'search' => true

        );
        $this->fields_list['cat_name'] = array(
            'title' => ('Fyndiq Category'),
            'type' => 'text',
            'align' => 'text-right',
            'havingFilter' => true,
            'orderby' => true,
            'class' => 'fixed-width-xs',
            'search' => true
        );

        $this->fields_list['error_message'] = array(
            'title' => $this->l('View Details'),
            'align' =>'text-left',
            'search' => false,
            'class' => 'fixed-width-xs',
            'callback' => 'viewDetailsButton',
        );

        if ($id_fyndiqcat = Tools::getValue('id_fyndiqcat')) {
            $this->id_fyndiqcat = $id_fyndiqcat;
            $this->context->cookie->id_fyndiqcat = $id_fyndiqcat;
        } elseif ($id_category = $this->context->cookie->id_fyndiqcat) {
            $this->id_fyndiqcat = $id_fyndiqcat;
        }

        // Any action performed w/o selecting product
        if (Tools::getIsset('productSelectError') && Tools::getValue('productSelectError')) {
            $this->errors[] = "Please Select Product";
        }

        // Save Product
        if (Tools::getIsset('productSaveSuccess') && Tools::getValue('productSaveSuccess')) {
            $this->confirmations[] = "Product Data Saved Successfully";
        }

        if (Tools::getIsset('productSaveError') && Tools::getValue('productSaveError')) {
            $this->errors[] = "Some error while saving Product Data";
        }

        // Upload Product
        if (Tools::getIsset('productUploadSuccess') && Tools::getValue('productUploadSuccess')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->confirmations[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->confirmations[] = 'Product Uploaded Successfully!';
            }
        }

        if (Tools::getIsset('productUploadError') && Tools::getValue('productUploadError')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->errors[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->errors[] = 'Failed to upload Product';
            }
        }

        // Include Product
        if (Tools::getIsset('productIncludeSuccess') && Tools::getValue('productIncludeSuccess')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->confirmations[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->confirmations[] = 'Product Included Successfully!';
            }
        }

        if (Tools::getIsset('productIncludeError') && Tools::getValue('productIncludeError')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->errors[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->errors[] = 'Failed to include Product';
            }
        }

        // Exclude Product
        if (Tools::getIsset('productExcludeSuccess') && Tools::getValue('productExcludeSuccess')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->confirmations[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->confirmations[] = 'Product Excluded Successfully!';
            }
        }

        if (Tools::getIsset('productExcludeError') && Tools::getValue('productExcludeError')) {
            if(Tools::getIsset('msg') && Tools::getValue('msg'))
            {
                $this->errors[] = json_decode(Tools::getValue('msg'), true);
            } else {
                $this->errors[] = 'Failed to exclude Product';
            }
        }

        // Remove Product Category
        if (Tools::getIsset('productRemoveCatSuccess') && Tools::getValue('productRemoveCatSuccess')) {
            $this->confirmations[] = "Category Removed Successfully";
        }

        // Assign Product Category
        if (Tools::getIsset('productAssignCatSuccess') && Tools::getValue('productAssignCatSuccess')) {
            $this->confirmations[] = "Category Assinged Successfully";
        }

        // Category not selected for assign product category
        if (Tools::getIsset('productAssignCatError') && Tools::getValue('productAssignCatError')) {
            $this->errors[] = "Please select Fyndiq Category";
        }

    }

    public function viewDetailsButton($data, $rowData)
    {
        $productName = isset($rowData['name'])?$rowData['name']: '';
        $this->context->smarty->assign(
            array(
                'validationJson' => $data,
                'productName' => $productName
            )
        );
        return $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/product/product_validation_detail.tpl'
        );
    }

    protected function processBulkUpload($product_ids = array())
    {
        if (is_array($product_ids) && count($product_ids)) {
            $CedfyndiqProduct = new CedfyndiqProduct();
            $result = $CedfyndiqProduct->uploadProducts($product_ids);
            return $result;
        }
    }

    public function initContent()
    {
        $page = (int) Tools::getValue('page');
        if (isset($id_fyndiqcat) && ($id_fyndiqcat = $this->id_fyndiqcat)) {
            self::$currentIndex .= '&id_fyndiqcat='.$this->id_fyndiqcat . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
        }
        parent::initContent();
    }

    public function processBulkAssignCat()
    {
        $page = (int) Tools::getValue('page');
        $link = new LinkCore();

        $db = Db::getInstance();
        $cedfyndiqProduct = new CedfyndiqProduct;
        $ids = $this->boxes;
        $fyndiqCat = (int)$this->id_fyndiqcat;
        if(!empty($fyndiqCat)) {
            if(!empty($ids)) {
                $catName = $cedfyndiqProduct->getCategoryNameById($fyndiqCat);
                foreach ($ids as $id) {
                    //$db->execute("ALTER TABLE `" . _DB_PREFIX_ . "fyndiq_products` ADD `cat_name` text NOT NULL");
                    $data = $db->executeS(
                        "SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                           WHERE `product_id`='" . (int)$id . "'"
                    );

                    if (isset($data[0]['id']) && !empty($data[0]['id'])) {

                        $res = $db->update(
                            'fyndiq_products',
                            array(
                                'category' => pSQL($fyndiqCat),
                                'cat_name' => pSQL($catName),
                            ),
                            'product_id='.(int)$id.''
                        );
                    } else {
                        $res = $db->insert(
                            'fyndiq_products',
                            array(
                                'category' => pSQL($fyndiqCat),
                                'cat_name' => pSQL($catName),
                                'product_id' => (int)$id
                            )
                        );
                    }
                }

                if($res) {
                    $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productAssignCatSuccess=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->confirmations[] = "Category Assinged Successfully";
                }
            } else {
                $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->errors[] = "Please select Product(s)";
            }
        } else {
            $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productAssignCatError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
            Tools::redirectAdmin($controller_link);
            $this->errors[] = "Please select Fyndiq Category";
        }
        $this->id_fyndiqcat = '';
        $this->context->cookie->id_fyndiqcat = '';
    }

    public function processBulkRemoveCat()
    {
        $page = (int) Tools::getValue('page');
        $link = new LinkCore();

        $db = Db::getInstance();
        $ids = $this->boxes;
        if(!empty($ids)) {
            foreach ($ids as $id) {
                $data = $db->executeS(
                    "SELECT `id` FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$id . "'"
                );
                //echo '<pre>'; print_r($data); die;
                if (isset($data[0]['id']) && !empty($data[0]['id'])) {
                    $res = $db->update(
                        'fyndiq_products',
                        array(
                            'category' => pSQL(''),
                            'cat_name' => pSQL(''),
                        ),
                        'product_id='.(int)$id.''
                    );
                } else {
                    $res = $db->insert(
                        'fyndiq_products',
                        array(
                            'category' => pSQL(''),
                            'cat_name' => pSQL(''),
                            'product_id' => (int)$id
                        )
                    );
                }
            }
            if($res) {
                $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productRemoveCatSuccess=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                Tools::redirectAdmin($controller_link);
                $this->confirmations[] = "Category Removed Successfully";
            }
        } else {
            $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
            Tools::redirectAdmin($controller_link);
            $this->errors[] = "Please select Product(s)";
        }
        $this->id_fyndiqcat = '';
        $this->context->cookie->id_fyndiqcat = '';
    }

    protected function processBulkInclude($product_ids = array())
    {
        $db = Db::getInstance();
        if (is_array($product_ids) && count($product_ids))
        {
            $error_message = array();
            $success_message = array();
            foreach($product_ids as $product_id)
            {
                $status = $db->executeS(
                    "SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$product_id . "'"
                );
                if (isset($status[0]) &&!empty($status[0]['fyndiq_status']))
                {
                    $res = $db->update(
                        'fyndiq_products',
                        array(
                            'fyndiq_status' => pSQL('')
                        ),
                        'product_id="'.(int)$product_id.'"'
                    );
                }
                if($res) {
                    $success_message[] = 'Product Id '.$product_id.' is included successfully.';
                } else {
                    $error_message[] = 'Failed to include product Id '.$product_id.' because it is not excluded';
                }
            }

            if(is_array($error_message) && !empty($error_message))
            {
                $response['error'] = implode(',', $error_message);
            } elseif(is_array($success_message) && !empty($success_message))
            {
                $response['success'] = implode(',', $success_message);
            } else {
                $response['error'] = 'Error while including product(s) - '. implode(',', $product_ids);
            }
            //$result = $this->includeFeed($product_ids);
            return $response;
        }
    }
    protected function processBulkExclude($product_ids = array())
    {
        $db = Db::getInstance();
        if (is_array($product_ids) && count($product_ids))
        {
            $error_message = array();
            $success_message = array();
            foreach($product_ids as $product_id)
            {
                $status = $db->getValue(
                    "SELECT `id` FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$product_id . "'"
                );

                if (!empty($status))
                {
                    $res = $db->update(
                        'fyndiq_products',
                        array(
                            'fyndiq_status' => pSQL('Excluded')
                        ),
                        'product_id="'.(int)$product_id.'"'
                    );
                }
                else
                {
                    $res = $db->insert(
                        'fyndiq_products',
                        array(
                            'fyndiq_status' => pSQL('Excluded'),
                            'product_id' => (int)$product_id
                        )
                    );
                }

                if($res) {
                    $success_message[] = 'Product Id '.$product_id.' is excluded successfully.';
                } else {
                    $error_message[] = 'Failed to exclude Product Id '. $product_id;
                }
            }

            if(is_array($error_message) && !empty($error_message))
            {
                $response['error'] = implode(',', $error_message);
            } elseif(is_array($success_message) && !empty($success_message))
            {
                $response['success'] = implode(',', $success_message);
            } else {
                $response['error'] = 'Error while excluding product(s) - '. implode(',', $product_ids);
            }
            //$result = $this->excludeFromFeed($product_ids);
            return $response;
        }
    }

    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = false
    ) {
        $orderByPriceFinal = (empty($orderBy) ? ($this->context->cookie->__get($this->table.'Orderby') ?
            $this->context->cookie->__get($this->table.'Orderby') :
            'id_'.$this->table) : $orderBy);
        $orderWayPriceFinal = (empty($orderWay) ? ($this->context->cookie->__get($this->table.'Orderway') ?
            $this->context->cookie->__get($this->table.'Orderby') :
            'ASC') : $orderWay);
        if ($orderByPriceFinal == 'price_final') {
            $orderBy = 'id_'.$this->table;
            $orderWay = 'ASC';
        }
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
        $nothing = null;
        /* update product quantity with attributes ...*/
        $nb = count($this->_list);
        if ($this->_list) {
            $context = $this->context->cloneContext();
            $context->shop = clone($context->shop);
            /* update product final price */
            for ($i = 0; $i < $nb; $i++) {
                if (Context::getContext()->shop->getContext() != Shop::CONTEXT_SHOP) {
                    $context->shop = new Shop((int)$this->_list[$i]['id_shop_default']);
                }

                // convert price with the currency from context
                $this->_list[$i]['price'] = Tools::convertPrice(
                    $this->_list[$i]['price'],
                    $this->context->currency,
                    true,
                    $this->context
                );
                $this->_list[$i]['price_tmp'] = Product::getPriceStatic(
                    $this->_list[$i]['id_product'],
                    true,
                    null,
                    (int)Configuration::get('PS_PRICE_DISPLAY_PRECISION'),
                    null,
                    false,
                    true,
                    1,
                    true,
                    null,
                    null,
                    null,
                    $nothing,
                    true,
                    true,
                    $context
                );
            }
        }

        if ($orderByPriceFinal == 'price_final') {
            if (Tools::strtolower($orderWayPriceFinal) == 'desc') {
                uasort($this->_list, 'cmpPriceDesc');
            } else {
                uasort($this->_list, 'cmpPriceAsc');
            }
        }
        for ($i = 0; $this->_list && $i < $nb; $i++) {
            $this->_list[$i]['price_final'] = $this->_list[$i]['price_tmp'];
            unset($this->_list[$i]['price_tmp']);
        }
    }


    public function initProcess()
    {
        if (Tools::isSubmit('submitProductFormAndStay')
            || Tools::isSubmit('submitProductForm')) {
            $this->id_object = (int)Tools::getValue('id_product');
            $this->object = new Product($this->id_object);
            $this->tab_display = Tools::getValue('currentTab');
        }
        if (!$this->action) {
            parent::initProcess();
        } else {
            $this->id_object = (int)Tools::getValue($this->identifier);
        }
    }

    /**
     * postProcess handle every checks before saving products information
     *
     * @return void
     */
    public function postProcess()
    {
        try {
            $page = (int) Tools::getValue('page');
            $link = new LinkCore();
//            $controller_link = $link->getAdminLink('AdminCedfyndiqProducts') . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');

            if (Tools::getIsset('action') && Tools::getIsset('country_code')
                && Tools::getValue('country_code')
                && (Tools::getValue('action')=='getFyndiqLanguageCurrency')) {
                $this->getFyndiqLanguageCurrency();
            }
            if (Tools::isSubmit('submitProductSave')) {
                $status = $this->saveFyndiqProduct(Tools::getAllValues());
                if ($status) {
                    $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productSaveSuccess=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->confirmations[] = 'Product Data Saved Successfully';
                } else {
                    $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productSaveError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->errors[] ='Some error while saving Product Data';
                }
            }

            // Upload Product
            if (Tools::getIsset('submitBulkuploadproduct')) {
                if (Tools::getIsset('productBox')
                    &&  count(Tools::getValue('productBox')))
                {
                    $result = $this->processBulkUpload(Tools::getValue('productBox'));

                    if (isset($result['error']) && $result['error']) {
                        if(is_array($result['error'])){
                            $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productUploadError=1&msg=' . json_encode(implode(',', $result['error'])) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                            Tools::redirectAdmin($controller_link);
                            $this->errors[] = implode(',', $result['error']);
                        } else {
                            $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productUploadError=1&msg=' . json_encode($result['error']) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                            Tools::redirectAdmin($controller_link);
                            $this->errors[] = $result['error'];
                        }
                    }
                    if (isset($result['success']) && $result['success']) {
                        $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productUploadSuccess=1&msg=' . json_encode($result['success']) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                        Tools::redirectAdmin($controller_link);
                        $this->confirmations[] = $result['success'];
                    }
                } else {
                    $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->errors[] = 'Please Select Product';
                }
            }

            // Include Product
            if (Tools::getIsset('submitBulkincludeproduct')) {
                if (Tools::getIsset('productBox')
                    &&  count(Tools::getValue('productBox'))) {
                    $result = $this->processBulkInclude(Tools::getValue('productBox'));

                    if (isset($result['error']) && $result['error']) {
                        $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productIncludeError=1&msg=' . json_encode($result['error']) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                        Tools::redirectAdmin($controller_link);
                        $this->errors[] = $result['error'];
                    }
                    if (isset($result['success']) && $result['success']) {
                        $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productIncludeSuccess=1&msg=' . json_encode($result['success']) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                        Tools::redirectAdmin($controller_link);
                        $this->confirmations[] = $result['success'];
                    }
                } else {
                    $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->errors[] = 'Please Select Product';
                }
            }

            // Exclude Product
            if (Tools::getIsset('submitBulkexcludeproduct'))
            {
                if (Tools::getIsset('productBox')
                    &&  count(Tools::getValue('productBox')))
                {
                    $result = $this->processBulkExclude(Tools::getValue('productBox'));

                    if (isset($result['error']) && $result['error']) {
                        $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productExcludeError=1&msg=' . json_encode($result['error']) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                        Tools::redirectAdmin($controller_link);
                        $this->errors[] = $result['error'];
                    }
                    if (isset($result['success']) && $result['success']) {
                        $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productExcludeSuccess=1&msg=' . json_encode($result['success']) . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                        Tools::redirectAdmin($controller_link);
                        $this->confirmations[] = $result['success'];
                    }
                } else {
                    $controller_link = $link->getAdminLink('AdminCedfyndiqProducts'). '&productSelectError=1' . ($page > 1 ? '&submitFilter'.$this->table.'='.(int)$page : '');
                    Tools::redirectAdmin($controller_link);
                    $this->errors[] = 'Please Select Product';
                }
            }

            // Clear Feed
            if (Tools::getIsset('clear_feed')) {
                $this->clearFeedData();
            }

            // Fetch Status
            if (Tools::getIsset('fetch_status')) {
                $this->fetchProductStatus();
            }
        } catch (PrestaShopException $e) {
            $this->errors[] = $e;
        }
        parent::postProcess();
    }

    protected function isTabSubmitted($tab_name)
    {
        if (!is_array($this->submitted_tabs)) {
            $this->submitted_tabs = Tools::getValue('submitted_tabs');
        }

        if (is_array($this->submitted_tabs) && in_array($tab_name, $this->submitted_tabs)) {
            return true;
        }

        return false;
    }


    public function renderList()
    {
        $feed_url = Configuration::get('CEDFYNDIQ_FEED_URL');
        $this->context->smarty->assign(array(
            'feed_url' => $feed_url
        ));
        $this->addRowAction('edit');
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/product/product_list.tpl'
        );

        if (Tools::getIsset('fetch_status')) {
            $response = $this->productInfo();
            $this->context->smarty->assign(array('response' => $response));

            $parent = $this->context->smarty->fetch(
                _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/product/fetch_status.tpl');
            return $parent;
        }

        $CedfyndiqProduct = new CedfyndiqProduct();
        $categories = $CedfyndiqProduct->getAllFyndiqCategory();
        //echo '<pre>'; print_r($categories); die;
        if(Tools::getValue('submitFilterproduct')){
            $reurl = $this->context->link->getAdminLink('AdminCedfyndiqProducts').'&submitFilterproduct='.Tools::getValue('submitFilterproduct');
        } else {
            $reurl = $this->context->link->getAdminLink('AdminCedfyndiqProducts');
        }
        $this->context->smarty->assign(array(
            'controllerUrl' => $reurl,
            'token' => $this->token,
            'fyndiqCategories' => $categories,
            'idCurrentFyndiqCategory' => isset($this->id_fyndiqcat) ? $this->id_fyndiqcat : '',
        ));
        $r = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ . 'cedfyndiq/views/templates/admin/product/category_selector.tpl');

        return $parent.$r.parent::renderList();
    }


    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['clear_feed'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqProducts').'&clear_feed',
                'desc' => 'Clear Feed',
                'icon' => 'process-icon-eraser'
            );
            $this->page_header_toolbar_btn['download_feed'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqDeveloper'),
                'desc' => 'Download Feed',
                'icon' => 'process-icon-download'
            );
            $this->page_header_toolbar_btn['upload_all'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqUploadall'),
                'desc' => 'Upload All',
                'icon' => 'process-icon-upload'
            );
            $this->page_header_toolbar_btn['fetch_status'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqProducts').'&fetch_status',
                'desc' => 'Fetch Status',
                'icon' => 'process-icon-download'
            );
            // $this->page_header_toolbar_btn['sync_qty'] = array(
            //     'href' => $this->context->link->getAdminLink('AdminCedfyndiqStock').'&sync_qty=true',
            //     'desc' => 'Update Stock',
            //     'icon' => 'process-icon-upload'
            // );
        }
        parent::initPageHeaderToolbar();
    }

    public function initToolbar()
    {
        $this->toolbar_btn['export'] = array(
            'href' => self::$currentIndex.'&export'.$this->table.'&token='.$this->token,
            'desc' => $this->l('Export')
        );
        if ($this->display == 'edit' || $this->display == 'add') {
            $this->toolbar_btn['save'] = array(
                'short' => 'Save',
                'href' => '#',
                'desc' => ('Save'),
            );

            $this->toolbar_btn['save-and-stay'] = array(
                'short' => 'SaveAndStay',
                'href' => '#',
                'desc' => ('Save and stay'),
            );
        }

        $this->context->smarty->assign('toolbar_scroll', 1);
        $this->context->smarty->assign('show_toolbar', 1);
        $this->context->smarty->assign('toolbar_btn', $this->toolbar_btn);
    }

    public function downloadFeed()
    {
        $filename = _PS_MODULE_DIR_ . 'cedfyndiq/product_upload/product_feed.csv';

        if(file_exists($filename)){
            header('Content-Description: File Transfer');
//            header('Content-Type: application/force-download');
            header('Content-Type: text/csv;charset=UTF-8');
            header("Content-language: sv");
            header("Content-Disposition: attachment; filename=\"" . basename($filename) . "\";");
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filename));
            // ob_clean();
            // flush();
            print chr(255) . chr(254) . mb_convert_encoding(readfile($filename), 'UTF-8');
            exit('ok');
        } else {
            return 'File Not Exists!';
        }
    }

    public function clearFeedData()
    {
        $db = Db::getInstance();
        try {
            $sql = "DELETE FROM  `"._DB_PREFIX_."fyndiq_final_products`";
            $res = $db->execute($sql);
            if ($res) {
                $csv_dir = _PS_MODULE_DIR_.'cedfyndiq/product_upload/';
                if (!is_dir($csv_dir)) {
                    mkdir($csv_dir, '0777', true);
                }
                $file = fopen($csv_dir.'product_feed.csv', 'w');

                fputcsv($file, $header);
                fclose($file);
                $this->confirmations[] = 'Feed data cleared successfully';
            } else {
                $this->errors[] = 'Failed to clear feed data';
            }
        } catch (\Exception $e) {
            $this->errors[] = $e->getMessage();
        }
    }

    public function fetchProductStatus()
    {
        try {
            $CedfyndiqHelper = new CedfyndiqHelper;
            $CedfyndiqProduct = new CedfyndiqProduct;
            $url = 'product_info/';
            $params = array();
            $response = $CedfyndiqProduct->syncProducts($url, $params);

            if (isset($response['error']) && is_array($response['error']) && !empty($response['error']))
            {
                $this->errors[] = $response['message'];

            } else {
                $this->confirmations[] = $response['message'];
            }
        } catch(\Exception $e) {
            $CedfyndiqHelper->log(
                'Cron syncProducts',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            $this->errors[] = $e->getMessage();
        }
    }

    /**
     * renderForm contains all necessary initialization needed for all tabs
     *
     * @return string|void
     * @throws PrestaShopException
     */
    public function renderForm()
    {
        $this->product_name = $this->object->name[$this->context->language->id];
        $product = $this->object;
        $fyndiqHelper = new CedfyndiqHelper;
        $this->context->smarty->assign(
            array(
                'currentIndex' => self::$currentIndex,
                'currentToken' => $this->token,
                'currentObject' => $product,
                'hasAttribute' => $product->hasAttributes(),
            )
        );
        $db =  Db::getInstance();
        $fyndiq_products = $db->ExecuteS("SELECT `attributes` FROM `"._DB_PREFIX_."fyndiq_products` 
        WHERE `product_id`='".(int)$this->object->id."'");

        if (isset($fyndiq_products['0']['attributes'])) {
            $fyndiq_products = unserialize($fyndiq_products['0']['attributes']);
        } elseif (count(Tools::getAllValues())) {
            $fyndiq_products = Tools::getAllValues();
        } else {
            $fyndiq_products = array();
        }

        $validation_array = $fyndiqHelper->getValidationArray();

        if (is_array($validation_array) && count($validation_array)) {
            $this->context->smarty->assign(array('attributes'  => $validation_array));
        } else {
            $this->context->smarty->assign(array('attributes'  => array()));
        }
        if (isset($fyndiq_products['fyndiq_status'])) {
            $this->context->smarty->assign(array('fyndiq_status' => $fyndiq_products['fyndiq_status']));
        }

        $this->context->smarty->assign(array('fyndiq_products' => $fyndiq_products));

        $this->context->smarty->assign(array('product_id' => Tools::getValue('product_id')));

        $page = (int)Tools::getValue('page');

        $this->context->smarty->assign(
            array('back'=> $this->context->link->getAdminLink('AdminCedfyndiqProducts').($page > 1 ? '&page='.(int)$page : ''))
        );

        if (Validate::isLoadedObject(($this->object))) {
            $id_product = (int)$this->object->id;
        } else {
            $id_product = (int)Tools::getvalue('id_product');
        }

        $this->context->smarty->assign(array(
            'action' => $this->context->link->getAdminLink('AdminCedfyndiqProducts').'&'.($id_product ?
                    'updateproduct&id_product='.(int)$id_product :
                    'uploadproduct').($page > 1 ? '&page='.(int)$page : '')));

        $this->context->smarty->assign(array('id_product' => $id_product));

        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/product/product_form.tpl'
        );
        if (Tools::getValue('success_message')) {
            $this->confirmations[] = Tools::getValue('success_message');
        }
        parent::renderForm();
        return $parent;
    }
    public function getFyndiqLanguageCurrency()
    {
        $cedfyndiqHelper = new CedfyndiqHelper;
        $response = array();
        $response['language'] = $cedfyndiqHelper->getFyndiqLanguage();
        $response['currency'] = $cedfyndiqHelper->getFyndiqCurrencyCode();
        die(json_encode($response));
    }

    public function saveFyndiqProduct($data)
    {
        $db =  Db::getInstance();
        if (isset($data['submitProductSave'])) {
            unset($data['submitProductSave']);
        }
        if (isset($data['controller'])) {
            unset($data['controller']);
        }
        if (isset($data['token'])) {
            unset($data['token']);
        }
        if (isset($data['controllerUri'])) {
            unset($data['controllerUri']);
        }

        $id_product = Tools::getValue('id_product');

        if (isset($id_product) && $id_product) {
            $result = $db->ExecuteS("SELECT * FROM `"._DB_PREFIX_."fyndiq_products` 
            where `product_id`='".(int)$id_product."'");

            if (count($result)) {
                $status = $db->Execute("UPDATE `"._DB_PREFIX_."fyndiq_products` 
                SET `attributes` = '".pSQL(serialize($data))."' 
                where `product_id`='".(int)$id_product."'");
                if ($status) {
                    return true;
                } else {
                    return false;
                }
            } else {
                $status = $db->Execute("INSERT INTO `"._DB_PREFIX_."fyndiq_products` 
                (`attributes`, `product_id`) 
                VALUES ('".pSQL(serialize($data))."', '".(int)$id_product."')");
                if ($status) {
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $this->addJqueryUI('ui.datepicker');
    }

    public function productInfo()
    {
        $params = array();
        $cedFyndiqHelper = new CedfyndiqHelper();
        $res = $cedFyndiqHelper->fyndiqGetRequest('product_info/', $params);
        // 
        if(isset($res['success']) && $res['success']) {
            $response = Tools::jsonDecode($res['response'], true);
            return $response;
        } else {
            $response = Tools::jsonDecode($res['message'], true);
            $this->errors[] = $response['detail'];
        }
    }

}
