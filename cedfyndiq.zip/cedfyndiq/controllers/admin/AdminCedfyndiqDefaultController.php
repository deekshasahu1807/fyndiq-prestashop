<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

require_once _PS_MODULE_DIR_ . 'cedfyndiq/classes/CedfyndiqHelper.php';
class AdminCedfyndiqDefaultController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;

        if (Tools::getIsset('submitDefaultValue') && (count(Tools::getAllValues())>4)) {
            $post = Tools::getAllValues();
            unset($post['submitDefaultValue']);
            unset($post['controller']);
            unset($post['token']);
            unset($post['controllerUri']);
            $response = $this->saveDefaultValueToFyndiq($post);
            if ($response) {
                $this->confirmations[] = 'Default Value saved Successfully.';
            } else {
                $this->errors[] = ' There may be some error .';
            }
        }
        parent::__construct();
    }
    public function renderList()
    {
        $cedfyndiqProduct = new CedfyndiqProduct();
        $cedfyndiqHelper = new CedfyndiqHelper();
        $validation_array = $cedfyndiqHelper->getValidationArray();
        $fyndiqCategory = $cedfyndiqHelper->getFyndiqCategories();
        if(is_array($fyndiqCategory) && !empty($fyndiqCategory)){
            $this->context->smarty->assign(array('fyndiqCategories'  => $fyndiqCategory));
        }
        $this->context->smarty->assign(
            array(
                'currentIndex' => self::$currentIndex,
                'currentToken' => $this->token,
            )
        );
        $already_default = $cedfyndiqProduct->getSavedDefaultValues();
        if (is_array($already_default) && count($already_default)) {
            $this->context->smarty->assign(array('already_default'  => $already_default));
        } else {
            $this->context->smarty->assign(array('already_default'  => array()));
        }


        if (is_array($validation_array) && count($validation_array)) {
            $this->context->smarty->assign(array('attributes'  => $validation_array));
        } else {
            $this->context->smarty->assign(array('attributes'  => array()));
        }

        $this->context->smarty->assign(array('action'=> $this->context->link->getAdminLink('AdminCedfyndiqDefault')));
        $this->context->smarty->assign(array('back'=> $this->context->link->getAdminLink('AdminCedfyndiqDefault')));
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/default/default_form.tpl'
        );
        parent::renderList();
        return $parent;
    }
   
    public function saveDefaultValueToFyndiq($data)
    {
        $db = Db::getInstance();
        $db->Execute("DELETE FROM `"._DB_PREFIX_."fyndiq_default_values`");
        $sql = "INSERT INTO `"._DB_PREFIX_."fyndiq_default_values` (`fyndiq_attribute`, `default_value`) VALUES ";
        foreach ($data as $key => $value) {
            $sql .= "('".pSQL($key)."', '".pSQL($value)."'), ";
        }
        $sql = rtrim($sql, ', ');
        $status = $db->Execute($sql);
        if ($status) {
            return true;
        } else {
            return false;
        }
    }
    public function getFyndiqLanguageCurrency()
    {
        $cedfyndiqHelper = new CedfyndiqHelper;
        $response = array();
        $response['language'] = $cedfyndiqHelper->getFyndiqLanguage();
        $response['currency'] = $cedfyndiqHelper->getFyndiqCurrencyCode();
        die(json_encode($response));
    }
}
