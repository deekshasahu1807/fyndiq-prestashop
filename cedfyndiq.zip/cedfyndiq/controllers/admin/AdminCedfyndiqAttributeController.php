<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

require_once _PS_MODULE_DIR_ . 'cedfyndiq/classes/CedfyndiqHelper.php';
require_once _PS_MODULE_DIR_ . 'cedfyndiq/classes/CedfyndiqProduct.php';

class AdminCedfyndiqAttributeController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
     
        if (Tools::getIsset('submitAttributeMapping') && (count(Tools::getAllValues())>4)) {
            $post = Tools::getAllValues();
            unset($post['submitAttributeMapping']);
            unset($post['controller']);
            unset($post['token']);
            unset($post['controllerUri']);
            $response = $this->mapAttributeToFyndiq($post);
            if ($response) {
                $this->confirmations[] = 'Attributes Mapped Successfully.';
            } else {
                $this->errors[] = 'Not Mapped, There may be some error .';
            }
        }
        parent::__construct();
    }
    public function renderList()
    {
        $fyndiqHelper = new CedfyndiqHelper;
        $fyndiqProduct = new CedfyndiqProduct();
        $already_mapped = array();
        $mapped_variant_attribute = array();
        $validation_array = $fyndiqHelper->getValidationArray();
        $variant_attributes = $fyndiqHelper->variantAttributes();
        $fyndiq_mapped_attributes = $fyndiqProduct->getMappedAttributes();

        foreach ($fyndiq_mapped_attributes as $fyndiqAttr => $presAttr) {
            if (!is_array($presAttr)) {
                $already_mapped[$fyndiqAttr] = $presAttr;
            } else {
                $mapped_variant_attribute[$fyndiqAttr] = $presAttr;
            }
        }
        if (is_array($already_mapped) && count($already_mapped)) {
            $this->context->smarty->assign(array('already_mapped'  => $already_mapped));
        } else {
            $this->context->smarty->assign(array('already_mapped'  => array()));
        }
        if (is_array($mapped_variant_attribute) && count($mapped_variant_attribute)) {
            $this->context->smarty->assign(array('mapped_variant_attribute'  => $mapped_variant_attribute));
        } else {
            $this->context->smarty->assign(array('mapped_variant_attribute'  => array()));
        }

        if (is_array($validation_array) && count($validation_array)) {
            $this->context->smarty->assign(array('attributes'  => $validation_array));
        } else {
            $this->context->smarty->assign(array('attributes'  => array()));
        }
        if (is_array($variant_attributes) && count($variant_attributes)) {
            $this->context->smarty->assign(array('variant_attributes'  => $variant_attributes));
        } else {
            $this->context->smarty->assign(array('variant_attributes'  => array()));
        }

        $features = $this->getFeatures();
        if (is_array($features) && count($features)) {
            $this->context->smarty->assign(array('features'  => $features));
        } else {
            $this->context->smarty->assign(array('features'  => array()));
        }

        $store_attributes = $this->getAttributes();
        if (is_array($store_attributes) && count($store_attributes)) {
            $this->context->smarty->assign(array('store_attributes'  => $store_attributes));
        } else {
            $this->context->smarty->assign(array('store_attributes'  => array()));
        }
        
        $variantAttributes = array();

        foreach($store_attributes as $index => $val){
            $index = $index+1;
            foreach($variant_attributes as $key => $value){
                $key_array = explode('-n-', $key);
                if($key_array[1] == 'name' && $key == 'article-property-n-name') {
                    $key_name = $key_array[0] . '-' . $index . '-' . $key_array[1];
                    $variantAttributes[$key_name] = $value;
                } else if($key_array[1] == 'value' && $key == 'article-property-n-value') {
                    $key_name = $key_array[0] . '-' . $index . '-' . $key_array[1];
                    $variantAttributes[$key_name] = $value;
                }
            }
        }

        if (is_array($variantAttributes) && count($variantAttributes)) {
            $this->context->smarty->assign(array('variant_attributes'  => $variantAttributes));
        }

        $store_attributes_value = $this->getAttributesValue();
        if (is_array($store_attributes_value) && count($store_attributes_value)) {
            $this->context->smarty->assign(array('store_attributes_value'  => $store_attributes_value));
        } else {
            $this->context->smarty->assign(array('store_attributes_value'  => array()));
        }

        $system_attributes = $this->getSystemAttributes();
        if (is_array($system_attributes) && count($system_attributes)) {
            $this->context->smarty->assign(array('system_attributes'  => $system_attributes));
        } else {
            $this->context->smarty->assign(array('system_attributes'  => array()));
        }

        $this->context->smarty->assign(array('action'=> $this->context->link->getAdminLink('AdminCedfyndiqAttribute')));
        $this->context->smarty->assign(array('back'=> $this->context->link->getAdminLink('AdminCedfyndiqAttribute')));
        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/attribute_map/form.tpl'
        );
        $this->informations[] = 'Map all the required Attributes that are mandatory at fyndiq';
        parent::renderList();
        return $parent;
    }
   
    public function getFeatures()
    {
        $db = Db::getInstance();
        $default_lang = ((int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $sql="SELECT `id_feature`,`name` FROM `"._DB_PREFIX_."feature_lang` 
              WHERE `id_lang`='".(int)$default_lang."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }
    }
    public function getAttributes()
    {
        $db = Db::getInstance();
        $default_lang = ((int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $sql="SELECT `id_attribute_group` as `id_attribute`,`name` FROM `"._DB_PREFIX_."attribute_group_lang` 
               WHERE `id_lang`='".(int)$default_lang."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }
    }

    public function getAttributesValue()
    {
        $db = Db::getInstance();
        $default_lang = ((int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $sql="SELECT a.`id_attribute`, al.`name`
               FROM `"._DB_PREFIX_."attribute_lang` AS al LEFT JOIN `"._DB_PREFIX_."attribute` AS a ON (al.`id_attribute` = a.`id_attribute` AND al.`id_lang`='".(int)$default_lang."') LEFT JOIN `"._DB_PREFIX_."attribute_group_lang` AS agl ON (agl.`id_attribute_group` = a.`id_attribute_group`) 
               WHERE agl.`id_lang`='".(int)$default_lang."'";
        $result = $db->ExecuteS($sql);
        if (is_array($result) && count($result)) {
            return $result;
        } else {
            return array();
        }

    }
    public function getSystemAttributes()
    {
        return array(
            'reference' => 'Reference',
            'name'      => 'Name',
            'description' => 'Description',
            'description_short' => 'Short Description',
            'id_manufacturer' => 'Manufacturer',
            'id_tax_rules_group' => 'Tax Rule',
            'price' => 'Final Price',
            'base_price' => 'Base Price',
            'upc' => 'UPC',
            'ean13' => 'EAN',
            'isbn' => 'ISBN',
            'mpn' => 'MPN',
            'quantity' => 'Quantity',
            );
    }
    public function mapAttributeToFyndiq($data)
    {
        $fyndiqHelper = new CedfyndiqHelper();
        $variant_attributes = array_keys($fyndiqHelper->variantAttributes());
        foreach ($variant_attributes as $at) {
            if (!in_array($at, array_keys($data))) {
                $data[$at] = array( 0 => '');
            }
        }
        $db = Db::getInstance();
        $db->Execute("DELETE FROM `"._DB_PREFIX_."fyndiq_attribute_mapping`");
        $sql = "INSERT INTO `"._DB_PREFIX_."fyndiq_attribute_mapping` 
        (`fyndiq_attribute`, `prestashop_attribute`,`fyndiqSkuId`) 
        VALUES ";
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $sql .= "('".pSQL($key)."', '".pSQL(json_encode($value))."', '".(int)'1'."'),";
            } else {
                $sql .= "('".pSQL($key)."', '".pSQL($value)."', '".(int)'0'."'), ";
            }
        }
        $sql = rtrim($sql, ', ');
        $status = $db->Execute($sql);
        if ($status) {
            return true;
        } else {
            return false;
        }
    }
}
