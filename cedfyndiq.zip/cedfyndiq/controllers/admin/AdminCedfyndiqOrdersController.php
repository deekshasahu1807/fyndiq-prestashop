<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php';
include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqOrder.php';

class AdminCedfyndiqOrdersController extends ModuleAdminController
{

    public $toolbar_title;

    protected $statuses_array = array();
    protected $bulk_actions;

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'order';
        $this->className = 'Order';
        $this->lang = false;
        $this->addRowAction('view');
        $this->addRowAction('acknowledge');
        $this->addRowAction('reject');
        
        $this->explicitSelect = true;
        $this->allow_export = true;
        //$this->deleted = false;
        $this->context = Context::getContext();

        $this->_select = '
        a.id_currency,
        a.id_order AS id_pdf,
        CONCAT(LEFT(c.`firstname`, 1), \'. \', c.`lastname`) AS `customer`,
        osl.`name` AS `osname`,
        os.`color`,
        IF((SELECT so.id_order FROM `'._DB_PREFIX_.'orders` so WHERE so.id_customer = a.id_customer
         AND so.id_order < a.id_order LIMIT 1) > 0, 0, 1) as new,
        country_lang.name as cname,
        IF(a.valid, 1, 0) badge_success';

        $this->_join = '
        LEFT JOIN `'._DB_PREFIX_.'customer` c ON (c.`id_customer` = a.`id_customer`)
        JOIN `'._DB_PREFIX_.'fyndiq_order` wo ON (wo.`prestashop_order_id` = a.`id_order`)
        LEFT JOIN `'._DB_PREFIX_.'address` address ON address.id_address = a.id_address_delivery
        LEFT JOIN `'._DB_PREFIX_.'country` country ON address.id_country = country.id_country
        LEFT JOIN `'._DB_PREFIX_.'country_lang` country_lang 
        ON (country.`id_country` = country_lang.`id_country` 
        AND country_lang.`id_lang` = '.(int)$this->context->language->id.')
        LEFT JOIN `'._DB_PREFIX_.'order_state` os 
        ON (os.`id_order_state` = a.`current_state`)
        LEFT JOIN `'._DB_PREFIX_.'order_state_lang` osl 
        ON (os.`id_order_state` = osl.`id_order_state` 
        AND osl.`id_lang` = '.(int)$this->context->language->id.')';
        $this->_orderBy = 'id_order';
        $this->_orderWay = 'DESC';
        $this->_use_found_rows = true;

        $statuses = OrderState::getOrderStates((int)$this->context->language->id);
        foreach ($statuses as $status) {
            $this->statuses_array[$status['id_order_state']] = $status['name'];
        }

        $this->fields_list = array(
            'id_order' => array(
                'title' => 'ID',
                'align' => 'text-center',
                'class' => 'fixed-width-xs'
            ),
            'fyndiq_order_id' => array(
                'title' => 'Purchase Order ID',
                'align' => 'text-center',
                'class' => 'fixed-width-xs'
            ),
            'reference' => array(
                'title' => 'Reference'
            ),
            'customer' => array(
                'title' => 'Customer',
                'havingFilter' => true,
            ),
        );

        $this->fields_list = array_merge($this->fields_list, array(
            'total_paid_tax_incl' => array(
                'title' => 'Total',
                'align' => 'text-right',
                'type' => 'price',
                'currency' => true,
                'callback' => 'setOrderCurrency',
                'badge_success' => true
            ),
            'payment' => array(
                'title' => 'Payment'
            ),
            'osname' => array(
                'title' => 'Status',
                'type' => 'select',
                'color' => 'color',
                'list' => $this->statuses_array,
                'filter_key' => 'os!id_order_state',
                'filter_type' => 'int',
                'order_key' => 'osname'
            ),
            'invoice' => array(
                'title' => 'Invoice',
                'type' => 'link',
                'filter_key' => 'wo!invoice',
                'callback' => 'downloadInvoice',
            ),
            'date_add' => array(
                'title' => 'Date',
                'align' => 'text-right',
                'type' => 'datetime',
                'filter_key' => 'a!date_add'
            )
            
        ));

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->ExecuteS('
        SELECT DISTINCT c.id_country, cl.`name`
        FROM `'._DB_PREFIX_.'orders` o
        '.Shop::addSqlAssociation('orders', 'o').'
        INNER JOIN `'._DB_PREFIX_.'address` a ON a.id_address = o.id_address_delivery
        INNER JOIN `'._DB_PREFIX_.'country` c ON a.id_country = c.id_country
        INNER JOIN `'._DB_PREFIX_.'country_lang` cl 
        ON (c.`id_country` = cl.`id_country` 
        AND cl.`id_lang` = '.(int)$this->context->language->id.')
        ORDER BY cl.name ASC');

            $country_array = array();
        foreach ($result as $row) {
            $country_array[$row['id_country']] = $row['name'];
        }

            $part1 = array_slice($this->fields_list, 0, 3);
            $part2 = array_slice($this->fields_list, 3);
            $part1['cname'] = array(
                'title' => 'Delivery',
                'type' => 'select',
                'list' => $country_array,
                'filter_key' => 'country!id_country',
                'filter_type' => 'int',
                'order_key' => 'cname'
            );
            $this->fields_list = array_merge($part1, $part2);

        $this->shopLinkType = 'shop';
        $this->shopShareDatas = Shop::SHARE_ORDER;

        if (Tools::isSubmit('id_order')) {
            $order = new Order((int)Tools::getValue('id_order'));
            $this->context->cart = new Cart($order->id_cart);
            $this->context->customer = new Customer($order->id_customer);
        }

        $this->bulk_actions = array(
            'handle' => array('text' => 'Order Handle', 'icon' => 'process-icon-upload'),
            'delivery' => array('text' => 'Delivery Notes', 'icon' => 'process-icon-download')
        );
    
        parent::__construct();
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['new_order'] = array(
                'href' => self::$currentIndex.'&fetchorder&token='.$this->token,
                'desc' => 'Fetch Order',
                'icon' => 'process-icon-new'
            );
        }
        parent::initPageHeaderToolbar();
    }

    public function initToolbar()
    {
        if ($this->display == 'view') {
            /** @var Order $order */
            $order = $this->loadObject();
            $customer = $this->context->customer;

            if (!Validate::isLoadedObject($order)) {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminCedfyndiqOrder'));
            }
            $this->toolbar_title[] = sprintf(
                'Order %1$s from %2$s %3$s',
                $order->reference,
                $customer->firstname,
                $customer->lastname
            );
            $this->addMetaTitle($this->toolbar_title[count($this->toolbar_title) - 1]);
        }
    }

    public function renderList()
    {
        if (Tools::getIsset('fetchorder')) {
            $CedfyndiqHelper = new CedfyndiqHelper;
            $CedfyndiqOrder = new CedfyndiqOrder();
            try {
                $status = $CedfyndiqHelper->isEnabled();
                if ($status) {
                    $url ='orders/';
                    $params= array();
                    
                    $order_data = $CedfyndiqOrder->fetchOrder($params, $url);

                    if (isset($order_data['success']) && $order_data['success']) {
                        $message = '';
                        if(isset($order_data['sub_message']) && !empty($order_data['sub_message'])){
                            $message = $order_data['sub_message'];
                        } else {
                            $message = $order_data['message'];
                        }
                        $this->confirmations[] = json_encode($message);
                    } elseif (isset($order_data['message'])) {
                        $fetch_errors = $order_data['message'];

                        $fetch_errors = json_decode($fetch_errors, true);
                        if (!$fetch_errors) {
                            $this->errors[] = $order_data['message'];
                        } else {
                            $error_msg = '';
                            if (is_array($fetch_errors['errors']) && count($fetch_errors['errors'])) {
                                foreach ($fetch_errors['errors'] as $value) {
                                    if (isset($value['0']['description'])) {
                                        $error_msg .=$value['0']['description'];
                                    }
                                }
                            }
                            $this->errors[] = $error_msg;
                        }
                    } else {
                        $this->errors[] = 'Can not fetch Order';
                    }
                }
            } catch (\Exception $e) {
                $CedfyndiqHelper->log(
                    'AdminCedfyndiqOrdersController::FetchOrder',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
            }
        }
         return parent::renderList();
    }

    public static function setOrderCurrency($echo, $tr)
    {
        $order = new Order($tr['id_order']);
        return Tools::displayPrice($echo, (int)$order->id_currency);
    }
    public function downloadInvoice($invoice, $rowData)
    {
        $this->context->smarty->assign('id_order', $rowData['id_order']);
        $this->context->smarty->assign('invoice', $invoice);
        $this->context->smarty->assign('token', $this->token);
        $downloadInvoice = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/orders/invoice.tpl'
        );
        return $downloadInvoice;

    }
    public function initContent()
    {
        parent::initContent();
    }
    public function renderView()
    {
        $order = $this->loadObject();
        $order_data = (array)$order;
        $id_order = 0;
        if (isset($order_data['id']) && $order_data['id']) {
            $id_order =$order_data['id'];
        }
        if ($id_order) {
            $sql = "SELECT `order_data` FROM `"._DB_PREFIX_."fyndiq_order` 
            WHERE `prestashop_order_id` = '".(int)$id_order."'";
            $db = Db::getInstance();
            $result = $db->ExecuteS($sql);

            if (is_array($result) && count($result) && isset($result['0']['order_data'])) {
                if (Tools::stripslashes($result['0']['order_data'])) {
                    $order_data = json_decode(Tools::stripslashes(trim($result['0']['order_data'], '"')), true);

                    $CedfyndiqHelper = new CedfyndiqHelper;

                    $this->context->smarty->assign(array('order_info' => array()));
                    if ($order_data) {

                        $shipping_data = array(
                            'delivery_firstname' => $order_data['delivery_firstname'],
                            'delivery_lastname' => $order_data['delivery_lastname'],
                            'delivery_phone' => $order_data['delivery_phone'],
                            'delivery_company' => $order_data['delivery_company'],
                            'delivery_address' => $order_data['delivery_address'],
                            'delivery_city' => $order_data['delivery_city'],
                            'delivery_country' => $order_data['delivery_country'],
                            'delivery_country_code' =>$order_data['delivery_country_code'],
                            'delivery_postalcode' => $order_data['delivery_postalcode'],
                            'delivery_co' => $order_data['delivery_co']
                        );

                        unset($order_data['delivery_address']);
                        
                        $this->context->smarty->assign(array('shippingInfo'  => $shipping_data));

                        $orderLines = $order_data['order_rows'];
                        if (!isset($orderLines['0'])) {
                            $temp_orderLine =$orderLines;
                            $orderLines = array();
                            $orderLines['0'] = $temp_orderLine;
                        }
                        unset($order_data['order_rows']);

                        $this->context->smarty->assign(array('orderLines'  => $orderLines));

                        $this->context->smarty->assign(array('order_info'  => $order_data));

                        $this->context->smarty->assign(array('shipping_info'  => $shipping_data));
                    }
                   
                    $this->context->smarty->assign(
                        'ship',
                        $this->context->link->getAdminLink('AdmincedfyndiqOrder').
                        '&submitShippingNumber=true'
                    );
                    $this->context->smarty->assign('id_order', $id_order);
                    $this->context->smarty->assign('token', $this->token);
                    $parent = $this->context->smarty->fetch(
                        _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/orders/form.tpl'
                    );
                    parent::renderForm();
                    return $parent;
                }
            }
        }
    }

    public function postProcess()
    {
         if (Tools::getIsset('action') && Tools::getValue('action')=='postTrackingDetails')
         {
            $cedFyndiqHelper = new CedFyndiqHelper();
            try{
                $postData = Tools::getAllValues();

                $orderData = Db::getInstance()->ExecuteS("SELECT `order_data` FROM `". _DB_PREFIX_ ."fyndiq_order` WHERE `fyndiq_order_id` = '". (int) $postData['orderId'] ."' ");
                $orderData = $orderData['0'];
                
                $orderData = Tools::jsonDecode($orderData['order_data'], true);
                
                $sku_data = array();
                foreach($orderData['order_rows'] as $key => $order_data){

                    $sku_data[] = $order_data['sku'];
                }
 
                $packageData[] = array(
                    'service' => $postData['service'],
                    'tracking' => $postData['tracking'],
                    'sku' => $sku_data,
                    'order' => $postData['orderId']
                    );
                $params = array(
                    'packages' => $packageData
                    );
                
                $res = $cedFyndiqHelper->fyndiqPostRequest('packages/', $params, "POST");
                if(isset($res['success']) && $res['success']) {
                    
                    die(json_encode(array('success' => true, 'message' => 'Tracking Details Send Successfully')));
                } else {
                    $message = Tools::jsonDecode($res['message'], true);
                    if(empty($message)){
                        $message['detail'] = 'Not Found';
                    }
                    die(json_encode(array('success' => false, 'message' => $message['detail'])));
                }

            } catch (\Exception $e) {
                $cedFyndiqHelper->log(
                    'AdminCedfyndiqOrdersController::TrackingDetails',
                    'Exception',
                    $e->getMessage(),
                    $e->getMessage(),
                    true
                );
                die(json_encode(array('success' => false,'message' => $e->getMessage())));
            }
         }

        if (Tools::getIsset('submitBulkhandleorder')) {
            if (Tools::getIsset('orderBox')
                &&  count(Tools::getValue('orderBox'))) {
                $this->processBulkHandle(Tools::getValue('orderBox'));
            } else {
                $this->errors[] = 'Please Select Order';
            }
        }

        if (Tools::getIsset('submitBulkdeliveryorder')) {
            if (Tools::getIsset('orderBox')
                &&  count(Tools::getValue('orderBox'))) {
                $this->processBulkDelivery(Tools::getValue('orderBox'));
            } else {
                $this->errors[] = 'Please Select Order';
            }
        }
        parent::postProcess();
    }

    public function displayHandleLink($token = null, $id = null, $name = null)
    {
        if ($token && $name) {
        }
        $tpl = $this->createTemplate('helpers/list/list_action_view.tpl');
        if (!array_key_exists('Handle', self::$cache_lang)) {
            self::$cache_lang['Handle'] = $this->l('Handle', 'Helper');
        }

        $tpl->assign(array(
            'href' => Context::getContext()->link
                    ->getAdminLink('AdminCedfyndiqOrders').
                '&orderHandle=true&id_order='.$id,
            'action' => self::$cache_lang['handle'],
            'id' => $id
        ));

        return $tpl->fetch();
    }

    public function displayDeliveryLink($token = null, $id = null, $name = null)
    {
        if ($token && $name) {
        }
        $tpl = $this->createTemplate('helpers/list/list_action_view.tpl');
        if (!array_key_exists('Delivery', self::$cache_lang)) {
            self::$cache_lang['Delivery'] = $this->l('Delivery', 'Helper');
        }

        $tpl->assign(array(
            'href' => Context::getContext()->link
                    ->getAdminLink('AdminCedfyndiqOrders').
                '&deliveryNotes=true&id_order='.$id,
            'action' => self::$cache_lang['Delivery'],
            'id' => $id
        ));

        return $tpl->fetch();
    }

    public function processBulkHandle($ids)
    {
        $cedFyndiqHelper = new CedFyndiqHelper();
        $CedfyndiqOrder = new CedfyndiqOrder();
        try {
            if($ids){
                $cedFyndiqHelper = new CedfyndiqHelper();
                if(count($ids) == '1'){
                    $orderData = Db::getInstance()->ExecuteS("SELECT `fyndiq_order_id` FROM `". _DB_PREFIX_ ."fyndiq_order` WHERE `prestashop_order_id` = '". (int) $ids['0']."' ");

                    $params = array('marked' => true);
                    $res = $cedFyndiqHelper->fyndiqPostRequest('orders/'.$orderData['0']['fyndiq_order_id'].'/', $params, "PATCH");

                    if(isset($res['success']) && $res['success']) {
                        //$message = Tools::jsonDecode($res['results'], true);
                        if(Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED'))
                        {
                            $CedfyndiqOrder->updateOrderStatus($ids['0'], Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED'));
                        }
                        $this->confirmations[] = 'Orders Handled Successfully!';
                    } else {
                        $message = Tools::jsonDecode($res['message'], true);
                        if(empty($message)){
                            $message['detail'] = 'Not Found';
                        }
                        $this->errors[] = $message['detail'];
                    }
                } else {
                    $order_ids = array();
                    foreach($ids as $key => $order_id){
                        $orderData = Db::getInstance()->ExecuteS("SELECT `fyndiq_order_id` FROM `". _DB_PREFIX_ ."fyndiq_order` WHERE `prestashop_order_id` = '". (int) $order_id."' ");

                        $order_ids[] = array(
                            'id' => $orderData['0']['fyndiq_order_id'],
                            'marked' => true
                        );

                        if(Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED'))
                        {
                            $CedfyndiqOrder->updateOrderStatus($order_id, Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED'));
                        }
                    }

                    $params = array('orders' => $order_ids);

                    $res = $cedFyndiqHelper->fyndiqPostRequest('orders/marked/', $params, "POST");
                    if(isset($res['success']) && $res['success']) {
                        //$message = Tools::jsonDecode($res['results'], true);
                        $this->confirmations[] = 'Orders Handled Successfully!';
                    } else {
                        $message = Tools::jsonDecode($res['message'], true);
                        if(empty($message)){
                            $message['detail'] = 'Not Found';
                        }
                        $this->errors[] = $message['detail'];
                    }
                }
            }
        } catch(\Exception $e)
        {
            $cedFyndiqHelper->log(
                'AdminCedfyndiqOrdersController::processBulkHandle',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            die(json_encode(array('success' => false,'message' => $e->getMessage())));
        }
    }

    public function processBulkDelivery($ids)
    {
        $cedFyndiqHelper = new CedFyndiqHelper();
        try{
            if($ids)
            {
                $cedFyndiqHelper = new CedfyndiqHelper();
                $order_ids = array();
                $order_file_name = '';
                foreach($ids as $key => $order_id)
                {
                    $orderData = Db::getInstance()->ExecuteS("SELECT `fyndiq_order_id` FROM `". _DB_PREFIX_ ."fyndiq_order` WHERE `prestashop_order_id` = '". (int) $order_id."' ");

                    $order_ids[] = array(
                        'order' => $orderData['0']['fyndiq_order_id']
                    );
                    $order_file_name .= $orderData['0']['fyndiq_order_id'] . '_';
                }

                $params = array('orders' => $order_ids);

                $res = $cedFyndiqHelper->fyndiqPostRequest('delivery_notes/', $params, "POST");

                if(isset($res['success']) && $res['success']) {

                    $data = $res['message'];
                    $order_file_name = rtrim($order_file_name, '_');
                    $path = _PS_MODULE_DIR_ . 'cedfyndiq/orders/'. $order_file_name . '.pdf';
                    file_put_contents($path, $data);

                    header("Content-type:application/pdf");
                    header("Content-Disposition:attachment;filename=delivery_note.pdf");
                    echo $data;

                    $this->confirmations[] = 'Delivery Slip Generated Successfully!';
                } else {
                    $message = Tools::jsonDecode($res['message'], true);
                    $response_message = '';
                    foreach($message['order'] as $key => $value){
                        $response_message .= $value;
                    }

                    if(empty($response_message)){
                        $response_message = 'Not Found';
                    }
                    $this->errors[] = $response_message;
                }
            }
        } catch(\Exception $e)
        {
            $cedFyndiqHelper->log(
                'AdminCedfyndiqOrdersController::processBulkDelivery',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            die(json_encode(array('success' => false,'message' => $e->getMessage())));
        }
    }
}
