<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

require_once _PS_MODULE_DIR_ . 'cedfyndiq/classes/CedfyndiqCategory.php';
require_once _PS_MODULE_DIR_ . 'cedfyndiq/classes/CedfyndiqHelper.php';

class AdminCedfyndiqCategoryController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap  = true;
        $this->table      = 'fyndiq_category_list';
        $this->identifier = 'id';
        $this->list_no_link = true;
        $this->addRowAction('mapcategory');
        $this->fields_list = array(
            'id'       => array(
                'title' => 'ID',
                'type'  => 'text',
                'align' => 'center',
                'class' => 'fixed-width-xs',
            ),
            'category_id'     => array(
                'title' => 'Category ID',
                'type'  => 'text',
            ),
            'name_sv'     => array(
                'title' => 'Name SV',
                'type'  => 'text',
            ),
//            'name_de'     => array(
//                'title' => 'Name DE',
//                'type'  => 'text',
//            ),
        );
        $this->fields_list['mapped_categories'] = array(
            'title' =>'View Mapping',
            'align' =>'text-left',
            'search' => false,
            'callback' => 'viewMappingButton',
        );

        if (Tools::getIsset('submitCategoryMapping') && Tools::getIsset('id')) {
            $response = $this->mapCategoryToFyndiq(Tools::getAllValues());
            if ($response) {
                $this->confirmations[] = 'Category Mapped Successfully.';
            } else {
                $this->errors[] = 'Not Mapped, There may be some error .';
            }
        }

        if (Tools::getIsset('fetch_category')) {
                $this->fetchCategory();
            }
        parent::__construct();
    }

    public function initToolbar()
    {
        $this->toolbar_btn['export'] = array(
            'href' => self::$currentIndex.'&export'.$this->table.'&token='.$this->token,
            'desc' => $this->l('Export')
        );
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['fetch_category'] = array(
                    'href' => $this->context->link->getAdminLink('AdminCedfyndiqCategory').'&fetch_category=true',
                    'desc' => 'Fetch Category',
                    'icon' => 'process-icon-download'
                );
        }
        parent::initPageHeaderToolbar();
    }
    public function fetchCategory()
    {
        $CedfyndiqHelper = new CedfyndiqHelper;
        $result = $CedfyndiqHelper->fyndiqGetRequest('categories/', array());
        if(isset($result['success']) && ($result['success'] == true) && isset($result['response']) && $result['response'])
        {
            $CedfyndiqCategory = new CedfyndiqCategory;
            $response = json_decode($result['response'], true);
            if(isset($response['categories']) && is_array($response['categories']) && $response['categories'])
            {
                $res = $CedfyndiqCategory->insertCategory($response['categories']);
                if(isset($res['success']) && ($res['success'] == true))
                {
                    $this->confirmation[] = $res['message'];
                } else {
                    $this->errors[] = $res['message'];
                }
            } else {
                $this->errors[] = 'Category not fetched!';
            }
        }
    }
    public function viewMappingButton($id)
    {
        if ($id) {
            // $default_lang = ((int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'))?
                // (int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'):
                // (int) Configuration::get('PS_LANG_DEFAULT');
            $category_ids = unserialize($id);
            $result = array();
            $id_lang = Context::getContext()->language->id;
            $id_shop = Context::getContext()->shop->id;
            if (count($category_ids)) {
                $result = Db::getInstance()->ExecuteS("SELECT `name`, `id_category` FROM `"._DB_PREFIX_."category_lang` 
                    WHERE 
                    `id_category` IN (".implode(',', $category_ids).") AND 
                    id_lang='".$id_lang."' AND 
                    id_shop='".$id_shop."'");
            }

            $this->context->smarty->assign(array(
               'category_ids' => $category_ids,
               'result' => $result,
               'id' => $id,
            ));
        } else {
            $this->context->smarty->assign(array(
                'category_ids' => array(),
                'result' => array(),
                'id' => null,
            ));
        }
        return $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/category_map/mapped_category.tpl'
        );
    }
    public function renderForm()
    {
//        $default_lang = ((int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'))?
//            (int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'):
//            (int) Configuration::get('PS_LANG_DEFAULT');
        //$storeCategory = Category::getAllCategoriesName(null, $default_lang);
        $storeCategory = array();
        $mapped_categories = $this->getMappedCategories(Tools::getValue('id'));
        $disable_categories = $this->getCategoriesToDisable(Tools::getValue('id'));
//        echo '<pre>'; print_r($mapped_categories); die;
        if (is_array($mapped_categories) && count($mapped_categories)) {
            $storeCategory = $mapped_categories;
            $this->context->smarty->assign(array('mapped_categories'  => $mapped_categories));
        } else {
            $this->context->smarty->assign(array('mapped_categories'  => array()));
        }
        if (is_array($disable_categories) && count($disable_categories)) {
            $this->context->smarty->assign(array('disable_categories'  => $disable_categories));
        } else {
            $this->context->smarty->assign(array('disable_categories'  => array()));
        }
        $this->context->smarty->assign(array(
            'action'=> $this->context->link->getAdminLink('AdminCedfyndiqCategory').'&id='.Tools::getValue('id')));
        $this->context->smarty->assign(array(
            'back'=> $this->context->link->getAdminLink('AdminCedfyndiqCategory')));
        if (is_array($storeCategory) && count($storeCategory)) {
            $this->context->smarty->assign(array('store_categories'  => $storeCategory));
        } else {
            $this->context->smarty->assign(array('store_categories'  => array()));
        }

        if (version_compare(_PS_VERSION_, '1.6.0', '>=') === true) {
            $tree_categories_helper = new HelperTreeCategories('categories-treeview');
            $tree_categories_helper->setRootCategory((Shop::getContext() == Shop::CONTEXT_SHOP ?
                Category::getRootCategory()->id_category : 0))
                ->setUseCheckBox(true);
        } else {
            if (Shop::getContext() == Shop::CONTEXT_SHOP) {
                $root_category = Category::getRootCategory();
                $root_category = array(
                    'id_category' => $root_category->id_category,
                    'name' => $root_category->name);
            } else {
                $root_category = array('id_category' => '0', 'name' => $this->l('Root'));
            }
            $tree_categories_helper = new Helper();
        }
        if (version_compare(_PS_VERSION_, '1.6.0', '>=') === true) {
            $tree_categories_helper->setUseSearch(true);
            $tree_categories_helper->setSelectedCategories($storeCategory);
            $this->context->smarty->assign(array(
                'storeCategories' => $tree_categories_helper->render()));
        } else {
            $this->context->smarty->assign(array(
                'storeCategories' => $tree_categories_helper->renderCategoryTree(
                    $root_category,
                    $storeCategory,
                    'categoryBox'
                )
            ));
        }

        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/category_map/form.tpl'
        );
        parent::renderForm();
        return $parent;
    }
    public function displayMapcategoryLink($token = null, $id = null)
    {
        if ($token) {
            $tpl = $this->createTemplate('helpers/list/list_action_edit.tpl');
        } else {
            $tpl = $this->createTemplate('helpers/list/list_action_edit.tpl');
        }
        if (!array_key_exists('Edit Mapping', self::$cache_lang)) {
            self::$cache_lang['Edit Mapping'] = $this->l('Edit Mapping', 'Helper');
        }

        $tpl->assign(array(
                'href' => Context::getContext()->link->getAdminLink('AdminCedfyndiqCategory')
                    .'&updatefyndiq_category_list&id='.$id,
                'action' => self::$cache_lang['Edit Mapping'],
                'id' => $id
        ));

        return $tpl->fetch();
    }
    public function mapCategoryToFyndiq($category_map)
    {
//        echo '<pre>'; print_r($category_map); die;
        $db = Db::getInstance();
//        if (!isset($category_map['store_category'])) {
//            $category_map['store_category'] = array();
//        }
//        $row = $db->Execute("UPDATE `"._DB_PREFIX_."fyndiq_category_list`
//        SET `mapped_categories` = '".pSQL(serialize($category_map['store_category']))."'
//        WHERE `id`='".(int)$category_map['id']."'");
        if (!isset($category_map['categoryBox'])) {
            $category_map['categoryBox'] = array();
        }
        $row = $db->Execute("UPDATE `"._DB_PREFIX_."fyndiq_category_list` 
        SET `mapped_categories` = '".pSQL(serialize($category_map['categoryBox']))."' 
        WHERE `id`='".(int)$category_map['id']."'");
        if ($row) {
            return true;
        } else {
            return false;
        }
    }
    public function getMappedCategories($category_id)
    {
        $db = Db::getInstance();
        $row = $db->getRow("SELECT `mapped_categories` FROM `"._DB_PREFIX_."fyndiq_category_list` 
        WHERE `id`='".(int)$category_id."'");
        if (isset($row['mapped_categories']) && $row['mapped_categories']) {
            return unserialize($row['mapped_categories']);
        } else {
            return array();
        }
    }
    public function getCategoriesToDisable($category_id)
    {
        $db = Db::getInstance();
        $row = $db->ExecuteS("SELECT `mapped_categories` FROM `"._DB_PREFIX_."fyndiq_category_list` 
        WHERE `mapped_categories` != '' AND `id` != '".(int)$category_id."'");
        
        if (isset($row['0']) && $row['0']) {
            $mapped_categories = array();
            foreach ($row as $value) {
                $mapped_categories = array_merge($mapped_categories, unserialize($value['mapped_categories']));
            }
            return $mapped_categories  ;
        } else {
            return array();
        }
    }
}
