<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php';
include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqProduct.php';

class AdminCedfyndiqProductsController extends ModuleAdminController
{
    /**
     * @var string name of the tab to display
     */

    public $db_columns = array(
        '0' => '',
        '1' => 'p.id_product',
        '2' => '',
        '3' => 'pl.name',
        '4' => 'p.reference',
        '5' => 'price',
        '6' => 'sav.quantity',
        '7' => 'p.active',
        '8' => 'p.id_product',
        '9' => 'p.id_product',
    );

    public function __construct()
    {
        $this->context = Context::getContext();
        $this->bootstrap = true;

        parent::__construct();

        if (Tools::getIsset('action') && Tools::getIsset('country_code')
            && Tools::getValue('country_code')
            && (Tools::getValue('action')=='getFyndiqLanguageCurrency')) {
            $this->getFyndiqLanguageCurrency();
        }
        if (Tools::isSubmit('submitProductSave')
            || Tools::isSubmit('submitProductSave')) {
            $status = $this->saveFyndiqProduct(Tools::getAllValues());
            if ($status) {
                $this->confirmations[] = 'Product Data Saved Successfully.';
            } else {
                $this->errors[] ='Some error while saving Product Data.';
            }
        }

        // Upload Product
        if (Tools::getIsset('submitBulkuploadproduct')) {
            if (Tools::getIsset('productBox')
                &&  count(Tools::getValue('productBox')))
            {
                $result = $this->processBulkUpload(Tools::getValue('productBox'));

                if (isset($result['error']) && $result['error']) {
                    if(is_array($result['error']))
                        $this->errors[] = implode(',', $result['error']);
                    else
                        $this->errors[] = $result['error'];
                }
                if (isset($result['success']) && $result['success']) {
                    $this->confirmations[] = $result['success'];

                    $link = new LinkCore();
                    $controller_link = $link->getAdminLink('AdminCedfyndiqUploadall');
                    Tools::redirectAdmin($controller_link);
                }
            } else {
                $this->errors[] = 'Please Select Product';
            }
        }

        // Include Product
        if (Tools::getIsset('submitBulkincludeproduct')) {
            if (Tools::getIsset('productBox')
                &&  count(Tools::getValue('productBox'))) {
                $result = $this->processBulkInclude(Tools::getValue('productBox'));

                if (isset($result['error']) && $result['error']) {
                    $this->errors[] = $result['error'];
                }
                if (isset($result['success']) && $result['success']) {
                    $this->confirmations[] = $result['success'];
                }
            } else {
                $this->errors[] = 'Please Select Product';
            }
        }

        // Exclude Product
        if (Tools::getIsset('submitBulkexcludeproduct'))
        {
            if (Tools::getIsset('productBox')
                &&  count(Tools::getValue('productBox')))
            {
                $result = $this->processBulkExclude(Tools::getValue('productBox'));

                if (isset($result['error']) && $result['error']) {
                    $this->errors[] = $result['error'];
                }
                if (isset($result['success']) && $result['success']) {
                    $this->confirmations[] = $result['success'];
                }
            } else {
                $this->errors[] = 'Please Select Product';
            }
        }

        // Clear Feed
        if (Tools::getIsset('clear_feed')) {
            $this->clearFeedData();
            //$this->downloadFeed();
        }

        // Fetch Status
        if (Tools::getIsset('fetch_status')) {
            $this->fetchProductStatus();
        }

        if(Tools::getIsset('ajax') && Tools::getValue('ajax') == 'data') {
            $output = $this->prepareData();
            die(json_encode($output));

        }

    }

    public function viewDetailsButton($data, $rowData)
    {
        $productName = isset($rowData['name'])?$rowData['name']: '';
        $this->context->smarty->assign(
            array(
                'validationJson' => $data,
                'productName' => $productName
            )
        );
        return $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/product/product_validation_detail.tpl'
        );
    }

    protected function processBulkUpload($product_ids = array())
    {
        if (is_array($product_ids) && count($product_ids)) {
            $CedfyndiqProduct = new CedfyndiqProduct();
            $result = $CedfyndiqProduct->uploadProducts($product_ids);
            return $result;
        }
    }

    public function initContent()
    {
        try {
            $content = null;
            parent::initContent();
            $link = new LinkCore();
            $controllerUrl = $link->getAdminLink('AdminCedfyndiqProducts');
            $uploadAll = $link->getAdminLink('AdminCedfyndiqUploadall');
            $fetchIds = $link->getAdminLink('AdminCedfyndiqStock').'&fetchstatus';
            $syncAll = $link->getAdminLink('AdminCedfyndiqStock').'&sync_qty=true';

            $feed_url = Configuration::get('CEDFYNDIQ_FEED_URL');

            $imgUrl = Context::getContext()->shop->getBaseURL(true).'modules/cedfyndiq/views/img/loading.gif';
            $this->context->smarty->assign(array(
                'feed_url' => $feed_url,
                'imgUrl' => $imgUrl,
            ));
            $token = $this->token;
            $this->context->smarty->assign(array('controllerUrl' => $controllerUrl));
            if(Tools::getIsset('updateproduct') && !empty(Tools::getValue('id_product'))) {
                $content = $this->getProductForm();
            } else {
                $categories = array();
                $cedfyndiqProduct = new CedfyndiqProduct();

                $categories = $cedfyndiqProduct->getAllFyndiqCategory();
                $this->context->smarty->assign(array('uploadAll' => $uploadAll));
                $this->context->smarty->assign(array('fyndiqCategories' => $categories));
                $this->context->smarty->assign(array('fetchIds' => $fetchIds));
                $this->context->smarty->assign(array('syncall' => $syncAll));
                $this->context->smarty->assign(array('token' => $token));
                $content = $this->context->smarty->fetch(
                    _PS_MODULE_DIR_ . 'cedfyndiq/views/templates/admin/product/data_table.tpl'
                );
            }


            $this->context->smarty->assign(array(
                'content' => $this->content . $content
            ));
        } catch (\Exception $e) {
        }
    }

    public function processBulkAssignCat()
    {
        $db = Db::getInstance();
        $cedfyndiqProduct = new CedfyndiqProduct;
        $ids = $this->boxes;
        $fyndiqCat = (int)$this->id_fyndiqcat;
        if(!empty($fyndiqCat)) {
            if(!empty($ids)) {
                $catName = $cedfyndiqProduct->getCategoryNameById($fyndiqCat);
                foreach ($ids as $id) {
                    //$db->execute("ALTER TABLE `" . _DB_PREFIX_ . "fyndiq_products` ADD `cat_name` text NOT NULL");
                    $data = $db->executeS(
                        "SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                           WHERE `product_id`='" . (int)$id . "'"
                    );

                    if (isset($data[0]['id']) && !empty($data[0]['id'])) {

                        $res = $db->update(
                            'fyndiq_products',
                            array(
                                'category' => pSQL($fyndiqCat),
                                'cat_name' => pSQL($catName),
                            ),
                            'product_id='.(int)$id.''
                        );
                    } else {
                        $res = $db->insert(
                            'fyndiq_products',
                            array(
                                'category' => pSQL($fyndiqCat),
                                'cat_name' => pSQL($catName),
                                'product_id' => (int)$id
                            )
                        );
                    }
                }

                if($res) {
                    $this->confirmations[] = "Category Assinged Successfully";
                }
            } else {
                $this->errors[] = "Please select Product(s)";
            }
        } else {
            $this->errors[] = "Please select Fyndiq Category";
        }
        $this->id_fyndiqcat = '';
        $this->context->cookie->id_fyndiqcat = '';

    }

    public function processBulkRemoveCat()
    {
        $db = Db::getInstance();
        $ids = $this->boxes;
        if(!empty($ids)) {
            foreach ($ids as $id) {
                $data = $db->executeS(
                    "SELECT `id` FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$id . "'"
                );
                //echo '<pre>'; print_r($data); die;
                if (isset($data[0]['id']) && !empty($data[0]['id'])) {
                    $res = $db->update(
                        'fyndiq_products',
                        array(
                            'category' => pSQL(''),
                            'cat_name' => pSQL(''),
                        ),
                        'product_id='.(int)$id.''
                    );
                } else {
                    $res = $db->insert(
                        'fyndiq_products',
                        array(
                            'category' => pSQL(''),
                            'cat_name' => pSQL(''),
                            'product_id' => (int)$id
                        )
                    );
                }
            }
            if($res) {
                $this->confirmations[] = "Category Removed Successfully";
            }
        } else {
            $this->errors[] = "Please select Product(s)";
        }
        $this->id_fyndiqcat = '';
        $this->context->cookie->id_fyndiqcat = '';
    }

    protected function processBulkInclude($product_ids = array())
    {
        $db = Db::getInstance();
        if (is_array($product_ids) && count($product_ids))
        {
            $error_message = array();
            $success_message = array();
            foreach($product_ids as $product_id)
            {
                $status = $db->executeS(
                    "SELECT * FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$product_id . "'"
                );
                if (isset($status[0]) &&!empty($status[0]['fyndiq_status']))
                {
                    $res = $db->update(
                        'fyndiq_products',
                        array(
                            'fyndiq_status' => pSQL('')
                        ),
                        'product_id="'.(int)$product_id.'"'
                    );
                }
                if($res) {
                    $success_message[] = 'Product Id '.$product_id.' is included successfully.';
                } else {
                    $error_message[] = 'Failed to include product Id '.$product_id.' because it is not excluded';
                }

            }

            if(is_array($error_message) && !empty($error_message))
            {
                $response['error'] = implode(',', $error_message);
            } elseif(is_array($success_message) && !empty($success_message))
            {
                $response['success'] = implode(',', $success_message);
            } else {
                $response['error'] = 'Error while including product(s) - '. implode(',', $product_ids);
            }
            //$result = $this->includeFeed($product_ids);
            return $response;
        }
    }
    protected function processBulkExclude($product_ids = array())
    {
        $db = Db::getInstance();
        if (is_array($product_ids) && count($product_ids))
        {
            $error_message = array();
            $success_message = array();
            foreach($product_ids as $product_id)
            {
                $status = $db->getValue(
                    "SELECT `id` FROM `" . _DB_PREFIX_ . "fyndiq_products` 
                WHERE `product_id`='" . (int)$product_id . "'"
                );

                if (!empty($status))
                {
                    $res = $db->update(
                        'fyndiq_products',
                        array(
                            'fyndiq_status' => pSQL('Excluded')
                        ),
                        'product_id="'.(int)$product_id.'"'
                    );
                }
                else
                {
                    $res = $db->insert(
                        'fyndiq_products',
                        array(
                            'fyndiq_status' => pSQL('Excluded'),
                            'product_id' => (int)$product_id
                        )
                    );
                }

                if($res) {
                    $success_message[] = 'Product Id '.$product_id.' is excluded successfully.';
                } else {
                    $error_message[] = 'Failed to exclude Product Id '. $product_id;
                }
            }

            if(is_array($error_message) && !empty($error_message))
            {
                $response['error'] = implode(',', $error_message);
            } elseif(is_array($success_message) && !empty($success_message))
            {
                $response['success'] = implode(',', $success_message);
            } else {
                $response['error'] = 'Error while excluding product(s) - '. implode(',', $product_ids);
            }
            //$result = $this->excludeFromFeed($product_ids);
            return $response;
        }
    }

    public function initPageHeaderToolbar()
    {
        if (empty($this->display)) {
            $this->page_header_toolbar_btn['clear_feed'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqProducts').'&clear_feed',
                'desc' => 'Clear Feed',
                'icon' => 'process-icon-eraser'
            );
            $this->page_header_toolbar_btn['download_feed'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqDeveloper'),
                'desc' => 'Download Feed',
                'icon' => 'process-icon-download'
            );
            $this->page_header_toolbar_btn['upload_all'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqUploadall'),
                'desc' => 'Upload All',
                'icon' => 'process-icon-upload'
            );
            $this->page_header_toolbar_btn['fetch_status'] = array(
                'href' => $this->context->link->getAdminLink('AdminCedfyndiqProducts').'&fetch_status',
                'desc' => 'Fetch Status',
                'icon' => 'process-icon-download'
            );
            // $this->page_header_toolbar_btn['sync_qty'] = array(
            //     'href' => $this->context->link->getAdminLink('AdminCedfyndiqStock').'&sync_qty=true',
            //     'desc' => 'Update Stock',
            //     'icon' => 'process-icon-upload'
            // );
        }
        parent::initPageHeaderToolbar();
    }

    public function downloadFeed()
    {
        $filename = _PS_MODULE_DIR_ . 'cedfyndiq/product_upload/temp_product_feed.csv';

        if(file_exists($filename)){
            header('Content-Description: File Transfer');
//            header('Content-Type: application/force-download');
            header('Content-Type: text/csv;charset=UTF-8');
            header("Content-language: sv");
            header("Content-Disposition: attachment; filename=\"" . basename($filename) . "\";");
            header('Content-Transfer-Encoding: binary');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($filename));
            // ob_clean();
            // flush();
            print chr(255) . chr(254) . mb_convert_encoding(readfile($filename), 'UTF-8');
            exit('ok');
        } else {
            return 'File Not Exists!';
        }
    }

    /**
     * renderForm contains all necessary initialization needed for all tabs
     *
     * @return string|void
     * @throws PrestaShopException
     */
    public function clearFeedData()
    {
        $db = Db::getInstance();
        try {
            $sql = "DELETE FROM  `"._DB_PREFIX_."fyndiq_final_products`";
            $res = $db->execute($sql);
            if ($res) {
                $csv_dir = _PS_MODULE_DIR_.'cedfyndiq/product_upload/';
                if (!is_dir($csv_dir)) {
                    mkdir($csv_dir, '0777', true);
                }
                //$file = fopen($csv_dir.'product_feed.csv', 'w');
                $header = array(
                    '0' => 'article-ean',
                    '1' => 'article-eu-energy-class',
                    '2' => 'article-eu-energy-datasheet-url',
                    '3' => 'article-eu-energy-label-url',
                    '4' => 'article-isbn',
                    '5' => 'article-location',
                    '6' => 'article-mpn',
                    '7' => 'article-name',
                    '8' => 'article-property-1-name',
                    '9' => 'article-property-1-value',
                    '10' => 'article-property-10-name',
                    '11' => 'article-property-10-value',
                    '12' => 'article-property-11-name',
                    '13' => 'article-property-11-value',
                    '14' => 'article-property-12-name',
                    '15' => 'article-property-12-value',
                    '16' => 'article-property-13-name',
                    '17' => 'article-property-13-value',
                    '18' => 'article-property-14-name',
                    '19' => 'article-property-14-value',
                    '20' => 'article-property-15-name',
                    '21' => 'article-property-15-value',
                    '22' => 'article-property-16-name',
                    '23' => 'article-property-16-value',
                    '24' => 'article-property-17-name',
                    '25' => 'article-property-17-value',
                    '26' => 'article-property-18-name',
                    '27' => 'article-property-18-value',
                    '28' => 'article-property-19-name',
                    '29' => 'article-property-19-value',
                    '30' => 'article-property-2-name',
                    '31' => 'article-property-2-value',
                    '32' => 'article-property-20-name',
                    '33' => 'article-property-20-value',
                    '34' => 'article-property-21-name',
                    '35' => 'article-property-21-value',
                    '36' => 'article-property-22-name',
                    '37' => 'article-property-22-value',
                    '38' => 'article-property-23-name',
                    '39' => 'article-property-23-value',
                    '40' => 'article-property-24-name',
                    '41' => 'article-property-24-value',
                    '42' => 'article-property-25-name',
                    '43' => 'article-property-25-value',
                    '44' => 'article-property-26-name',
                    '45' => 'article-property-26-value',
                    '46' => 'article-property-27-name',
                    '47' => 'article-property-27-value',
                    '48' => 'article-property-28-name',
                    '49' => 'article-property-28-value',
                    '50' => 'article-property-29-name',
                    '51' => 'article-property-29-value',
                    '52' => 'article-property-3-name',
                    '53' => 'article-property-3-value',
                    '54' => 'article-property-30-name',
                    '55' => 'article-property-30-value',
                    '56' => 'article-property-31-name',
                    '57' => 'article-property-31-value',
                    '58' => 'article-property-32-name',
                    '59' => 'article-property-32-value',
                    '60' => 'article-property-33-name',
                    '61' => 'article-property-33-value',
                    '62' => 'article-property-34-name',
                    '63' => 'article-property-34-value',
                    '64' => 'article-property-35-name',
                    '65' => 'article-property-35-value',
                    '66' => 'article-property-36-name',
                    '67' => 'article-property-36-value',
                    '68' => 'article-property-37-name',
                    '69' => 'article-property-37-value',
                    '70' => 'article-property-38-name',
                    '71' => 'article-property-38-value',
                    '72' => 'article-property-39-name',
                    '73' => 'article-property-39-value',
                    '74' => 'article-property-4-name',
                    '75' => 'article-property-4-value',
                    '76' => 'article-property-40-name',
                    '77' => 'article-property-40-value',
                    '78' => 'article-property-41-name',
                    '79' => 'article-property-41-value',
                    '80' => 'article-property-42-name',
                    '81' => 'article-property-42-value',
                    '82' => 'article-property-43-name',
                    '83' => 'article-property-43-value',
                    '84' => 'article-property-44-name',
                    '85' => 'article-property-44-value',
                    '86' => 'article-property-45-name',
                    '87' => 'article-property-45-value',
                    '88' => 'article-property-46-name',
                    '89' => 'article-property-46-value',
                    '90' => 'article-property-47-name',
                    '91' => 'article-property-47-value',
                    '92' => 'article-property-48-name',
                    '93' => 'article-property-48-value',
                    '94' => 'article-property-49-name',
                    '95' => 'article-property-49-value',
                    '96' => 'article-property-5-name',
                    '97' => 'article-property-5-value',
                    '98' => 'article-property-50-name',
                    '99' => 'article-property-50-value',
                    '100' => 'article-property-6-name',
                    '101' => 'article-property-6-value',
                    '102' => 'article-property-7-name',
                    '103' => 'article-property-7-value',
                    '104' => 'article-property-8-name',
                    '105' => 'article-property-8-value',
                    '106' => 'article-property-9-name',
                    '107' => 'article-property-9-value',
                    '108' => 'article-quantity',
                    '109' => 'article-sku',
                    '110' => 'product-brand-name',
                    '111' => 'product-category-fyndiq-id',
                    '112' => 'product-category-id',
                    '113' => 'product-category-name',
                    '114' => 'product-comparison-unit',
                    '115' => 'product-currency',
                    '116' => 'product-description',
                    '117' => 'product-id',
                    '118' => 'product-image-1-identifier',
                    '119' => 'product-image-1-url',
                    '120' => 'product-image-10-identifier',
                    '121' => 'product-image-10-url',
                    '122' => 'product-image-11-identifier',
                    '123' => 'product-image-11-url',
                    '124' => 'product-image-12-identifier',
                    '125' => 'product-image-12-url',
                    '126' => 'product-image-13-identifier',
                    '127' => 'product-image-13-url',
                    '128' => 'product-image-14-identifier',
                    '129' => 'product-image-14-url',
                    '130' => 'product-image-15-identifier',
                    '131' => 'product-image-15-url',
                    '132' => 'product-image-16-identifier',
                    '133' => 'product-image-16-url',
                    '134' => 'product-image-17-identifier',
                    '135' => 'product-image-17-url',
                    '136' => 'product-image-18-identifier',
                    '137' => 'product-image-18-url',
                    '138' => 'product-image-19-identifier',
                    '139' => 'product-image-19-url',
                    '140' => 'product-image-2-identifier',
                    '141' => 'product-image-2-url',
                    '142' => 'product-image-20-identifier',
                    '143' => 'product-image-20-url',
                    '144' => 'product-image-21-identifier',
                    '145' => 'product-image-21-url',
                    '146' => 'product-image-22-identifier',
                    '147' => 'product-image-22-url',
                    '148' => 'product-image-23-identifier',
                    '149' => 'product-image-23-url',
                    '150' => 'product-image-24-identifier',
                    '151' => 'product-image-24-url',
                    '152' => 'product-image-25-identifier',
                    '153' => 'product-image-25-url',
                    '154' => 'product-image-26-identifier',
                    '155' => 'product-image-26-url',
                    '156' => 'product-image-27-identifier',
                    '157' => 'product-image-27-url',
                    '158' => 'product-image-28-identifier',
                    '159' => 'product-image-28-url',
                    '160' => 'product-image-29-identifier',
                    '161' => 'product-image-29-url',
                    '162' => 'product-image-3-identifier',
                    '163' => 'product-image-3-url',
                    '164' => 'product-image-30-identifier',
                    '165' => 'product-image-30-url',
                    '166' => 'product-image-4-identifier',
                    '167' => 'product-image-4-url',
                    '168' => 'product-image-5-identifier',
                    '169' => 'product-image-5-url',
                    '170' => 'product-image-6-identifier',
                    '171' => 'product-image-6-url',
                    '172' => 'product-image-7-identifier',
                    '173' => 'product-image-7-url',
                    '174' => 'product-image-8-identifier',
                    '175' => 'product-image-8-url',
                    '176' => 'product-image-9-identifier',
                    '177' => 'product-image-9-url',
                    '178' => 'product-market',
                    '179' => 'product-oldprice',
                    '180' => 'product-paused',
                    '181' => 'product-portion',
                    '182' => 'product-price',
                    '183' => 'product-title',
                    '184' => 'product-vat-percent'
                );

                //fputcsv($file, $header);
                //fclose($file);
                $this->confirmations[] = 'Feed data cleared successfully';
            } else {
                $this->errors[] = 'Failed to clear feed data';
            }
        } catch (\Exception $e) {
            $this->errors[] = $e->getMessage();
        }
    }

    public function fetchProductStatus()
    {
        try {
            $CedfyndiqHelper = new CedfyndiqHelper;
            $CedfyndiqProduct = new CedfyndiqProduct;
            $url = 'product_info/';
            $params = array();
            $response = $CedfyndiqProduct->syncProducts($url, $params);

            if (isset($response['error']) && is_array($response['error']) && !empty($response['error']))
            {
                $this->errors[] = $response['message'];

            } else {
                $this->confirmations[] = $response['message'];
            }
        } catch(\Exception $e) {
            $CedfyndiqHelper->log(
                'Cron syncProducts',
                'Exception',
                $e->getMessage(),
                $e->getMessage(),
                true
            );
            $this->errors[] = $e->getMessage();
        }
    }

    public function getProductForm()
    {
        $this->product_name = $this->object->name[$this->context->language->id];
        $product = $this->object;
        $fyndiqHelper = new CedfyndiqHelper;
        $this->context->smarty->assign(
            array(
                'currentIndex' => self::$currentIndex,
                'currentToken' => $this->token,
                'currentObject' => $product,
                'hasAttribute' => $product->hasAttributes(),
            )
        );
        $db =  Db::getInstance();
        $fyndiq_products = $db->ExecuteS("SELECT `attributes` FROM `"._DB_PREFIX_."fyndiq_products` 
        WHERE `product_id`='".(int)$this->object->id."'");

        if (isset($fyndiq_products['0']['attributes'])) {
            $fyndiq_products = unserialize($fyndiq_products['0']['attributes']);
        } elseif (count(Tools::getAllValues())) {
            $fyndiq_products = Tools::getAllValues();
        } else {
            $fyndiq_products = array();
        }

        $validation_array = $fyndiqHelper->getValidationArray();

        if (is_array($validation_array) && count($validation_array)) {
            $this->context->smarty->assign(array('attributes'  => $validation_array));
        } else {
            $this->context->smarty->assign(array('attributes'  => array()));
        }
        if (isset($fyndiq_products['fyndiq_status'])) {
            $this->context->smarty->assign(array('fyndiq_status' => $fyndiq_products['fyndiq_status']));
        }

        $this->context->smarty->assign(array('fyndiq_products' => $fyndiq_products));

        $this->context->smarty->assign(array('product_id' => Tools::getValue('product_id')));

        $this->context->smarty->assign(
            array('back'=> $this->context->link->getAdminLink('AdminCedfyndiqProducts'))
        );

        if (Validate::isLoadedObject(($this->object))) {
            $id_product = (int)$this->object->id;
        } else {
            $id_product = (int)Tools::getvalue('id_product');
        }

        $page = (int)Tools::getValue('page');

        $this->context->smarty->assign(array(
            'action' => $this->context->link->getAdminLink('AdminCedfyndiqProducts').'&'.($id_product ?
                    'updateproduct&id_product='.(int)$id_product :
                    'uploadproduct').($page > 1 ? '&page='.(int)$page : '')));

        $this->context->smarty->assign(array('id_product' => $id_product));

        $parent = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ .'cedfyndiq/views/templates/admin/product/product_form.tpl'
        );
        if (Tools::getValue('success_message')) {
            $this->confirmations[] = Tools::getValue('success_message');
        }
        parent::renderForm();
        return $parent;
    }
    public function getFyndiqLanguageCurrency()
    {
        $cedfyndiqHelper = new CedfyndiqHelper;
        $response = array();
        $response['language'] = $cedfyndiqHelper->getFyndiqLanguage();
        $response['currency'] = $cedfyndiqHelper->getFyndiqCurrencyCode();
        die(json_encode($response));
    }

    public function saveFyndiqProduct($data)
    {
        $db =  Db::getInstance();
        if (isset($data['submitProductSave'])) {
            unset($data['submitProductSave']);
        }
        if (isset($data['controller'])) {
            unset($data['controller']);
        }
        if (isset($data['token'])) {
            unset($data['token']);
        }
        if (isset($data['controllerUri'])) {
            unset($data['controllerUri']);
        }

        $id_product = Tools::getValue('id_product');

        if (isset($id_product) && $id_product) {
            $result = $db->ExecuteS("SELECT * FROM `"._DB_PREFIX_."fyndiq_products` 
            where `product_id`='".(int)$id_product."'");

            if (count($result)) {
                $status = $db->Execute("UPDATE `"._DB_PREFIX_."fyndiq_products` 
                SET `attributes` = '".pSQL(serialize($data))."' 
                where `product_id`='".(int)$id_product."'");
                if ($status) {
                    return true;
                } else {
                    return false;
                }
            } else {
                $status = $db->Execute("INSERT INTO `"._DB_PREFIX_."fyndiq_products` 
                (`attributes`, `product_id`) 
                VALUES ('".pSQL(serialize($data))."', '".(int)$id_product."')");
                if ($status) {
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
//    public function setMedia($isNewTheme = false)
//    {
//        parent::setMedia($isNewTheme);
//        $this->addJqueryUI('ui.datepicker');
//    }

    public function productInfo()
    {
        $params = array();
        $cedFyndiqHelper = new CedfyndiqHelper();
        $res = $cedFyndiqHelper->fyndiqGetRequest('product_info/', $params);
        //
        if(isset($res['success']) && $res['success']) {
            $response = Tools::jsonDecode($res['response'], true);
            return $response;
        } else {
            $response = Tools::jsonDecode($res['message'], true);
            $this->errors[] = $response['detail'];
        }
    }

    public function prepareData()
    {
        $filter ='';
        $start = (int)Tools::getValue('start');
        $limit = (int)Tools::getValue('length');
        $orderByData = Tools::getValue('order');
        $frrugoProductStatusFilter = '';
        $frrugoIdFilter = '';
        $orderBy = 'p.id_product';
        $orderWay = 'asc';
        if(isset($orderByData['0']['column']) && !empty($orderByData['0']['column'])) {
            $orderByIndex = $orderByData['0']['column'];
            $orderBy = $this->db_columns[$orderByIndex];
            $orderWay = $orderByData['0']['dir'];
        }
        $draw  =Tools::getValue('draw');
        if(Tools::getValue('columns') && is_array(Tools::getValue('columns'))) {
            $columns = Tools::getValue('columns');
            foreach ($columns as $column) {
                if($column['data'] == 'id_product') {
                    $idf = trim($column['search']['value']);
                    if(!empty((int)$idf)) {
                        $filter .= " AND p.`id_product`='".(int)$idf."'";
                    }
                }
                if($column['data'] == 'name') {
                    $namef = trim($column['search']['value']);
                    if(!empty($namef)) {
                        $filter .= " AND pl.`name` LIKE '%".pSQL($namef)."%'";
                    }
                }
                if($column['data'] == 'reference') {
                    $referencef = trim($column['search']['value']);
                    if(!empty($referencef)) {
                        $filter .= " AND p.`reference` LIKE '%".pSQL($referencef)."%'";
                    }
                }
                if($column['data'] == 'quantity') {
                    $quantityf = trim($column['search']['value']);
                    if(!empty($quantityf)) {
                        $filter .= " AND sav.`quantity` = '".(int)($quantityf)."'";
                    }
                }
                if($column['data'] == 'status') {
                    $statusf = trim($column['search']['value']);
                    if(in_array($statusf, array('0','1'))) {
                        $filter .= " AND p.`active` = '".(int)($statusf)."'";
                    }
                }
                if($column['data'] == 'fyndiq_status') {
                    $fyndiq_statusf = trim($column['search']['value']);
                    if(!empty($fyndiq_statusf)) {
                        $filter .= " AND fp.`fyndiq_status` LIKE '%".pSQL($fyndiq_statusf)."%'";
                    }
                }
                if($column['data'] == 'fyndiq_id') {
                    $fyndiq_idf = trim($column['search']['value']);
                    if(!empty($fyndiq_idf)) {
                        $filter .= " AND fp.`fyndiqSkuId` LIKE '%".pSQL($fyndiq_idf)."%'";
                    }
                }
            }
        }
        $cedfyndiqProduct = new CedfyndiqProduct();
        $mapped_categories = $cedfyndiqProduct->getAllMappedCategories();
        $mapped_categories = array_unique($mapped_categories);
        $mapped_categories_str = implode(',', $mapped_categories);
        $db = Db::getInstance();
        $sql = "SELECT p.*, pl.`name`, sav.quantity, i.`id_image`, fp.*
             FROM `"._DB_PREFIX_."product` p
             LEFT JOIN `"._DB_PREFIX_."product_lang` pl ON (p.`id_product`=pl.`id_product`)
             LEFT JOIN `"._DB_PREFIX_."fyndiq_products` fp ON (p.`id_product`=fp.`product_id`)
             LEFT JOIN `"._DB_PREFIX_."image` i ON (i.`id_product` = p.`id_product` AND i.`cover` =1)
             LEFT JOIN `"._DB_PREFIX_."stock_available` sav ON (sav.`id_product` = p.`id_product` 
             AND sav.`id_product_attribute` = 0
             ".StockAvailable::addSqlShopRestriction(null, null, 'sav').")
             WHERE 1 $filter AND p.`id_category_default` IN (".$mapped_categories_str.") GROUP BY p.`id_product`
             ORDER BY $orderBy $orderWay LIMIT $start,$limit 
             ";

        $countsql = "SELECT  count(DISTINCT p.`id_product`) as total
             FROM `"._DB_PREFIX_."product` p
             LEFT JOIN `"._DB_PREFIX_."product_lang` pl ON (p.`id_product`=pl.`id_product`)
             LEFT JOIN `"._DB_PREFIX_."fyndiq_products` fp ON (p.`id_product`=fp.`product_id`)
             LEFT JOIN `"._DB_PREFIX_."stock_available` sav ON (sav.`id_product` = p.`id_product` 
             AND sav.`id_product_attribute` = 0
             ".StockAvailable::addSqlShopRestriction(null, null, 'sav').")
             WHERE 1 $filter AND p.`id_category_default` IN (".$mapped_categories_str.") 
             ";
        $cres = $db->executeS($countsql);

        $result = $db->executeS($sql);
        $total = $cres[0]['total'];
        $data = array();
        $nothing = null;
        $link = new Link();
        $context = Context::getContext();
        foreach ($result as $res) {
            $product = new Product($res['id_product']);
            $price = Product::getPriceStatic(
                $res['id_product'],
                true,
                null,
                (int)Configuration::get('PS_PRICE_DISPLAY_PRECISION'),
                null,
                false,
                true,
                1,
                true,
                null,
                null,
                null,
                $nothing,
                true,
                true,
                $context
            );
            $path_to_image = $link->getImageLink($product->link_rewrite[(int)Configuration::get('PS_LANG_DEFAULT')], $res['id_image'], 'home_default');
            $path_to_image = (Configuration::get('PS_SSL_ENABLED') ?
                    'https://' : 'http://') . $path_to_image;
            $data[] = array(
                "id" => $res['id_product'],
                "id_product" => $res['id_product'],
                "image" => "<img src='$path_to_image' width='50px' height='50px;'>",
                "name" => $res['name'],
                "reference" => $res['reference'],
                "price" => Tools::displayPrice($price),
                "quantity" => $res['quantity'],
                "status" => $res['active'],
                "fyndiq_status" => $res['fyndiq_status'],
                "fyndiq_id" => $res['fyndiqSkuId'],
                "error_message" => $res['error_message'],
                "action" => $res['id_product'],
            );
        }
        $response = array(
            "draw" => $draw,
            "recordsTotal" => $total,
            "recordsFiltered" => $total,
            "data" => $data,
        );
        return $response;
    }

}
