<?php
 /**
  * CedCommerce
  *
  * NOTICE OF LICENSE
  *
  * This source file is subject to the End User License Agreement(EULA)
  * that is bundled with this package in the file LICENSE.txt.
  * It is also available through the world-wide-web at this URL:
  * http://cedcommerce.com/license-agreement.txt
  *
  * @author    CedCommerce Core Team <connect@cedcommerce.com>
  * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
  * @license   http://cedcommerce.com/license-agreement.txt
  * @category  Ced
  * @package   CedFyndiq
  */

if (!defined('_PS_VERSION_')) {
    exit;
}
include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php';
include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqProduct.php';
include_once  _PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqOrder.php';

class Cedfyndiq extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'cedfyndiq';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Cedcommerce';
        $this->need_instance = 0;
        $this->db =  Db::getInstance();
        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        // $this->module_key = '634e216f748740b75991d6460de21b87';
        $this->bootstrap = true;
        $this->secure_key = Tools::encrypt($this->name);
        parent::__construct();

        $this->displayName = $this->l('Fyndiq Integration');
        $this->description = $this->l('Fyndiq Integration By Cedcommerce is a connector module for prestashop and Fyndiq.');

        $this->confirmUninstall = $this->l('Do you want to uninstall Fyndiq Integration');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);

    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
       // require_once  _PS_MODULE_DIR_.'cedfyndiq/sql/sql_install.php';
        Configuration::updateValue('CEDFYNDIQ_LIVE_MODE', false);
        if (count($this->db->ExecuteS("SHOW TABLES LIKE '"._DB_PREFIX_."fyndiq_category_list%'"))==0) {
            require_once  _PS_MODULE_DIR_.'cedfyndiq/sql/sql_install.php';
        }

        $shop_email =  Configuration::get('PS_SHOP_EMAIL');
        $shop_url =  Context::getContext()->shop->getBaseURL(true);
        $require_data =  array('domain'=>$shop_url, 'email'=>$shop_email, 'framework'=>'PrestaShop');
        $cedcommerce_url = 'http://admin.apps.cedcommerce.com/magento-fyndiq-info/create?'
            .http_build_query($require_data);

        $ch = curl_init($cedcommerce_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);

        // Check if any error occurred
        if (curl_errno($ch)) {
            $cedfyndiqHelper = new CedfyndiqHelper;
            $cedfyndiqHelper->log(
                __METHOD__,
                'Warning',
                'Install Message curl error',
                curl_errno($ch)
            );
        }

        // Close handle
        curl_close($ch);

        return parent::install() &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('actionProductUpdate') &&
            $this->installTab(
                'AdminCedfyndiq',
                'Fyndiq Integration',
                0
            ) &&
            $this->installTab(
                'AdminCedfyndiqCategory',
                'Fyndiq Category',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->installTab(
                'AdminCedfyndiqAttribute',
                'Fyndiq Attribute',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->installTab(
                'AdminCedfyndiqProducts',
                'Fyndiq Products',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
//            $this->installTab(
//                'AdminCedfyndiqOptionMapping',
//                'Fyndiq Option Mapping',
//                (int) Tab::getIdFromClassName('AdminCedfyndiq')
//            ) &&
            $this->installTab(
                'AdminCedfyndiqDefault',
                'Fyndiq Default Values',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->installTab(
                'AdminCedfyndiqOrders',
                'Fyndiq Orders',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->installTab(
                'AdminCedfyndiqFailedorder',
                'Fyndiq Failed Orders',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->installTab(
                'AdminCedfyndiqUploadall',
                'Fyndiq Upload All',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->installTab(
                'AdminCedfyndiqLogs',
                'Fyndiq Logs',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->installTab(
                'AdminCedfyndiqConfig',
                'Fyndiq Configuration',
                (int) Tab::getIdFromClassName('AdminCedfyndiq')
            ) &&
            $this->registerHook('actionOrderStatusPostUpdate');
    }
    public function installTab($class_name, $tab_name, $parent)
    {
        // Create new admin tab
        $tab = new Tab();
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = $tab_name;
        }
        $tab->id_parent = (int) Tab::getIdFromClassName($parent);
        $tab->icon = 'CFY';
        $tab->class_name = $class_name;
        $tab->module = $this->name;
        $tab->active = 1;
        return $tab->add();
    }
    public function uninstallTab($class_name)
    {
        $id_tab = (int)Tab::getIdFromClassName($class_name);
        if ($id_tab) {
            try {
                $tab = new Tab($id_tab);
                return $tab->delete();
            } catch (\Exception $e) {
                return false;
            }
        } else {
            return false;
        }
    }
    public function uninstall()
    {
        //Configuration::deleteByName('CEDFYNDIQ_LIVE_MODE');

        return parent::uninstall() && $this->uninstallTab('AdminCedfyndiq') &&
            $this->uninstallTab('AdminCedfyndiqCategory') &&
            $this->uninstallTab('AdminCedfyndiqProducts') &&
            $this->uninstallTab('AdminCedfyndiqOrders') &&
            //$this->uninstallTab('AdminCedfyndiqOptionMapping') &&
            $this->uninstallTab('AdminCedfyndiqDefault') &&
            $this->uninstallTab('AdminCedfyndiqStock') &&
            $this->uninstallTab('AdminCedfyndiqUploadall') &&
            $this->uninstallTab('AdminCedfyndiqConfig') &&
            $this->uninstallTab('AdminCedfyndiqLogs') &&
            $this->uninstallTab('AdminCedfyndiqFailedorder') &&
            $this->unregisterHook('displayBackOfficeHeader') &&
            $this->unregisterHook('actionProductUpdate');
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        $output = '';
        if (((bool)Tools::isSubmit('submitCedfyndiqModule')) == true) {
            $this->postProcess();
            if (Tools::getValue('CEDFYNDIQ_CONSUMER_ID') == ''
                || Tools::getValue('CEDFYNDIQ_CONSUMER_ID') == null) {
                $output .= $this->displayError('Please Fill Fyndiq User Name');
            }
            if (Tools::getValue('CEDFYNDIQ_TOKEN') == ''
                || Tools::getValue('CEDFYNDIQ_TOKEN') == null) {
                $output .= $this->displayError('Please Fill Fyndiq API Token');
            }
            if (Tools::getValue('CEDFYNDIQ_CUSTOMER_ID')
                && !empty(Tools::getValue('CEDFYNDIQ_CUSTOMER_ID'))) {
                if (!Validate::isInt(Tools::getValue('CEDFYNDIQ_CUSTOMER_ID'))) {
                    $output .= $this->displayError($this->l('Customer Id must be numeric'));
                    Configuration::updateValue('CEDFYNDIQ_CUSTOMER_ID', '');
                }
            }

            if ($output =='') {
                $output .= $this->displayConfirmation($this->l('Fyndiq Configuration saved successfully'));
            }
        }

        $this->context->smarty->assign('module_dir', $this->_path);

        $output1 = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');

        return $output. $output1.$this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $fields_form = array();
        $fields_form[0]['form'] = $this->getGeneralSettingForm();
        $fields_form[1]['form'] = $this->getProductSettingForm();
        $fields_form[2]['form'] = $this->getOrderSettingForm();
        $fields_form[3]['form'] = $this->getCronInfoForm();
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitCedfyndiqModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm($fields_form);
    }

    public function getGeneralSettingForm()
    {
        $store_languages = array();

        $store_languages_list = Language::getLanguages(true);

        foreach ($store_languages_list as $languages) {
            if (isset($languages['id_lang']) && $languages['id_lang']
                && isset($languages['name']) && $languages['name']
                && isset($languages['active']) && $languages['active']) {
                array_push($store_languages, array('id'=>$languages['id_lang'], 'name'=>$languages['name']));
            }
        }
        return  array(
           'legend' => array(
               'title' => $this->l('General Settings'),
               'icon' => 'icon-cogs',
           ),
           'input' => array(
               array(
                   'type' => 'switch',
                   'label' => $this->l('Enable'),
                   'name' => 'CEDFYNDIQ_LIVE_MODE',
                   'is_bool' => true,
                   'desc' => $this->l('Enable this module.'),
                   'values' => array(
                       array(
                           'id' => 'active_on',
                           'value' => true,
                           'label' => $this->l('Yes')
                       ),
                       array(
                           'id' => 'active_off',
                           'value' => false,
                           'label' => $this->l('No')
                       )
                   ),
               ),
               array(
                   'col' => 6,
                   'type' => 'text',
                   'prefix' => '<i class="icon icon-envelope"></i>',
                   'desc' => $this->l('API URL OF FYNDIQ SELLER i.e. "https://fyndiq.se/api/v1/".'),
                   'name' => 'CEDFYNDIQ_API_URL',
                   'readonly' => true,
                   'default_value' => 'https://api.fyndiq.com/v2/',
                   'label' => $this->l('API Url'),
               ),
               array(
                   'col' => 6,
                   'type' => 'text',
                   'prefix' => '<i class="icon icon-envelope"></i>',
                   'desc' => $this->l('Fyndiq User Name.'),
                   'name' => 'CEDFYNDIQ_CONSUMER_ID',
                   'required' => true,
                   'label' => $this->l('Fyndiq User Name'),
               ),
               array(
                   'col' => 6,
                   'type' => 'text',
                   'prefix' => '<i class="icon icon-envelope"></i>',
                   'desc' => $this->l('Fyndiq API Token.'),
                   'name' => 'CEDFYNDIQ_TOKEN',
                   'required' => true,
                   'label' => $this->l('Fyndiq Token.'),
               ),
               array(
                   'type' => 'select',
                   'label' => $this->l('Store Language'),
                   'desc' => $this->l('Store Language to be used in this module.'),
                   'name' => 'CEDFYNDIQ_LANGUAGE_STORE',
                   'required' => false,
                   'default_value' => '',
                   'options' => array(
                       'query' => $store_languages,
                       'id' => 'id',
                       'name' => 'name',
                   )
               ),
               array(
                   'type' => 'switch',
                   'label' => $this->l('Debug.'),
                   'name' => 'CEDFYNDIQ_DEBUG_ENABLE',
                   'is_bool' => true,
                   'desc' => $this->l('Log data while request sends on fyndiq.'),
                   'values' => array(
                       array(
                           'id' => 'active_on',
                           'value' => true,
                           'label' => $this->l('Yes')
                       ),
                       array(
                           'id' => 'active_off',
                           'value' => false,
                           'label' => $this->l('No')
                       )
                   ),
               ),
           )
        );
    }

    public function getProductSettingForm()
    {
        $categories = array();
        $cedfyndiqProduct = new CedfyndiqProduct();
        $categories = $cedfyndiqProduct->getAllFyndiqCategory();
        return array(
            'legend' => array(
                'title' => $this->l('Product Settings'),
                'icon' => 'icon-cogs',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'readonly' => true,
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Products Feed url which is to be shared with fyndiq.'),
                    'name' => 'CEDFYNDIQ_FEED_URL',
                    'label' => $this->l('Products Feed Url'),
                ),
                array(
                    'col' => 6,
                    'type' => 'text',
                    'readonly' => true,
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Products Notification url which is to be shared with fyndiq.'),
                    'name' => 'CEDFYNDIQ_NOTIFICATION_URL',
                    'label' => $this->l('Products Notification Url'),
                ),
                // array(
                //     'type' => 'select',
                //     'col' => 6,
                //     'label' => $this->l('Is Manufacturer'),
                //     'name' => 'CEDFYNDIQ_IS_MANUFACTURER',
                //     'desc' => $this->l('If merchant is manufacturer too in this 
                //         case product "EAN" is not required at Fyndiq.'),
                //     'required' => false,
                //     'default_value' => '',
                //     'options' => array(
                //         'query' => array(
                //             array('value' => 0, 'label' => 'No'),
                //             array('value' => 1, 'label' => 'Yes'),
                //         ),
                //         'id' => 'value',
                //         'name' => 'label',
                //     )
                // ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Price variant Type'),
                    'name' => 'CEDFYNDIQ_PRICE_VARIANT_TYPE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => 0, 'label' => '--  Select Price Variation --'),
                            array('value' => 1, 'label' => 'Regular Price'),
                            array('value' => 2, 'label' => 'Increase Fixed Amount'),
                            array('value' => 3, 'label' => 'Decrease Fix Amount'),
                            array('value' => 4, 'label' => 'Increase Fix Percent'),
                            array('value' => 5, 'label' => 'Decrease Fix Percent'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),
                array(
                    'col' => 3,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Amount to be variate on the basis of Increment or Decrement value.'),
                    'name' => 'CEDFYNDIQ_PRICE_VARIANT_AMOUNT',
                    'label' => $this->l('Price Variant Value'),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Fyndiq Price Type'),
                    'name' => 'CEDFYNDIQ_PRICE_TYPE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => 'product-price', 'label' => 'Product Price'),
                            array('value' => 'product-oldprice', 'label' => 'Product Old Price'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),

                array(
                    'type' => 'select',
                    'col' =>'9',
                    'label' => $this->l('Disabled Product Upload'),
                    'name' => 'CEDFYNDIQ_UPLOAD_DISABLE_PRODUCT',
                    'desc' => $this->l('Disabled Product to be upload or not at 
                        the time of Product upload on Fyndiq.'),
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => array(
                            array('value' => '0', 'label' => 'Skip Disabled Product'),
                            array('value' => '1', 'label' => 'Upload With "OUT OF STOCK" Status'),
                        ),
                        'id' => 'value',
                        'name' => 'label',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Map All Category'),
                    'name' => 'CEDFYNDIQ_CATEGORY_MAP_ALL',
                    'required' => false,
                    'class' => 'co',
                    'default_value' => '',
                    'options' => array(
                        'query' => $categories,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),
                // array(
                //     'type' => 'switch',
                //     'label' => $this->l('Auto Sync Inventory and Price By Cron'),
                //     'name' => 'CEDFYNDIQ_AUTO_SYNC_INVENTRY_PRICE_CRON',
                //     'is_bool' => true,
                //     'desc' => $this->l('If enable then QUANTITY AND PRICE will be automatically 
                //         SYNCHRONIZED By Cron.'),
                //     'values' => array(
                //         array(
                //             'id' => 'active_on',
                //             'value' => true,
                //             'label' => $this->l('Yes')
                //         ),
                //         array(
                //             'id' => 'active_off',
                //             'value' => false,
                //             'label' => $this->l('No')
                //         )
                //     ),
                // ),
                // array(
                //     'type' => 'switch',
                //     'label' => $this->l('Update Price on Product Edit.'),
                //     'name' => 'CEDFYNDIQ_UPDATE_PRICE_PRODUCT_EDIT',
                //     'is_bool' => true,
                //     'desc' => $this->l('Update price on fyndiq when you edit product on store .'),
                //     'values' => array(
                //         array(
                //             'id' => 'active_on',
                //             'value' => true,
                //             'label' => $this->l('Yes')
                //         ),
                //         array(
                //             'id' => 'active_off',
                //             'value' => false,
                //             'label' => $this->l('No')
                //         )
                //     ),
                // ),
                 array(
                     'type' => 'switch',
                     'label' => $this->l('Update Fyndiq Product on Product Edit.'),
                     'name' => 'CEDFYNDIQ_UPDATE_PRODUCT_EDIT',
                     'is_bool' => true,
                     'desc' => $this->l('Update product on fyndiq when you edit product on store.'),
                     'values' => array(
                         array(
                             'id' => 'active_on',
                             'value' => true,
                             'label' => $this->l('Yes')
                         ),
                         array(
                             'id' => 'active_off',
                             'value' => false,
                             'label' => $this->l('No')
                         )
                     ),
                 ),
                // array(
                //     'type' => 'switch',
                //     'label' => $this->l('Delete Product Data on Product Delete.'),
                //     'name' => 'CEDFYNDIQ_AUTO_DELETE_PRODUCT',
                //     'is_bool' => true,
                //     'desc' => $this->l('Delete PRODUCT DATA on fyndiq when you delete product on store .'),
                //     'values' => array(
                //         array(
                //             'id' => 'active_on',
                //             'value' => true,
                //             'label' => $this->l('Yes')
                //         ),
                //         array(
                //             'id' => 'active_off',
                //             'value' => false,
                //             'label' => $this->l('No')
                //         )
                //     ),
                // ),
            )
        );
    }
    public function getOrderSettingForm()
    {
        $id_lang = ((int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'))?
            (int) Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'):
            (int) Configuration::get('PS_LANG_DEFAULT');
        $order_states = $this->db->ExecuteS("SELECT `id_order_state`,`name` FROM `"._DB_PREFIX_."order_state_lang` WHERE `id_lang` = '".(int)$id_lang."'");

        $order_carriers = $this->db->ExecuteS("SELECT `id_carrier`,`name` FROM `"._DB_PREFIX_."carrier` WHERE `active` = '1' and `deleted` = '0'");

        $payment_methods = array();

        $modules_list = Module::getPaymentModules();

        foreach ($modules_list as $module) {
            $module_obj = Module::getInstanceById($module['id_module']);
            if ($module_obj) {
                array_push($payment_methods, array('id'=>$module_obj->name,'name'=>$module_obj->displayName));
            }
        }
        return array(
            'legend' => array(
                'title' => $this->l(' Order Settings'),
                'icon' => 'icon-cogs',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('Default Customer Id to create order on store which are imported form fyndiq.'),
                    'name' => 'CEDFYNDIQ_CUSTOMER_ID',
                    'label' => $this->l('Customer Id'),
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Import Status'),
                    'desc' => $this->l('Order Status when imported from Fyndiq.'),
                    'name' => 'CEDFYNDIQ_ORDER_STATE',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Handled Status'),
                    'desc' => $this->l('Order Status in Prestashop when handled at Fyndiq.'),
                    'name' => 'CEDFYNDIQ_ORDER_STATE_HANDLED',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_states,
                        'id' => 'id_order_state',
                        'name' => 'name',
                    )
                ),
//                array(
//                    'type' => 'select',
//                    'label' => $this->l('Order Shipped Status'),
//                    'desc' => $this->l('Order Status in Prestashop when Shipped at Fyndiq.'),
//                    'name' => 'CEDFYNDIQ_ORDER_STATE_SHIPPED',
//                    'required' => false,
//                    'default_value' => '',
//                    'options' => array(
//                        'query' => $order_states,
//                        'id' => 'id_order_state',
//                        'name' => 'name',
//                    )
//                ),
//                array(
//                    'type' => 'select',
//                    'label' => $this->l('Order Cancelled Status'),
//                    'desc' => $this->l('Order Status in Prestashop when Cancelled at Fyndiq.'),
//                    'name' => 'CEDFYNDIQ_ORDER_STATE_CANCELLED',
//                    'required' => false,
//                    'default_value' => '',
//                    'options' => array(
//                        'query' => $order_states,
//                        'id' => 'id_order_state',
//                        'name' => 'name',
//                    )
//                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Carrier'),
                    'desc' => $this->l('Carrier used to import Order from fyndiq.'),
                    'name' => 'CEDFYNDIQ_CARRIER_ID',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $order_carriers,
                        'id' => 'id_carrier',
                        'name' => 'name',
                    )
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Order Payment'),
                    'desc' => $this->l('Payment method used to import Order from fyndiq.'),
                    'name' => 'CEDFYNDIQ_ORDER_PAYMENT',
                    'required' => false,
                    'default_value' => '',
                    'options' => array(
                        'query' => $payment_methods,
                        'id' => 'id',
                        'name' => 'name',
                    )
                ),

                // array(
                //     'type' => 'switch',
                //     'label' => $this->l('Auto Order Accept/Reject'),
                //     'name' => 'CEDFYNDIQ_AUTO_ORDER_PROCESS',
                //     'is_bool' => true,
                //     'desc' => $this->l('If enable then order will be automatically accepted or
                //          rejected based on fulfillment status .'),
                //     'values' => array(
                //         array(
                //             'id' => 'active_on',
                //             'value' => true,
                //             'label' => $this->l('Yes')
                //         ),
                //         array(
                //             'id' => 'active_off',
                //             'value' => false,
                //             'label' => $this->l('No')
                //         )
                //     ),
                // ),
            )
        );
    }
    public function getCronInfoForm()
    {
        $this->context->smarty->assign(array(
            'base_url' => Context::getContext()->shop->getBaseURL(true),
            'cron_secure_key' => Configuration::get('CEDFYNDIQ_CRON_SECURE_KEY')
        ));
        $cron_html = $this->display(
            __FILE__,
            'views/templates/admin/configuration/cron_table.tpl'
        );
        return array(
            'legend' => array(
                'title' => $this->l('Cron Info'),
                'icon' => 'icon-info',
            ),
            'input' => array(
                array(
                    'col' => 6,
                    'type' => 'text',
                    'prefix' => '<i class="icon icon-envelope"></i>',
                    'desc' => $this->l('This cron secure key need to set in 
                    the parameters of following cron urls'),
                    'name' => 'CEDFYNDIQ_CRON_SECURE_KEY',
                    'label' => $this->l('Cron Secure Key'),
                ),

                array(
                    'type'  => 'html',
                    'col' => 12,
                    'label'  => $this->l(''),
                    'name' => $cron_html,
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
            ),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();
        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue(trim($key), Tools::getValue($key));
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookDisplayBackOfficeHeader($params)
    {
        if (!Module::isEnabled($this->name)) {
            return false;
        }
        if (method_exists($this->context->controller, 'addCSS')) {
            $this->context->controller->addCSS($this->_path.'views/css/tab.css');
        }
    }

    public function hookActionProductUpdate($params)
    {
        $cedfyndiqProduct = new CedfyndiqProduct();
        $cedfyndiqHelper = new CedfyndiqHelper();
        try {
            $idProduct = isset($params['id_product']) ? $params['id_product'] : null;

            if (!empty($idProduct)) {
                // $fyndiqPrice = (float)Tools::getValue('fyndiqPrice');
                // $fyndiqOldprice = (float)Tools::getValue('fyndiqOldPrice');
               
                // $cedfyndiqProduct->updateFyndiqPriceValue($idProduct, $fyndiqPrice, $fyndiqOldprice);
                if (Configuration::get('CEDFYNDIQ_UPDATE_PRODUCT_EDIT')) {
                    $result = $cedfyndiqProduct->uploadProducts(array($idProduct));
                    $cedfyndiqHelper->log(
                        __METHOD__,
                        'Info',
                        'Hook Product Update ' . $idProduct,
                        json_encode(
                            array(
                                'response' => $result
                            )
                        )
                    );
                }
            }
        } catch (\Exception $e) {
            $cedfyndiqHelper->log(
                __METHOD__,
                'Exception',
                $e->getMessage(),
                json_encode(
                    array(
                        'Trace' => $e->getMessage()
                    )
                ),
                true
            );
        }
    }

    // public function hookActionProductDelete($params)
    // {
    //     if (Configuration::get('CEDFYNDIQ_LIVE_MODE')
    //         && Configuration::get('CEDFYNDIQ_AUTO_DELETE_PRODUCT')) {
    //         $cedfyndiqHelper = new CedfyndiqHelper;
    //         $cedfyndiqProduct= new CedfyndiqProduct();
    //         try {
    //             $product_id = $params['id_product'];
    //             $response = $cedfyndiqProduct->deleteProductAtFyndiq(array($product_id));
    //             $cedfyndiqHelper->log(
    //                 __METHOD__,
    //                 'Info',
    //                 'HookActionProductDelete',
    //                 Tools::jsonEncode($response)
    //             );
    //         } catch (\Exception $e) {
    //             $cedfyndiqHelper->log(
    //                 'cedfyndiq::hookActionProductDelete',
    //                 'Exception',
    //                 $e->getMessage(),
    //                 $e->getMessage(),
    //                 true
    //             );
    //         }
    //     }
    // }

    // public function hookActionUpdateQuantity($params)
    // {
    //     $cedfyndiqHelper = new CedfyndiqHelper;
    //     $cedfyndiqProduct= new CedfyndiqProduct();
    //     try {
    //         $cedfyndiqHelper->log(
    //             __METHOD__,
    //             'Info',
    //             'Update Quantity Hook Running',
    //             ''
    //         );
    //         if (Configuration::get('CEDFYNDIQ_LIVE_MODE')
    //             && Configuration::get('CEDFYNDIQ_UPDATE_INVENTRY_PRODUCT_EDIT')) {
    //             $status = $cedfyndiqProduct->updateStock(array($params['id_product']));
    //             $cedfyndiqHelper->log(
    //                 __METHOD__,
    //                 'Info',
    //                 'Update Quantity Hook Response',
    //                 Tools::jsonEncode($status)
    //             );
    //         }
    //     } catch (\Exception $e) {
    //         $cedfyndiqHelper->log(
    //             'cedfyndiq::hookActionUpdateQuantity',
    //             'Exception',
    //             $e->getMessage(),
    //             Tools::jsonEncode($e->getMessage()),
    //             true
    //         );
    //     }
    // }
//    public function hookActionOrderStatusPostUpdate($params)
//    {
//        $cedfyndiqHelper = new CedfyndiqHelper;
//        $cedfyndiqOrder = new CedfyndiqOrder;
//        try {
//            $params = (array)$params;
//            $id_order = $params['id_order'];
//            $data  = (array)new Order($id_order);
//            $current_order_status = (int)$data['current_state'];
//            $order_state_when_shipped = (int)Configuration::get('CEDFyndiq_ORDER_STATE_SHIPPED');
//
//            if ($current_order_status == $order_state_when_shipped) {
//                $tracking_number = (int)$data['shipping_number'];
//                if (isset($tracking_number) && !empty($tracking_number)) {
//                    $id_carrier = (int)$data['id_carrier'];
//                    if ($id_carrier) {
//                        $carrier_data = (array)new Carrier($id_carrier);
//                        if (!empty($carrier_data)) {
//                            $tracking_url = $carrier_data['url'];
//                            if (isset($tracking_url) && !empty($tracking_url)) {
//                                $db = Db::getInstance();
//                                $sql = "SELECT `fyndiq_order_id` FROM `"._DB_PREFIX_."fyndiq_order`
//                                        WHERE `prestashop_order_id` = ".$id_order."";
//                                $res = $db->executeS($sql);
//                                if (is_array($res) && !empty($res)) {
//                                    $fyndiq_order_id = $res[0]['fyndiq_order_id'];
//                                    if ($fyndiq_order_id) {
//                                        $result = $cedfyndiqOrder->shipCompleteOrder(
//                                            $fyndiq_order_id,
//                                            '',
//                                            '',
//                                            $tracking_number,
//                                            $tracking_url
//                                        );
//                                        if (isset($result['success'])
//                                            && $result['success'] && isset($result['response'])) {
//                                            $data = $cedfyndiqHelper->xml2array($result['response']);
//                                            $cedfyndiqOrder->updatefyndiqOrderData(
//                                                $fyndiq_order_id,
//                                                $data['o:orders']['o:order']
//                                            );
//                                            $cedfyndiqOrder->updateOrderStatus(
//                                                $fyndiq_order_id,
//                                                'CEDFYNDIQ_ORDER_STATE_SHIPPED'
//                                            );
//                                        } else {
//                                            $error_res = 'Some Error While Shipment.';
//                                            if (isset($result['message'])) {
//                                                $error_res = $result['message'];
//                                            }
//                                            $cedfyndiqHelper->log($error_res, true);
//                                        }
//                                    }
//                                }
//                            } else {
//                            }
//                        } else {
//                        }
//                    }
//                } else {
//                }
//            } else {
//            }
//        } catch (\Exception $e) {
//        }
//    }

    public function getConfigFormValues()
    {
        return array(
            'CEDFYNDIQ_LIVE_MODE' => Configuration::get('CEDFYNDIQ_LIVE_MODE'),
            'CEDFYNDIQ_API_URL' => Configuration::get('CEDFYNDIQ_API_URL') ?
                Configuration::get('CEDFYNDIQ_API_URL'): 'https://api.fyndiq.com/v2/',
            'CEDFYNDIQ_CONSUMER_ID' => Configuration::get('CEDFYNDIQ_CONSUMER_ID') ?
                Configuration::get('CEDFYNDIQ_CONSUMER_ID'): '',
            'CEDFYNDIQ_TOKEN' => Configuration::get('CEDFYNDIQ_TOKEN') ?
                Configuration::get('CEDFYNDIQ_TOKEN'): '',
            'CEDFYNDIQ_IS_MANUFACTURER' => Configuration::get('CEDFYNDIQ_IS_MANUFACTURER') ?
                Configuration::get('CEDFYNDIQ_IS_MANUFACTURER'): 0,
            'CEDFYNDIQ_PRICE_TYPE' => Configuration::get('CEDFYNDIQ_PRICE_TYPE') ?
                Configuration::get('CEDFYNDIQ_PRICE_TYPE'): '',
            'CEDFYNDIQ_UPLOAD_DISABLE_PRODUCT' => Configuration::get('CEDFYNDIQ_UPLOAD_DISABLE_PRODUCT') ?
                Configuration::get('CEDFYNDIQ_UPLOAD_DISABLE_PRODUCT'): '',
            'CEDFYNDIQ_PRICE_VARIANT_AMOUNT' => Configuration::get('CEDFYNDIQ_PRICE_VARIANT_AMOUNT') ?
                Configuration::get('CEDFYNDIQ_PRICE_VARIANT_AMOUNT'): '',
            'CEDFYNDIQ_PRICE_VARIANT_TYPE' => Configuration::get('CEDFYNDIQ_PRICE_VARIANT_TYPE') ?
                Configuration::get('CEDFYNDIQ_PRICE_VARIANT_TYPE'): 0,
            'CEDFYNDIQ_AUTO_ORDER_PROCESS' => Configuration::get('CEDFYNDIQ_AUTO_ORDER_PROCESS') ?
                Configuration::get('CEDFYNDIQ_AUTO_ORDER_PROCESS'): false,
            'CEDFYNDIQ_AUTO_SYNC_INVENTRY_PRICE_CRON' => Configuration::get('CEDFYNDIQ_AUTO_SYNC_INVENTRY_PRICE_CRON') ?
                Configuration::get('CEDFYNDIQ_AUTO_SYNC_INVENTRY_PRICE_CRON'): false,
            'CEDFYNDIQ_FEED_URL' => Configuration::get('CEDFYNDIQ_FEED_URL') ?
                Configuration::get('CEDFYNDIQ_FEED_URL') :
                Context::getContext()->shop->getBaseURL(true). 'modules/cedfyndiq/product_upload/product_feed.csv',
            'CEDFYNDIQ_NOTIFICATION_URL' => Configuration::get('CEDFYNDIQ_NOTIFICATION_URL') ?
                Configuration::get('CEDFYNDIQ_NOTIFICATION_URL') :
                Context::getContext()->shop->getBaseURL(true) .
                'index.php?fc=module&module=cedfyndiq&controller=notification',
            'CEDFYNDIQ_UPDATE_PRICE_PRODUCT_EDIT' => Configuration::get('CEDFYNDIQ_UPDATE_PRICE_PRODUCT_EDIT') ?
                Configuration::get('CEDFYNDIQ_UPDATE_PRICE_PRODUCT_EDIT'): false,
            'CEDFYNDIQ_LANGUAGE_STORE' => Configuration::get('CEDFYNDIQ_LANGUAGE_STORE') ?
                Configuration::get('CEDFYNDIQ_LANGUAGE_STORE'): '',
            'CEDFYNDIQ_UPDATE_PRODUCT_EDIT' => Configuration::get('CEDFYNDIQ_UPDATE_PRODUCT_EDIT') ? Configuration::get('CEDFYNDIQ_UPDATE_PRODUCT_EDIT') : false,
            'CEDFYNDIQ_UPDATE_INVENTRY_PRODUCT_EDIT' => Configuration::get('CEDFYNDIQ_UPDATE_INVENTRY_PRODUCT_EDIT') ?
                Configuration::get('CEDFYNDIQ_UPDATE_INVENTRY_PRODUCT_EDIT'): false,
            'CEDFYNDIQ_AUTO_DELETE_PRODUCT' => Configuration::get('CEDFYNDIQ_AUTO_DELETE_PRODUCT') ?
                Configuration::get('CEDFYNDIQ_AUTO_DELETE_PRODUCT'): false,
            'CEDFYNDIQ_CATEGORY_MAP_ALL' => Configuration::get('CEDFYNDIQ_CATEGORY_MAP_ALL') ?
                Configuration::get('CEDFYNDIQ_CATEGORY_MAP_ALL'): '',
            'CEDFYNDIQ_DEBUG_ENABLE' => Configuration::get('CEDFYNDIQ_DEBUG_ENABLE') ?
                Configuration::get('CEDFYNDIQ_DEBUG_ENABLE'): true,
            'CEDFYNDIQ_CUSTOMER_ID' => Configuration::get('CEDFYNDIQ_CUSTOMER_ID') ?
                Configuration::get('CEDFYNDIQ_CUSTOMER_ID'): '',
            'CEDFYNDIQ_ORDER_STATE' => Configuration::get('CEDFYNDIQ_ORDER_STATE') ?
                Configuration::get('CEDFYNDIQ_ORDER_STATE'): null,
            'CEDFYNDIQ_CARRIER_ID' => Configuration::get('CEDFYNDIQ_CARRIER_ID') ?
                Configuration::get('CEDFYNDIQ_CARRIER_ID'): null,
            'CEDFYNDIQ_ORDER_PAYMENT' => Configuration::get('CEDFYNDIQ_ORDER_PAYMENT') ?
                Configuration::get('CEDFYNDIQ_ORDER_PAYMENT'): null,
            'CEDFYNDIQ_ORDER_STATE_HANDLED' => Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED') ?
                Configuration::get('CEDFYNDIQ_ORDER_STATE_HANDLED'): null,
            'CEDFYNDIQ_ORDER_STATE_SHIPPED' => Configuration::get('CEDFYNDIQ_ORDER_STATE_SHIPPED') ?
                Configuration::get('CEDFYNDIQ_ORDER_STATE_SHIPPED'): null,
            'CEDFYNDIQ_ORDER_STATE_CANCELLED' => Configuration::get('CEDFYNDIQ_ORDER_STATE_CANCELLED') ?
                Configuration::get('CEDFYNDIQ_ORDER_STATE_CANCELLED'): null,
            'CEDFYNDIQ_CRON_SECURE_KEY' => Configuration::get('CEDFYNDIQ_CRON_SECURE_KEY') ?
                Configuration::get('CEDFYNDIQ_CRON_SECURE_KEY'): '',
        );
    }
}
