<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php');


if (!Tools::getIsset('secure_key')
    || Tools::getValue('secure_key') != Configuration::get('CEDFYNDIQ_CRON_SECURE_KEY')) {
    die('Secure key does not matched');
}

try {
    $CedFyndiqHelper = new CedfyndiqHelper();

    $db = Db::getInstance();

    $params = array();
    $final_array = array();

    $sql = $db->executes("SELECT * FROM `". _DB_PREFIX_ ."fyndiq_order` WHERE `status` = 'NORMAL' ");

    if(isset($sql['0']['prestashop_order_id']) && !empty($sql['0']['prestashop_order_id']))
    {
        $data = array();
        foreach($sql as $order_data)
        {
            $tracking_number = $db->getvalue("SELECT `tracking_number` FROM `". _DB_PREFIX_ ."order_carrier`
                WHERE `id_order` = '". $order_data['prestashop_order_id'] ."' ");
            if(!empty($tracking_number))
            {
                $data['service'] = 'dhl';
                $data['tracking'] = $tracking_number;
                $data['order'] = $order_data['id'];
                $orderData = json_decode($order_data['order_data'], true);
                if(isset($orderData['order_rows']) && is_array($orderData['order_rows']) && !empty($orderData['order_rows']))
                {
                    $sku_data = array();
                    foreach($orderData['order_rows'] as $order_item_data)
                    {
                        $sku_data[] = $order_item_data['sku'];
                    }
                    $data['sku'] = $sku_data;
                }
                $final_array[] = $data;
            }

        }
    }

    if(isset($final_array) && is_array($final_array) && !empty($final_array))
    {
        $params = array('packages' => $final_array);
        $url ='packages/';
        $res = $CedFyndiqHelper->fyndiqPostRequest('packages/', $params, "POST");

        $CedFyndiqHelper->log(
            'ShipOrder Cron',
            'Info',
            'Cron For Ship Order',
            Tools::jsonEncode($res)
        );

        if(isset($res['success']) && $res['success']) {

            die(json_encode(array('success' => true, 'message' => 'Tracking Details Send Successfully')));
        } else {
            $message = Tools::jsonDecode($res['message'], true);
            if(empty($message['detail'])){
                $message['detail'] = 'No Response From Fyndiq';
            }
            die(json_encode(array('success' => false, 'message' => $message['detail'])));
        }
    }
} catch (Exception $e) {
    $CedFyndiqHelper->log(
        'CronOrderFetch',
        'Exception',
        $e->getMessage(),
        Tools::jsonEncode(
            array(
                'Trace' => $e->getTraceAsString()
            )
        ),
        true
    );
    die(Tools::jsonEncode(array(
        'success' => false,
        'message' => $e->getMessage()
    )));
}
