<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedShopee
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqProduct.php');

if (!Tools::isSubmit('secure_key')
    || Tools::getValue('secure_key') != Configuration::get('CEDFYNDIQ_CRON_SECURE_KEY')) {
    die('Secure key not matched');
}

try {

    $CedfyndiqHelper = new CedfyndiqHelper;
    $CedfyndiqProduct = new CedfyndiqProduct;
    $url = 'product_info/';
    $params = array();
    $response = $CedfyndiqProduct->syncProducts($url, $params);
//echo '<pre>'; print_r($response); die;
    if (isset($response['error']) && is_array($response['error']) && !empty($response['error']))
    {
        die(Tools::jsonEncode(
            array(
                'status' => false,
                'response' => $response['message']
            )
        ));
    } else {
        die(Tools::jsonEncode(
            array(
                'status' => true,
                'response' => $response['message']
            )
        ));
    }

} catch(\Exception $e) {
    $CedfyndiqHelper->log(
        'Cron syncProducts',
        'Exception',
        $e->getMessage(),
        $e->getMessage(),
        true
    );
    die(Tools::jsonEncode(array(
        'status' => false,
        'message' => $e->getMessage()
    )));
}