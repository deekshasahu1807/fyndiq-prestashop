<?php
/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement(EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://cedcommerce.com/license-agreement.txt
 *
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright Copyright CEDCOMMERCE(http://cedcommerce.com/)
 * @license   http://cedcommerce.com/license-agreement.txt
 * @category  Ced
 * @package   CedFyndiq
 */

include(dirname(__FILE__).'/../../config/config.inc.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqOrder.php');
include_once(_PS_MODULE_DIR_.'cedfyndiq/classes/CedfyndiqHelper.php');


if (!Tools::getIsset('secure_key')
 || Tools::getValue('secure_key') != Configuration::get('CEDFYNDIQ_CRON_SECURE_KEY')) {
    die('Secure key does not matched');
}

try {
    $CedFyndiqOrder = new CedfyndiqOrder();
    $CedFyndiqHelper = new CedfyndiqHelper();
    $url ='orders/';
    $params= array();
//    $minDate = date('Y-m-d H:i:s');
//    $minDate = str_replace(' ', '%20', $minDate);
//    $order = array('min_date'=> $minDate);
    $res = $CedFyndiqOrder->fetchOrder($params, $url);
    //echo '<pre>'; print_r($res); die;
    $CedFyndiqHelper->log(
        'OrderFetch Cron',
        'Info',
        'Cron For Order Fetch',
        Tools::jsonEncode($res)
    );
    die(Tools::jsonEncode($res));
} catch (Exception $e) {
    $CedFyndiqHelper->log(
        'CronOrderFetch',
        'Exception',
        $e->getMessage(),
        Tools::jsonEncode(
            array(
                'Trace' => $e->getTraceAsString()
            )
        ),
        true
    );
    die(Tools::jsonEncode(array(
        'success' => false,
        'message' => $e->getMessage()
        )));
}
